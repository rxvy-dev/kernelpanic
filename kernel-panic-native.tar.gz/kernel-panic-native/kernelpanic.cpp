// KERNEL PANIC - native SDL2 build.
// A neon twin-stick roguelite for Linux. C++17, SDL2 only (notify-send optional).
// Build: make            Run: ./kernel-panic [--help]
#include <SDL.h>
#include "net.h"

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <string>
#include <vector>

#include <fcntl.h>
#include <signal.h>
#include <spawn.h>
#include <sys/stat.h>
#include <unistd.h>
extern char** environ;

// ============================================================================
//  utils
// ============================================================================
static const float PI = 3.14159265358979f, TAU = 6.28318530717959f;
static uint64_t rngState = 0x9E3779B97F4A7C15ull;
static inline uint32_t rnd32() { rngState ^= rngState << 13; rngState ^= rngState >> 7; rngState ^= rngState << 17; return (uint32_t)(rngState >> 11); }
static inline float rnd01() { return (rnd32() & 0xFFFFFF) / 16777216.0f; }
static inline float rndr(float a, float b) { return a + (b - a) * rnd01(); }
static inline int irnd(int n) { return (int)(rnd01() * n); }
static inline float clampf(float v, float a, float b) { return v < a ? a : v > b ? b : v; }
static inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }
static inline float sq(float x) { return x * x; }

static std::string fmt(const char* f, ...) {
    char buf[512];
    va_list ap; va_start(ap, f); vsnprintf(buf, sizeof buf, f, ap); va_end(ap);
    return buf;
}
static std::string fmtNum(long n) {
    std::string s = std::to_string(n < 0 ? 0 : n), o;
    int c = 0;
    for (int i = (int)s.size() - 1; i >= 0; i--) { o.insert(o.begin(), s[i]); if (++c % 3 == 0 && i > 0) o.insert(o.begin(), ','); }
    return o;
}
static std::string fmtTime(float t) { int s = (int)t; return fmt("%02d:%02d", s / 60, s % 60); }

struct Col { uint8_t r, g, b, a; };
static Col hexc(uint32_t h, float a = 1.f) { return { (uint8_t)(h >> 16), (uint8_t)(h >> 8), (uint8_t)h, (uint8_t)(clampf(a, 0, 1) * 255) }; }
static Col withA(Col c, float a) { c.a = (uint8_t)(clampf(a, 0, 1) * 255); return c; }
static Col mixc(Col a, Col b, float t) {
    return { (uint8_t)lerpf(a.r, b.r, t), (uint8_t)lerpf(a.g, b.g, t), (uint8_t)lerpf(a.b, b.b, t), (uint8_t)lerpf(a.a, b.a, t) };
}
static const Col WHITE = { 255, 255, 255, 255 };
struct Pt { float x, y; };
// network hooks (defined in the multiplayer section)
static void netEvSfx(int n); static void netEvRing(float x, float y, float mx, uint32_t col); static void netEvShake(float a); static void netEvHit(float x, float y, float dmg, bool crit);
static void netEvKill(float x, float y, int type, bool elite); static void netEvGem(int idx); static void netEvBeam(const std::vector<Pt>& pts);
static void netBanner(const std::string& t, const std::string& sub, uint32_t col); static void netSendOver(); static void netShutdown();

// ============================================================================
//  paths, settings, stats
// ============================================================================
static std::string homeDir() { const char* h = getenv("HOME"); return h ? h : "."; }
static std::string xdgDir(const char* env, const char* fallback) { const char* v = getenv(env); return (v && *v) ? v : homeDir() + fallback; }
static void mkdirs(const std::string& p) {
    std::string cur;
    for (size_t i = 0; i < p.size(); i++) { cur += p[i]; if (p[i] == '/' && i > 0) mkdir(cur.c_str(), 0755); }
    mkdir(p.c_str(), 0755);
}

struct Settings {
    bool bloom = true, shake = true, notify = true, hooks = true, autopause = true, fullscreen = false, sfxOn = true, musOn = true, vsync = true, upnp = true;
    float master = 0.85f;
};
static Settings CFG;
static std::string cfgDir, dataDir, cacheDir, hooksDir;

static void loadSettings() {
    FILE* f = fopen((cfgDir + "/config.ini").c_str(), "r"); if (!f) return;
    char line[256];
    while (fgets(line, sizeof line, f)) {
        char k[64]; int v;
        if (sscanf(line, " %63[^=]=%d", k, &v) == 2) {
            std::string key = k;
            if (key == "bloom") CFG.bloom = v; else if (key == "shake") CFG.shake = v; else if (key == "notify") CFG.notify = v;
            else if (key == "hooks") CFG.hooks = v; else if (key == "autopause") CFG.autopause = v; else if (key == "fullscreen") CFG.fullscreen = v;
            else if (key == "sfx") CFG.sfxOn = v; else if (key == "music") CFG.musOn = v; else if (key == "vsync") CFG.vsync = v; else if (key == "upnp") CFG.upnp = v;
        }
    }
    fclose(f);
}
static void saveSettings() {
    FILE* f = fopen((cfgDir + "/config.ini").c_str(), "w"); if (!f) return;
    fprintf(f, "bloom=%d\nshake=%d\nnotify=%d\nhooks=%d\nautopause=%d\nfullscreen=%d\nsfx=%d\nmusic=%d\nvsync=%d\nupnp=%d\n",
            CFG.bloom, CFG.shake, CFG.notify, CFG.hooks, CFG.autopause, CFG.fullscreen, CFG.sfxOn, CFG.musOn, CFG.vsync, CFG.upnp);
    fclose(f);
}

struct Stats { long best = 0; int bestWave = 0; float bestTime = 0; int runs = 0; long totalKills = 0; };
static Stats STATS;
static void loadStats() {
    FILE* f = fopen((dataDir + "/stats.txt").c_str(), "r"); if (!f) return;
    char line[256];
    while (fgets(line, sizeof line, f)) {
        char k[64]; double v;
        if (sscanf(line, " %63[^=]=%lf", k, &v) == 2) {
            std::string key = k;
            if (key == "best") STATS.best = (long)v; else if (key == "bestWave") STATS.bestWave = (int)v; else if (key == "bestTime") STATS.bestTime = (float)v;
            else if (key == "runs") STATS.runs = (int)v; else if (key == "totalKills") STATS.totalKills = (long)v;
        }
    }
    fclose(f);
}
static void saveStats() {
    FILE* f = fopen((dataDir + "/stats.txt").c_str(), "w");
    if (f) {
        fprintf(f, "best=%ld\nbestWave=%d\nbestTime=%.1f\nruns=%d\ntotalKills=%ld\n", STATS.best, STATS.bestWave, STATS.bestTime, STATS.runs, STATS.totalKills);
        fclose(f);
    }
    // one-line summary for fastfetch / status bars
    f = fopen((dataDir + "/best.txt").c_str(), "w");
    if (f) { fprintf(f, "%s pts - wave %d - %s - %d runs\n", fmtNum(STATS.best).c_str(), STATS.bestWave, fmtTime(STATS.bestTime).c_str(), STATS.runs); fclose(f); }
}

// ============================================================================
//  desktop integration: notifications, hooks, live status, taskbar flash
// ============================================================================
struct EventInfo {
    const char* name; std::string title, body; int urgency; uint32_t color;
    int wave = 1; long score = 0; int kills = 0, level = 1; float hpPct = 100, time = 0; std::string boss;
};
static SDL_Window* gWindow = nullptr;

static void spawnDetached(const std::vector<std::string>& args) {
    if (args.empty()) return;
    std::vector<char*> av;
    for (auto& s : args) av.push_back((char*)s.c_str());
    av.push_back(nullptr);
    posix_spawn_file_actions_t fa; posix_spawn_file_actions_init(&fa);
    posix_spawn_file_actions_addopen(&fa, 0, "/dev/null", O_RDONLY, 0);
    posix_spawn_file_actions_addopen(&fa, 1, "/dev/null", O_WRONLY, 0);
    posix_spawn_file_actions_addopen(&fa, 2, "/dev/null", O_WRONLY, 0);
    pid_t pid;
    posix_spawnp(&pid, av[0], &fa, nullptr, av.data(), environ);   // failure (tool missing) is fine: best effort
    posix_spawn_file_actions_destroy(&fa);
}
static void emitEvent(const EventInfo& e) {
    // 1) live status file, readable by widgets/scripts
    FILE* f = fopen((cacheDir + "/live.json").c_str(), "w");
    if (f) {
        fprintf(f, "{\"event\":\"%s\",\"wave\":%d,\"score\":%ld,\"kills\":%d,\"level\":%d,\"hp\":%.0f,\"time\":%.0f,\"boss\":\"%s\",\"color\":\"#%06x\"}\n",
                e.name, e.wave, e.score, e.kills, e.level, e.hpPct, e.time, e.boss.c_str(), e.color);
        fclose(f);
    }
    // 2) taskbar flash when the window is in the background
    if (gWindow && !(SDL_GetWindowFlags(gWindow) & SDL_WINDOW_INPUT_FOCUS))
        SDL_FlashWindow(gWindow, e.urgency >= 2 ? SDL_FLASH_UNTIL_FOCUSED : SDL_FLASH_BRIEFLY);
    // 3) desktop notification
    if (CFG.notify && !e.title.empty()) {
        const char* u[] = { "low", "normal", "critical" };
        spawnDetached({ "notify-send", "-a", "Kernel Panic", "-u", u[std::min(2, std::max(0, e.urgency))], "-i", "applications-games", "-t", e.urgency >= 2 ? "6000" : "3500",
                        "-h", "string:x-canonical-private-synchronous:kernel-panic", e.title, e.body });
    }
    // 4) user hooks: ~/.config/kernel-panic/hooks/on_<event> and on_any (env carries the game state)
    if (CFG.hooks) {
        setenv("KP_EVENT", e.name, 1);
        setenv("KP_WAVE", std::to_string(e.wave).c_str(), 1);
        setenv("KP_SCORE", std::to_string(e.score).c_str(), 1);
        setenv("KP_KILLS", std::to_string(e.kills).c_str(), 1);
        setenv("KP_LEVEL", std::to_string(e.level).c_str(), 1);
        setenv("KP_HP", fmt("%.0f", e.hpPct).c_str(), 1);
        setenv("KP_TIME", fmt("%.0f", e.time).c_str(), 1);
        setenv("KP_BOSS", e.boss.c_str(), 1);
        setenv("KP_COLOR", fmt("#%06x", e.color).c_str(), 1);
        setenv("KP_BEST", std::to_string(STATS.best).c_str(), 1);
        for (const std::string& h : { hooksDir + "/on_" + e.name, hooksDir + "/on_any" })
            if (access(h.c_str(), X_OK) == 0) spawnDetached({ h });
    }
}

// ============================================================================
//  audio: software synth + sequenced music (no assets)
// ============================================================================
enum Wave { W_SIN, W_SQR, W_SAW, W_TRI, W_NOI };
struct Voice {
    bool on = false, bus = false, send = false; int wave = 0;
    float ph = 0, f0 = 440, lr = 0, dur = 0.1f, t = 0, vol = 0.1f, att = 0.004f, lpA = 0, hpA = 0, lpS = 0, hpS = 0, delay = 0;
};
struct Audio {
    SDL_AudioDeviceID dev = 0; int sr = 44100;
    Voice v[80];
    std::atomic<float> sfxVol{ 0.9f }, musTarget{ 0.5f }, master{ 0.85f };
    std::atomic<int> intensity{ 0 }, beat{ 0 };
    float musG = 0.5f;
    double stepAcc = 0; int step = 0; float bpm = 126;
    std::vector<float> dl; int dlPos = 0, dlLen = 1;
    // self-test counters
    std::atomic<long> cbCount{ 0 }, nanCount{ 0 }; std::atomic<float> peak{ 0 };

    Voice* alloc() {
        for (auto& x : v) if (!x.on) return &x;
        Voice* best = &v[0]; float bt = -1;
        for (auto& x : v) if (x.t > bt) { bt = x.t; best = &x; }
        return best;
    }
    void add(int wave, float f0, float f1, float dur, float vol, float lp, float hp, bool bus, bool send, float att, float delaySec) {
        Voice* x = alloc();
        *x = Voice();
        x->on = true; x->wave = wave; x->f0 = f0; x->lr = f1 > 0 ? log2f(f1 / f0) : 0; x->dur = dur; x->vol = vol; x->bus = bus; x->send = send;
        x->att = std::max(0.001f, att); x->delay = delaySec * sr;
        x->lpA = lp > 0 ? 1.f - expf(-TAU * lp / sr) : 0;
        x->hpA = hp > 0 ? 1.f - expf(-TAU * hp / sr) : 0;
    }
    // main-thread entry points (lock), callback-thread uses add() directly
    void tone(int wave, float f0, float f1, float dur, float vol, float lp = 0, float delaySec = 0) {
        if (!dev) return; SDL_LockAudioDevice(dev); add(wave, f0, f1, dur, vol, lp, 0, false, false, 0.004f, delaySec); SDL_UnlockAudioDevice(dev);
    }
    void noise(float dur, float vol, float lp, float hp) {
        if (!dev) return; SDL_LockAudioDevice(dev); add(W_NOI, 1, 0, dur, vol, lp, hp, false, false, 0.002f, 0); SDL_UnlockAudioDevice(dev);
    }

    static float midi(float n) { return 440.f * exp2f((n - 69.f) / 12.f); }
    void musicStep() {   // called from the audio thread, 16th-note resolution
        int I = intensity.load(); int bar = (step / 16) % 4, s = step % 16;
        static const int roots[4] = { 45, 41, 43, 40 };
        static const int chords[4][3] = { { 0, 3, 7 }, { 0, 4, 7 }, { 0, 4, 7 }, { 0, 3, 7 } };
        int root = roots[bar]; const int* ch = chords[bar];
        if (I >= 1 && s % 4 == 0) { add(W_SIN, 150, 45, 0.18f, 0.5f, 0, 0, true, false, 0.002f, 0); beat.fetch_add(1); }
        if (I >= 2 && (s == 4 || s == 12)) { add(W_NOI, 1, 0, 0.14f, 0.16f, 0, 1500, true, false, 0.002f, 0); add(W_TRI, 220, 120, 0.1f, 0.1f, 0, 0, true, false, 0.002f, 0); }
        if (I >= 1 && s % 2 == 1) add(W_NOI, 1, 0, 0.035f, I >= 2 ? 0.05f : 0.035f, 0, 7000, true, false, 0.001f, 0);
        if (I >= 3 && s % 2 == 0) add(W_NOI, 1, 0, 0.03f, 0.03f, 0, 8000, true, false, 0.001f, 0);
        if (I >= 1 && s % 2 == 0) { static const int bp[8] = { 0, 0, 12, 0, 0, 12, 0, 7 }; add(W_SAW, midi((float)(root + bp[(s / 2) % 8])), 0, 0.2f, 0.15f, 520, 0, true, false, 0.004f, 0); }
        int arp[8] = { ch[0], ch[1], ch[2], ch[1] + 12, ch[2], ch[1], ch[0] + 12, ch[2] };
        if (I == 0) { if (s % 2 == 0) add(W_TRI, midi((float)(root + 24 + arp[(s / 2) % 8])), 0, 0.3f, 0.06f, 2000, 0, true, true, 0.004f, 0); }
        else add(W_SQR, midi((float)(root + 24 + arp[s % 8] + (I >= 3 && s % 4 == 3 ? 12 : 0))), 0, 0.12f, I >= 2 ? 0.055f : 0.04f, 2600, 0, true, true, 0.004f, 0);
        step = (step + 1) % 64;
    }
    void fill(float* out, int n) {
        for (int i = 0; i < n; i++) {
            stepAcc -= 1.0;
            if (stepAcc <= 0) { stepAcc += sr * 60.0 / bpm / 4.0; musicStep(); }
            float sfx = 0, mus = 0, send = 0;
            for (auto& x : v) {
                if (!x.on) continue;
                if (x.delay > 0) { x.delay -= 1; continue; }
                float p = x.t / x.dur;
                if (p >= 1) { x.on = false; continue; }
                float f = x.lr != 0 ? x.f0 * exp2f(x.lr * p) : x.f0;
                float e = (x.t < x.att ? x.t / x.att : 1.f) * (1 - p) * (1 - p);
                float s;
                switch (x.wave) {
                    case W_SIN: s = sinf(TAU * x.ph); break;
                    case W_SQR: s = x.ph < 0.5f ? 1.f : -1.f; break;
                    case W_SAW: s = 2 * x.ph - 1; break;
                    case W_TRI: s = 4 * fabsf(x.ph - 0.5f) - 1; break;
                    default: s = (float)(rnd32() & 0xFFFF) / 32768.f - 1.f; break;
                }
                x.ph += f / sr; if (x.ph >= 1) x.ph -= floorf(x.ph);
                if (x.lpA > 0) { x.lpS += (s - x.lpS) * x.lpA; s = x.lpS; }
                if (x.hpA > 0) { x.hpS += (s - x.hpS) * x.hpA; s -= x.hpS; }
                s *= e * x.vol; x.t += 1.f / sr;
                if (x.bus) { mus += s; if (x.send) send += s; } else sfx += s;
            }
            float d = dl[dlPos]; dl[dlPos] = send + d * 0.34f; if (++dlPos >= dlLen) dlPos = 0;
            mus += d * 0.32f;
            musG += (musTarget.load() - musG) * 0.0006f;
            float m = (mus * musG + sfx * sfxVol.load()) * master.load();
            if (!std::isfinite(m)) { m = 0; nanCount++; }
            m = m / (1.f + fabsf(m));       // soft clip
            float a = fabsf(m); if (a > peak.load()) peak.store(a);
            out[2 * i] = out[2 * i + 1] = m;
        }
        cbCount++;
    }
    static void cb(void* ud, Uint8* stream, int len) { ((Audio*)ud)->fill((float*)stream, len / (int)(sizeof(float) * 2)); }
    bool init() {
        SDL_AudioSpec want; SDL_zero(want);
        want.freq = 44100; want.format = AUDIO_F32SYS; want.channels = 2; want.samples = 1024; want.callback = cb; want.userdata = this;
        SDL_AudioSpec have;
        dev = SDL_OpenAudioDevice(nullptr, 0, &want, &have, 0);
        if (!dev) return false;
        sr = have.freq;
        dlLen = std::max(1, (int)(sr * 60.0 / bpm * 0.75)); dl.assign(dlLen, 0.f);
        SDL_PauseAudioDevice(dev, 0);
        return true;
    }
};
static Audio AU;
static uint32_t sfxLast[24] = { 0 }; static int gemPitch = 0; static uint32_t gemT = 0;
enum Sfx { S_SHOOT, S_HIT, S_KILL, S_GEM, S_LEVEL, S_DASH, S_SUDO, S_HURT, S_BOSS, S_WAVE, S_DIE, S_ZAP, S_READY, S_UI, S_BOOM };
static void sfx(int n) {
    if (n < 0 || n > S_BOOM) return;   // never index tables with an id that came from the network
    netEvSfx(n);
    if (!AU.dev || !CFG.sfxOn) return;
    uint32_t now = SDL_GetTicks();
    static const uint32_t gap[24] = { 45, 25, 35, 25, 0, 0, 0, 0, 0, 0, 0, 90, 0, 0, 60 };
    if (now - sfxLast[n] < gap[n]) return;
    sfxLast[n] = now;
    switch (n) {
        case S_SHOOT: AU.tone(W_SQR, 820 + rndr(-40, 40), 260, 0.07f, 0.04f, 3500); break;
        case S_HIT: AU.noise(0.04f, 0.05f, 0, 2500); break;
        case S_KILL: AU.noise(0.16f, 0.09f, 1800, 0); AU.tone(W_SAW, 220, 60, 0.14f, 0.06f); break;
        case S_GEM: gemPitch = (now - gemT < 350) ? std::min(gemPitch + 1, 10) : 0; gemT = now; AU.tone(W_TRI, 520 * exp2f(gemPitch * 2 / 12.f), 0, 0.09f, 0.05f); break;
        case S_LEVEL: { const int st[4] = { 0, 4, 7, 12 }; for (int i = 0; i < 4; i++) AU.tone(W_SQR, 440 * exp2f(st[i] / 12.f), 0, 0.16f, 0.06f, 3000, i * 0.07f); break; }
        case S_DASH: AU.tone(W_SAW, 300, 900, 0.14f, 0.05f, 2500); AU.noise(0.15f, 0.05f, 0, 1200); break;
        case S_SUDO: AU.tone(W_SIN, 140, 28, 0.9f, 0.35f); AU.noise(0.8f, 0.2f, 900, 0); break;
        case S_HURT: AU.tone(W_SAW, 180, 60, 0.25f, 0.12f, 900); AU.noise(0.15f, 0.1f, 1200, 0); break;
        case S_BOSS: for (int k = 0; k < 4; k++) AU.tone(W_SAW, k % 2 ? 440.f : 330.f, 0, 0.3f, 0.07f, 1400, k * 0.32f); break;
        case S_WAVE: AU.tone(W_TRI, 330, 660, 0.3f, 0.08f); break;
        case S_DIE: AU.tone(W_SAW, 400, 40, 1.2f, 0.2f, 1500); AU.noise(1.0f, 0.15f, 600, 0); break;
        case S_ZAP: AU.noise(0.12f, 0.07f, 0, 3000); AU.tone(W_SQR, 1400, 300, 0.1f, 0.04f); break;
        case S_READY: AU.tone(W_TRI, 880, 0, 0.1f, 0.08f); AU.tone(W_TRI, 1320, 0, 0.14f, 0.08f, 0, 0.09f); break;
        case S_UI: AU.tone(W_SQR, 600, 900, 0.06f, 0.05f); break;
        case S_BOOM: AU.tone(W_SIN, 110, 30, 0.35f, 0.2f); AU.noise(0.3f, 0.12f, 1200, 0); break;
    }
}

// ============================================================================
//  graphics: batched geometry, glow sprites, 5x7 font, bloom + chromatic post
// ============================================================================
static const uint8_t FONT5x7[64][5] = {
    { 0x00, 0x00, 0x00, 0x00, 0x00 }, { 0x00, 0x00, 0x5F, 0x00, 0x00 }, { 0x00, 0x07, 0x00, 0x07, 0x00 }, { 0x14, 0x7F, 0x14, 0x7F, 0x14 },
    { 0x24, 0x2A, 0x7F, 0x2A, 0x12 }, { 0x23, 0x13, 0x08, 0x64, 0x62 }, { 0x36, 0x49, 0x56, 0x20, 0x50 }, { 0x00, 0x08, 0x07, 0x03, 0x00 },
    { 0x00, 0x1C, 0x22, 0x41, 0x00 }, { 0x00, 0x41, 0x22, 0x1C, 0x00 }, { 0x2A, 0x1C, 0x7F, 0x1C, 0x2A }, { 0x08, 0x08, 0x3E, 0x08, 0x08 },
    { 0x00, 0x80, 0x70, 0x30, 0x00 }, { 0x08, 0x08, 0x08, 0x08, 0x08 }, { 0x00, 0x00, 0x60, 0x60, 0x00 }, { 0x20, 0x10, 0x08, 0x04, 0x02 },
    { 0x3E, 0x51, 0x49, 0x45, 0x3E }, { 0x00, 0x42, 0x7F, 0x40, 0x00 }, { 0x72, 0x49, 0x49, 0x49, 0x46 }, { 0x21, 0x41, 0x49, 0x4D, 0x33 },
    { 0x18, 0x14, 0x12, 0x7F, 0x10 }, { 0x27, 0x45, 0x45, 0x45, 0x39 }, { 0x3C, 0x4A, 0x49, 0x49, 0x31 }, { 0x41, 0x21, 0x11, 0x09, 0x07 },
    { 0x36, 0x49, 0x49, 0x49, 0x36 }, { 0x46, 0x49, 0x49, 0x29, 0x1E }, { 0x00, 0x00, 0x14, 0x00, 0x00 }, { 0x00, 0x40, 0x34, 0x00, 0x00 },
    { 0x00, 0x08, 0x14, 0x22, 0x41 }, { 0x14, 0x14, 0x14, 0x14, 0x14 }, { 0x00, 0x41, 0x22, 0x14, 0x08 }, { 0x02, 0x01, 0x59, 0x09, 0x06 },
    { 0x3E, 0x41, 0x5D, 0x59, 0x4E }, { 0x7C, 0x12, 0x11, 0x12, 0x7C }, { 0x7F, 0x49, 0x49, 0x49, 0x36 }, { 0x3E, 0x41, 0x41, 0x41, 0x22 },
    { 0x7F, 0x41, 0x41, 0x41, 0x3E }, { 0x7F, 0x49, 0x49, 0x49, 0x41 }, { 0x7F, 0x09, 0x09, 0x09, 0x01 }, { 0x3E, 0x41, 0x41, 0x51, 0x73 },
    { 0x7F, 0x08, 0x08, 0x08, 0x7F }, { 0x00, 0x41, 0x7F, 0x41, 0x00 }, { 0x20, 0x40, 0x41, 0x3F, 0x01 }, { 0x7F, 0x08, 0x14, 0x22, 0x41 },
    { 0x7F, 0x40, 0x40, 0x40, 0x40 }, { 0x7F, 0x02, 0x1C, 0x02, 0x7F }, { 0x7F, 0x04, 0x08, 0x10, 0x7F }, { 0x3E, 0x41, 0x41, 0x41, 0x3E },
    { 0x7F, 0x09, 0x09, 0x09, 0x06 }, { 0x3E, 0x41, 0x51, 0x21, 0x5E }, { 0x7F, 0x09, 0x19, 0x29, 0x46 }, { 0x26, 0x49, 0x49, 0x49, 0x32 },
    { 0x03, 0x01, 0x7F, 0x01, 0x03 }, { 0x3F, 0x40, 0x40, 0x40, 0x3F }, { 0x1F, 0x20, 0x40, 0x20, 0x1F }, { 0x3F, 0x40, 0x38, 0x40, 0x3F },
    { 0x63, 0x14, 0x08, 0x14, 0x63 }, { 0x03, 0x04, 0x78, 0x04, 0x03 }, { 0x61, 0x59, 0x49, 0x4D, 0x43 }, { 0x00, 0x7F, 0x41, 0x41, 0x41 },
    { 0x02, 0x04, 0x08, 0x10, 0x20 }, { 0x00, 0x41, 0x41, 0x41, 0x7F }, { 0x04, 0x02, 0x01, 0x02, 0x04 }, { 0x40, 0x40, 0x40, 0x40, 0x40 }
};

struct Gfx {
    SDL_Window* win = nullptr; SDL_Renderer* rd = nullptr;
    int W = 1280, H = 720; float winScale = 1;
    SDL_Texture *glowT = nullptr, *fontT = nullptr, *vigT = nullptr, *scene = nullptr, *half = nullptr, *quarter = nullptr, *blurA = nullptr;
    std::vector<SDL_Vertex> vs; std::vector<int> ix;
    SDL_Texture* curT = nullptr; SDL_BlendMode curB = SDL_BLENDMODE_BLEND;
    bool targetsOK = false, software = false;

    void flush() {
        if (vs.empty()) return;
        SDL_SetRenderDrawBlendMode(rd, curB);
        if (curT) SDL_SetTextureBlendMode(curT, curB);
        SDL_RenderGeometry(rd, curT, vs.data(), (int)vs.size(), ix.data(), (int)ix.size());
        vs.clear(); ix.clear();
    }
    void mode(SDL_BlendMode b, SDL_Texture* t = nullptr) { if (b != curB || t != curT) { flush(); curB = b; curT = t; } }
    void vert(float x, float y, Col c, float u = 0, float w = 0) {
        SDL_Vertex a; a.position.x = x; a.position.y = y; a.color.r = c.r; a.color.g = c.g; a.color.b = c.b; a.color.a = c.a; a.tex_coord.x = u; a.tex_coord.y = w;
        vs.push_back(a);
    }
    void quad(Pt a, Pt b, Pt c, Pt d, Col col) {
        if (vs.size() > 60000) flush();
        int i = (int)vs.size();
        vert(a.x, a.y, col); vert(b.x, b.y, col); vert(c.x, c.y, col); vert(d.x, d.y, col);
        int idx[6] = { i, i + 1, i + 2, i, i + 2, i + 3 }; ix.insert(ix.end(), idx, idx + 6);
    }
    void rect(float x, float y, float w, float h, Col c) { quad({ x, y }, { x + w, y }, { x + w, y + h }, { x, y + h }, c); }
    void line(float x0, float y0, float x1, float y1, float w, Col c) {
        float dx = x1 - x0, dy = y1 - y0, l = sqrtf(dx * dx + dy * dy); if (l < 1e-4f) return;
        float ux = dx / l, uy = dy / l, nx = -uy * w * 0.5f, ny = ux * w * 0.5f, ex = ux * w * 0.35f, ey = uy * w * 0.35f;
        quad({ x0 - ex + nx, y0 - ey + ny }, { x1 + ex + nx, y1 + ey + ny }, { x1 + ex - nx, y1 + ey - ny }, { x0 - ex - nx, y0 - ey - ny }, c);
    }
    void fillCircle(float x, float y, float r, Col c, int seg = 0) {
        if (seg <= 0) seg = (int)clampf(r * 0.6f + 8, 10, 40);
        if (vs.size() > 60000) flush();
        int base = (int)vs.size();
        vert(x, y, c);
        for (int i = 0; i <= seg; i++) { float a = i * TAU / seg; vert(x + cosf(a) * r, y + sinf(a) * r, c); }
        for (int i = 0; i < seg; i++) { int idx[3] = { base, base + 1 + i, base + 2 + i }; ix.insert(ix.end(), idx, idx + 3); }
    }
    void ringStroke(float x, float y, float r, float w, Col c, int seg = 0) {
        if (seg <= 0) seg = (int)clampf(r * 0.35f + 12, 16, 72);
        for (int i = 0; i < seg; i++) {
            float a0 = i * TAU / seg, a1 = (i + 1) * TAU / seg, r0 = r - w * 0.5f, r1 = r + w * 0.5f;
            quad({ x + cosf(a0) * r0, y + sinf(a0) * r0 }, { x + cosf(a0) * r1, y + sinf(a0) * r1 }, { x + cosf(a1) * r1, y + sinf(a1) * r1 }, { x + cosf(a1) * r0, y + sinf(a1) * r0 }, c);
        }
    }
    void polyFill(const Pt* p, int n, Col c) {   // convex
        int base = (int)vs.size();
        for (int i = 0; i < n; i++) vert(p[i].x, p[i].y, c);
        for (int i = 1; i + 1 < n; i++) { int idx[3] = { base, base + i, base + i + 1 }; ix.insert(ix.end(), idx, idx + 3); }
    }
    void polyFillGrad(const Pt* p, int n, Pt c, Col cc, Col ec) {   // fan from a lit center to darker edges = cheap volume shading
        int base = (int)vs.size();
        vert(c.x, c.y, cc);
        for (int i = 0; i < n; i++) vert(p[i].x, p[i].y, ec);
        for (int i = 0; i < n; i++) { int j = (i + 1) % n; int idx[3] = { base, base + 1 + i, base + 1 + j }; ix.insert(ix.end(), idx, idx + 3); }
    }
    void polyStroke(const Pt* p, int n, bool closed, float w, Col c) {
        for (int i = 0; i + 1 < n; i++) line(p[i].x, p[i].y, p[i + 1].x, p[i + 1].y, w, c);
        if (closed && n > 2) line(p[n - 1].x, p[n - 1].y, p[0].x, p[0].y, w, c);
    }
    void glow(float x, float y, float rad, Col c) {   // additive glow sprite (call with mode(ADD, glowT))
        int i = (int)vs.size();
        vert(x - rad, y - rad, c, 0, 0); vert(x + rad, y - rad, c, 1, 0); vert(x + rad, y + rad, c, 1, 1); vert(x - rad, y + rad, c, 0, 1);
        int idx[6] = { i, i + 1, i + 2, i, i + 2, i + 3 }; ix.insert(ix.end(), idx, idx + 6);
    }
    float textW(const std::string& s, float sc) { return s.empty() ? 0 : (float)s.size() * 6 * sc - sc; }
    void text(const std::string& s, float x, float y, float sc, Col c, int align = 0) {   // align: 0 left, 1 center, 2 right
        mode(SDL_BLENDMODE_BLEND, fontT);
        float w = textW(s, sc); if (align == 1) x -= w / 2; else if (align == 2) x -= w;
        for (char ch : s) {
            int g = toupper((unsigned char)ch) - 32; if (g < 0 || g > 63) g = '?' - 32;
            float u0 = (g % 16) * 8 / 128.f, v0 = (g / 16) * 8 / 32.f, u1 = u0 + 8 / 128.f, v1 = v0 + 8 / 32.f;
            int i = (int)vs.size();
            vert(x, y, c, u0, v0); vert(x + 8 * sc, y, c, u1, v0); vert(x + 8 * sc, y + 8 * sc, c, u1, v1); vert(x, y + 8 * sc, c, u0, v1);
            int idx[6] = { i, i + 1, i + 2, i, i + 2, i + 3 }; ix.insert(ix.end(), idx, idx + 6);
            x += 6 * sc;
        }
    }
    void textGlow(const std::string& s, float x, float y, float sc, Col c, int align = 0) {   // chromatic-split neon text
        text(s, x - sc * 0.6f, y, sc, withA(hexc(0xff5fa2), 0.55f * c.a / 255.f), align);
        text(s, x + sc * 0.6f, y, sc, withA(hexc(0x67e8f9), 0.55f * c.a / 255.f), align);
        text(s, x, y, sc, c, align);
    }

    SDL_Texture* makeTarget(int w, int h, bool linear) {
        SDL_Texture* t = SDL_CreateTexture(rd, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_TARGET, std::max(1, w), std::max(1, h));
        if (t) SDL_SetTextureScaleMode(t, linear ? SDL_ScaleModeLinear : SDL_ScaleModeNearest);
        return t;
    }
    void destroyTargets() {
        for (SDL_Texture** t : { &scene, &half, &quarter, &blurA, &vigT }) if (*t) { SDL_DestroyTexture(*t); *t = nullptr; }
    }
    void buildTargets() {
        destroyTargets();
        SDL_GetRendererOutputSize(rd, &W, &H);
        int ww, wh; SDL_GetWindowSize(win, &ww, &wh); winScale = ww > 0 ? (float)W / ww : 1.f;
        scene = makeTarget(W, H, true); half = makeTarget(W / 2, H / 2, true); quarter = makeTarget(W / 4, H / 4, true); blurA = makeTarget(W / 4, H / 4, true);
        targetsOK = scene && half && quarter && blurA;
        // vignette (alpha rises toward the corners)
        const int vw = 128, vh = 72;
        SDL_Surface* s = SDL_CreateRGBSurfaceWithFormat(0, vw, vh, 32, SDL_PIXELFORMAT_RGBA32);
        if (s) {
            Uint32* px = (Uint32*)s->pixels;
            for (int y = 0; y < vh; y++) for (int x = 0; x < vw; x++) {
                float dx = (x + 0.5f) / vw - 0.5f, dy = (y + 0.5f) / vh - 0.5f, d = sqrtf(dx * dx + dy * dy) / 0.7071f;
                float a = clampf((d - 0.38f) / 0.62f, 0, 1); a = a * a * 0.9f;
                px[y * vw + x] = SDL_MapRGBA(s->format, 255, 255, 255, (Uint8)(a * 255));
            }
            vigT = SDL_CreateTextureFromSurface(rd, s); SDL_FreeSurface(s);
            if (vigT) { SDL_SetTextureBlendMode(vigT, SDL_BLENDMODE_BLEND); SDL_SetTextureScaleMode(vigT, SDL_ScaleModeLinear); }
        }
    }
    void buildStaticTextures() {
        SDL_Surface* g = SDL_CreateRGBSurfaceWithFormat(0, 64, 64, 32, SDL_PIXELFORMAT_RGBA32);
        Uint32* px = (Uint32*)g->pixels;
        for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
            float d = sqrtf(sq((x + 0.5f - 32) / 32) + sq((y + 0.5f - 32) / 32)), a = d >= 1 ? 0 : d < 0.25f ? lerpf(1, 0.55f, d / 0.25f) : lerpf(0.55f, 0, (d - 0.25f) / 0.75f);
            px[y * 64 + x] = SDL_MapRGBA(g->format, 255, 255, 255, (Uint8)(a * 255));
        }
        glowT = SDL_CreateTextureFromSurface(rd, g); SDL_FreeSurface(g);
        SDL_SetTextureScaleMode(glowT, SDL_ScaleModeLinear);
        SDL_Surface* f = SDL_CreateRGBSurfaceWithFormat(0, 128, 32, 32, SDL_PIXELFORMAT_RGBA32);
        SDL_FillRect(f, nullptr, SDL_MapRGBA(f->format, 0, 0, 0, 0));
        Uint32* fp = (Uint32*)f->pixels;
        for (int gi = 0; gi < 64; gi++) for (int c = 0; c < 5; c++) for (int r = 0; r < 7; r++)
            if ((FONT5x7[gi][c] >> r) & 1) fp[((gi / 16) * 8 + r) * 128 + (gi % 16) * 8 + c] = SDL_MapRGBA(f->format, 255, 255, 255, 255);
        fontT = SDL_CreateTextureFromSurface(rd, f); SDL_FreeSurface(f);
        SDL_SetTextureScaleMode(fontT, SDL_ScaleModeNearest);
    }
    bool init(bool headless, bool fullscreen) {
        Uint32 wf = SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI | (fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
        int ww0 = getenv("KP_W") ? atoi(getenv("KP_W")) : 1280, hh0 = getenv("KP_H") ? atoi(getenv("KP_H")) : 720;   // KP_W/KP_H: dev aid for fast headless tests
        win = SDL_CreateWindow("KERNEL PANIC", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, ww0, hh0, wf);
        if (!win) { fprintf(stderr, "window: %s\n", SDL_GetError()); return false; }
        SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1");
        if (!headless) rd = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | (CFG.vsync ? SDL_RENDERER_PRESENTVSYNC : 0));
        if (!rd) { rd = SDL_CreateRenderer(win, -1, SDL_RENDERER_SOFTWARE); software = true; }
        if (!rd) { fprintf(stderr, "renderer: %s\n", SDL_GetError()); return false; }
        buildStaticTextures(); buildTargets();
        return true;
    }
    void beginScene() {
        SDL_SetRenderTarget(rd, targetsOK ? scene : nullptr);
        SDL_SetRenderDrawColor(rd, 7, 4, 15, 255); SDL_RenderClear(rd);
        vs.clear(); ix.clear(); curT = nullptr; curB = SDL_BLENDMODE_BLEND;
    }
    // scene target -> screen with bloom and optional chromatic split
    void compose(bool bloom, float chroma) {
        flush();
        if (!targetsOK) return;
        SDL_FRect full = { 0, 0, (float)W, (float)H };
        if (bloom) {
            SDL_SetTextureBlendMode(scene, SDL_BLENDMODE_NONE); SDL_SetTextureBlendMode(half, SDL_BLENDMODE_NONE);
            SDL_SetTextureColorMod(scene, 255, 255, 255);
            SDL_SetRenderTarget(rd, half); SDL_RenderCopy(rd, scene, nullptr, nullptr);
            SDL_SetRenderTarget(rd, quarter); SDL_RenderCopy(rd, half, nullptr, nullptr);
            SDL_SetTextureBlendMode(quarter, SDL_BLENDMODE_ADD); SDL_SetTextureBlendMode(blurA, SDL_BLENDMODE_ADD);
            static const float wgt[5] = { 0.07f, 0.24f, 0.38f, 0.24f, 0.07f };
            SDL_FRect q = { 0, 0, (float)(W / 4), (float)(H / 4) };
            for (int pass = 0; pass < 2; pass++) {
                SDL_Texture* src = pass == 0 ? quarter : blurA; SDL_Texture* dst = pass == 0 ? blurA : quarter;
                SDL_SetRenderTarget(rd, dst); SDL_SetRenderDrawColor(rd, 0, 0, 0, 255); SDL_RenderClear(rd);
                for (int k = -2; k <= 2; k++) {
                    Uint8 c = (Uint8)(wgt[k + 2] * 255);
                    SDL_SetTextureColorMod(src, c, c, c);
                    SDL_FRect d = q; if (pass == 0) d.x += k * 1.7f; else d.y += k * 1.7f;
                    SDL_RenderCopyF(rd, src, nullptr, &d);
                }
                SDL_SetTextureColorMod(src, 255, 255, 255);
            }
        }
        SDL_SetRenderTarget(rd, nullptr);
        SDL_SetRenderDrawColor(rd, 0, 0, 0, 255); SDL_RenderClear(rd);
        if (chroma > 0.2f) {
            SDL_SetTextureBlendMode(scene, SDL_BLENDMODE_ADD);
            const Uint8 cm[3][3] = { { 255, 0, 0 }, { 0, 255, 0 }, { 0, 0, 255 } };
            for (int i = 0; i < 3; i++) {
                SDL_SetTextureColorMod(scene, cm[i][0], cm[i][1], cm[i][2]);
                SDL_FRect d = full; d.x += (i - 1) * chroma; SDL_RenderCopyF(rd, scene, nullptr, &d);
            }
            SDL_SetTextureColorMod(scene, 255, 255, 255);
        } else { SDL_SetTextureBlendMode(scene, SDL_BLENDMODE_NONE); SDL_RenderCopyF(rd, scene, nullptr, &full); }
        if (bloom) {
            SDL_SetTextureBlendMode(quarter, SDL_BLENDMODE_ADD);
            SDL_SetTextureColorMod(quarter, 170, 170, 170); SDL_RenderCopyF(rd, quarter, nullptr, &full);
            SDL_SetTextureColorMod(quarter, 255, 255, 255);
        }
    }
    void overlayFull(Col c) { mode(SDL_BLENDMODE_BLEND); rect(0, 0, (float)W, (float)H, c); }
    void vignette(Col c) {
        if (!vigT) return;
        flush(); SDL_SetTextureColorMod(vigT, c.r, c.g, c.b); SDL_SetTextureAlphaMod(vigT, c.a);
        SDL_FRect full = { 0, 0, (float)W, (float)H }; SDL_RenderCopyF(rd, vigT, nullptr, &full);
    }
    void screenshot(const std::string& path) {
        SDL_Surface* s = SDL_CreateRGBSurfaceWithFormat(0, W, H, 32, SDL_PIXELFORMAT_ARGB8888);
        if (!s) return;
        if (SDL_RenderReadPixels(rd, nullptr, SDL_PIXELFORMAT_ARGB8888, s->pixels, s->pitch) == 0) SDL_SaveBMP(s, path.c_str());
        SDL_FreeSurface(s);
    }
};
static Gfx GX;

// ============================================================================
//  game data
// ============================================================================
static const float WX0 = -1500, WX1 = 1500, WY0 = -1000, WY1 = 1000, CELL = 96;
enum { T_WORM, T_TROJAN, T_SPY, T_RANSOM, T_CHARGER, T_BOMB, T_BOSS };
struct TypeDef { float r, hp, spd, dmg, xp; int val; uint32_t col; };
static const TypeDef TD[] = {
    { 11, 18, 118, 8, 1, 10, 0xff5fa2 }, { 24, 95, 62, 16, 4, 35, 0xffa940 }, { 14, 42, 95, 9, 3, 30, 0xffe14d }, { 19, 70, 84, 12, 3, 40, 0xff6b6b },
    { 16, 60, 80, 20, 4, 45, 0xc6ff4d }, { 15, 55, 46, 0, 3, 50, 0xff8a3d }, { 58, 1800, 70, 24, 40, 1500, 0xff3d81 }
};
static const char* BOSS_NAMES[3] = { "BOTNET HYDRA", "ZERO-DAY EXPLOIT", "SEGFAULT" };
static const uint32_t BOSS_COLS[3] = { 0xff3d81, 0x35f0c8, 0xffd23d };
static const uint32_t WAVE_COLS[8] = { 0xa855f7, 0x22d3ee, 0xf472b6, 0xfb923c, 0x4ade80, 0x60a5fa, 0xfacc15, 0xef4444 };

struct Enemy {
    int id = 0, type = 0; float x = 0, y = 0, vx = 0, vy = 0, r = 10, hp = 1, maxhp = 1, spd = 1, dmg = 1; uint32_t col = 0xffffff;
    float flash = 0, t = 0, orbCd = 0; int dashId = 0; bool elite = false, dead = false; int dir = 1; float fireT = 1; int state = 0; float st = 0, cx = 1, cy = 0, intro = 0;
    float atk = 0, spin = 0, sumT = 0, fuse = -1; int phase = 1, kind = 0;
};
struct Bullet { float x, y, vx, vy, r, life, dmg; bool crit, dead; int pierce; int hits[8]; int nh; int hom, owner; };
struct EBullet { float x, y, vx, vy, r, dmg, life; bool dead; uint32_t col; };
struct Gem { float x, y, vx, vy, v, t; bool mag, dead; };
struct Part { float x, y, vx, vy, life, max, s; uint32_t col; float drag; bool dead; };
struct FText { float x, y, life, max, size; uint32_t col; char s[16]; bool dead; };
struct RingFx { float x, y, max, life, t, w; uint32_t col; bool dead; };
struct Beam { std::vector<Pt> pts; float life, max; bool dead; };
struct Laser { float x, y, ang, t, tel, fire; bool hit, dead; uint32_t col; };
struct Shard { float x, y, vx, vy, rot, vr, len, life, max; uint32_t col; bool dead; };

struct PStats { float dmg = 10, rate = 4.2f; int count = 1, pierce = 0; float speed = 285, magnet = 100, regen = 0, crit = 0.05f; int homing = 0; float dashCd = 1.6f; int orbit = 0, chain = 0, nova = 0; };
struct Player {
    float x = 0, y = 0, vx = 0, vy = 0, ang = 0, r = 13, hp = 100, maxhp = 100, iframes = 0, dashT = 0, dashCd = 0; int dashId = 0; float dashDx = 1, dashDy = 0, fireCd = 0;
    int level = 1; float xp = 0, xpNeed = 0; bool dead = false; float orbAng = 0, chainT = 1.2f, novaT = 2.5f; int ups[24] = { 0 }; PStats st;
    int idx = 0; uint32_t col = 0x67e8f9; char name[16] = "PLAYER"; bool remote = false, connected = true; float respawnT = 0; int pending = 0; int choices[3] = { -1, -1, -1 }; bool offer = false; float offerT = 0;
    float inMx = 0, inMy = 0, inAng = 0, inAge = 99; bool inFire = false, inDash = false, inSudo = false; uint32_t sid = 0;
};
struct Upg { const char* tag; const char* name; const char* d1; const char* d2; int max; bool heal, nw; void (*fn)(Player&); };
static const Upg UPGS[] = {
    { "CPU", "OVERCLOCK", "+18% FIRE RATE", "", 8, false, false, [](Player& p) { p.st.rate *= 1.18f; } },
    { "CPU", "MULTITHREAD", "+1 PROJECTILE", "PER SHOT", 5, false, true, [](Player& p) { p.st.count++; } },
    { "CPU", "-O3 OPTIMIZATION", "+22% BULLET", "DAMAGE", 8, false, false, [](Player& p) { p.st.dmg *= 1.22f; } },
    { "CPU", "PIPE THROUGH", "BULLETS PIERCE", "+1 ENEMY", 4, false, false, [](Player& p) { p.st.pierce++; } },
    { "CPU", "/DEV/URANDOM", "+12% CRIT CHANCE", "(X2.2 DAMAGE)", 5, false, false, [](Player& p) { p.st.crit += 0.12f; } },
    { "WEAPON", "ROUTE TABLE", "BULLETS CURVE", "TOWARD ENEMIES", 3, false, true, [](Player& p) { p.st.homing++; } },
    { "WEAPON", "KERNEL MODULES", "+1 ORBITING BLADE", "THAT SHREDS", 5, false, true, [](Player& p) { p.st.orbit++; } },
    { "WEAPON", "IPTABLES CHAIN", "LIGHTNING ARCS", "BETWEEN ENEMIES", 5, false, true, [](Player& p) { p.st.chain++; } },
    { "WEAPON", "SIGKILL PULSE", "PERIODIC DAMAGING", "SHOCKWAVE", 5, false, true, [](Player& p) { p.st.nova++; } },
    { "SYSTEM", "HEAP EXPANSION", "+30 MAX HP", "AND HEAL 30", 6, false, false, [](Player& p) { p.maxhp += 30; p.hp = std::min(p.maxhp, p.hp + 30); } },
    { "SYSTEM", "SWAP REGEN", "REGENERATE", "1.2 HP PER SECOND", 4, false, false, [](Player& p) { p.st.regen += 1.2f; } },
    { "SYSTEM", "MAGNET MOUNT", "+50% PICKUP", "RANGE", 4, false, false, [](Player& p) { p.st.magnet *= 1.5f; } },
    { "MOBILITY", "NICE -N -20", "+12% MOVE SPEED", "", 5, false, false, [](Player& p) { p.st.speed *= 1.12f; } },
    { "MOBILITY", "CONTEXT SWITCH", "DASH RECHARGES", "22% FASTER", 4, false, false, [](Player& p) { p.st.dashCd *= 0.78f; } },
    { "HEAL", "GARBAGE COLLECT", "RESTORE 50%", "OF YOUR HP", 99, true, false, [](Player& p) { p.hp = std::min(p.maxhp, p.hp + p.maxhp * 0.5f); } },
};
static const int NUPG = (int)(sizeof(UPGS) / sizeof(UPGS[0]));
static const char* QUOTES[] = { "SEGMENTATION FAULT (CORE DUMPED)", "FATAL: UNABLE TO MOUNT ROOT FS", "INIT: KILLED BY SIGNAL 9", "OOPS: 0002 [#1] PREEMPT SMP NOPTI", "SYSTEMD[1]: FAILED TO START /BOOT.", "EMERGE: (1 OF 1) FAILED" };

enum State { ST_TITLE, ST_PLAY, ST_LEVELUP, ST_PAUSE, ST_DYING, ST_OVER, ST_JOIN, ST_LOBBY };
struct Banner { float t = 0, dur = 2.4f; std::string text, sub; uint32_t col = 0xc084fc; bool on = false; };
struct Game {
    State state = ST_TITLE; bool demo = true;
    float t = 0, time = 0; int wave = 3; double score = 0; int kills = 0, streak = 0, combo = 1; float comboT = 0, sudo = 0, hitstop = 0, timeScale = 1, shake = 0, beat = 0, hurt = 0, flash = 0;
    int intensity = 0; bool bossAlive = false; int bossCount = 0; float bossT = 0, swarmT = 40, spawnT = 1; int pending = 0; Banner banner; float deathT = 0; bool sudoReady = false;
    int choices[3] = { 0, 0, 0 }; uint32_t lvT = 0; uint32_t accent = 0xa855f7; float accentMix[3] = { 0.66f, 0.33f, 0.97f }; bool newBest = false; const char* quote = QUOTES[0];
};
static Game G;
static std::deque<Enemy> enemies;
static std::vector<Bullet> bullets; static std::vector<EBullet> ebul; static std::vector<Gem> gems; static std::vector<Part> parts;
static std::vector<FText> texts; static std::vector<RingFx> rings; static std::vector<Beam> beams; static std::vector<Laser> lasers; static std::vector<Shard> shards;
static int mpRole = 0;   // 0 = single player, 1 = host, 2 = client
static inline bool MP() { return mpRole != 0; }
static std::vector<Player> players(1); static Player* curP = &players[0]; static int localIdx = 0;
#define P (*curP)   /* the player currently being processed; the local player outside per-player loops */
static Enemy* boss = nullptr; static int nextId = 1;
static const uint32_t PCOLS[4] = { 0x67e8f9, 0xf472b6, 0x4ade80, 0xfb923c };
static Player* nearestPlayer(float x, float y) { Player* b = nullptr; float bd = 1e30f; for (auto& p : players) { if (p.dead || !p.connected) continue; float d = sq(p.x - x) + sq(p.y - y); if (d < bd) { bd = d; b = &p; } } return b ? b : &players[0]; }
static Player* randomAlive() { std::vector<Player*> v; for (auto& p : players) if (!p.dead && p.connected) v.push_back(&p); return v.empty() ? &players[0] : v[irnd((int)v.size())]; }
static bool allDead() { for (auto& p : players) if (p.connected && !p.dead) return false; return true; }
static float camX = 0, camY = 0, camPunch = 0, baseZoom = 1;
static std::vector<std::vector<Enemy*>> gridCells; static const int GW = 48, GH = 32;   // spatial hash covering the arena
static inline float viewZoom() { return baseZoom * (1 + camPunch); }
static inline int cellX(float x) { return (int)clampf(floorf((x - WX0) / CELL), 0, GW - 1); }
static inline int cellY(float y) { return (int)clampf(floorf((y - WY0) / CELL), 0, GH - 1); }

static float xpFor(int l) { return floorf(22 + l * 15 + l * l * 1.9f); }
static uint32_t waveColor(int w) { return WAVE_COLS[(((w - 1) % 8) + 8) % 8]; }   // safe for any input, including a bad wave number from the network

// ============================================================================
//  input state
// ============================================================================
struct Input { float mx = 0, my = 0, ang = 0; bool fire = false, dash = false, sudo = false; };
static bool mouseSeen = false, mouseDown = false; static float mouseX = 0, mouseY = 0;
static SDL_GameController* pad = nullptr;
static bool quitRequested = false;
static bool AUTOPLAY = false, BOTS = false;   // dev flags: AI drives the local player / the other players

// ============================================================================
//  effects
// ============================================================================
static void addPart(float x, float y, float vx, float vy, float life, float size, uint32_t col, float drag = 0.92f) {
    if (parts.size() > 1400) return;
    parts.push_back({ x, y, vx, vy, life, life, size, col, drag, false });
}
static void burst(float x, float y, uint32_t col, int n, float spd, float life, float size) {
    for (int i = 0; i < n; i++) { float a = rndr(0, TAU), s = rndr(0.25f, 1) * spd; addPart(x, y, cosf(a) * s, sinf(a) * s, rndr(0.6f, 1) * life, size * rndr(0.6f, 1.3f), col); }
}
static void spawnShards(float x, float y, uint32_t col, int n, float spd, float len) {
    for (int i = 0; i < n; i++) {
        if (shards.size() > 400) return;
        float a = rndr(0, TAU), v = rndr(0.3f, 1) * spd;
        shards.push_back({ x, y, cosf(a) * v, sinf(a) * v, rndr(0, TAU), rndr(-9, 9), len * rndr(0.5f, 1.3f), rndr(0.5f, 1.0f), 1.0f, col, false });
        shards.back().max = shards.back().life;
    }
}
static void ringFx(float x, float y, float mx, float life, uint32_t col, float w = 4) { netEvRing(x, y, mx, col); if (rings.size() > 300) return; rings.push_back({ x, y, mx, life, 0, w, col, false }); }
static void floatText(float x, float y, const std::string& s, uint32_t col, float size = 2.f) {
    if (texts.size() > 60) return;
    FText t; t.x = x + rndr(-8, 8); t.y = y; t.life = t.max = 0.8f; t.size = size; t.col = col; t.dead = false; snprintf(t.s, sizeof t.s, "%s", s.c_str()); texts.push_back(t);
}
static void addShake(float a) { netEvShake(a); G.shake = std::max(G.shake, CFG.shake ? a : 0.f); }
static void banner(const std::string& t, const std::string& sub, uint32_t col) { netBanner(t, sub, col); G.banner.on = true; G.banner.t = 0; G.banner.dur = 2.4f; G.banner.text = t; G.banner.sub = sub; G.banner.col = col; }
static std::vector<Pt> jag(const std::vector<Pt>& pts) {
    std::vector<Pt> out;
    for (size_t i = 0; i + 1 < pts.size(); i++) {
        Pt a = pts[i], b = pts[i + 1]; float dx = b.x - a.x, dy = b.y - a.y, l = sqrtf(dx * dx + dy * dy); if (l < 1e-3f) l = 1; float nx = -dy / l, ny = dx / l;
        out.push_back(a);
        for (int k = 1; k < 5; k++) { float f = k / 5.f, j = rndr(-14, 14); out.push_back({ a.x + dx * f + nx * j, a.y + dy * f + ny * j }); }
    }
    if (!pts.empty()) out.push_back(pts.back());
    return out;
}
static void rumble(float lo, float hi, int ms) { if (pad) SDL_GameControllerRumble(pad, (Uint16)(lo * 65535), (Uint16)(hi * 65535), ms); }

static void fireEvent(const char* name, const std::string& title, const std::string& body, int urgency, uint32_t color) {
    EventInfo e; e.name = name; e.title = title; e.body = body; e.urgency = urgency; e.color = color;
    e.wave = G.wave; e.score = (long)G.score; e.kills = G.kills; e.level = P.level; e.hpPct = 100.f * P.hp / P.maxhp; e.time = G.time;
    if (boss && !boss->dead) e.boss = BOSS_NAMES[boss->kind];
    if (G.demo) return;   // the attract-mode demo never talks to your desktop
    emitEvent(e);
}

// ============================================================================
//  player actions
// ============================================================================
static void setState(State s);
static void hurtEnemy(Enemy& e, float dmg, float kx, float ky, bool crit);

static Enemy* nearestEnemy(float x, float y, float maxD) {
    Enemy* best = nullptr; float bd = maxD * maxD;
    for (auto& e : enemies) { if (e.dead) continue; float dx = e.x - x, dy = e.y - y, d = dx * dx + dy * dy; if (d < bd) { bd = d; best = &e; } }
    return best;
}
static void shootBullets(float ang) {
    int n = P.st.count; const float spread = 0.11f;
    for (int i = 0; i < n; i++) {
        float a = ang + (i - (n - 1) / 2.f) * spread + rndr(-0.02f, 0.02f); bool crit = rnd01() < P.st.crit;
        Bullet b; b.x = P.x + cosf(a) * 16; b.y = P.y + sinf(a) * 16; b.vx = cosf(a) * 840; b.vy = sinf(a) * 840; b.r = 5; b.life = 0.95f; b.dmg = P.st.dmg * (crit ? 2.2f : 1.f);
        b.crit = crit; b.dead = false; b.pierce = P.st.pierce; b.nh = 0; b.hom = P.st.homing; b.owner = P.idx; bullets.push_back(b);
    }
    P.vx -= cosf(ang) * 14; P.vy -= sinf(ang) * 14;
    addPart(P.x + cosf(ang) * 18, P.y + sinf(ang) * 18, cosf(ang) * 200 + rndr(-60, 60), sinf(ang) * 200 + rndr(-60, 60), 0.12f, 5, 0x9ff3ff);
    sfx(S_SHOOT);
}
static void gameOverNow();
static void hitStop(float sec) { if (MP()) return; G.hitstop = std::max(G.hitstop, sec); }   // freezing the host would stutter every client
static void netEvHurt(int idx);
static void killPlayerP(Player& p) {
    if (G.state != ST_PLAY || p.dead) return;
    p.dead = true; p.hp = 0; p.respawnT = 9.f; bool local = &p == &players[localIdx];
    burst(p.x, p.y, p.col, 70, 420, 1.0f, 6); burst(p.x, p.y, 0xffffff, 25, 300, 0.7f, 4); spawnShards(p.x, p.y, p.col, 26, 380, 16);
    ringFx(p.x, p.y, 500, 0.8f, p.col, 8);
    sfx(S_DIE); if (local) rumble(1, 1, 500);
    if (allDead()) { addShake(32); G.flash = 0.7f; G.timeScale = MP() ? 1.f : 0.25f; G.deathT = MP() ? 0.8f : 1.7f; setState(ST_DYING); }
    else { addShake(14); floatText(p.x, p.y - 30, "DOWN! REVIVE IN 9S", 0xff8fa0, 2.4f); }
}
static void hurtPlayerP(Player& p, float dmg, float nx, float ny) {   // (nx, ny) points from the player toward the source of the damage
    if (G.demo || p.dead || p.iframes > 0 || p.dashT > 0) return;
    bool local = &p == &players[localIdx];
    p.hp -= dmg; p.iframes = 0.7f; if (local) { G.hurt = 1; } addShake(local ? 11.f : 5.f); hitStop(0.05f);
    p.vx -= nx * 260; p.vy -= ny * 260;
    burst(p.x, p.y, 0xff5f7e, 14, 260, 0.5f, 4);
    sfx(S_HURT); if (local) rumble(0.6f, 0.9f, 180);
    netEvHurt(p.idx);
    if (p.hp <= 0) killPlayerP(p);
}
static void gainXP(Player& p, float v) {
    p.xp += v;
    while (p.xp >= p.xpNeed) { p.xp -= p.xpNeed; p.level++; p.xpNeed = xpFor(p.level); p.pending++; ringFx(p.x, p.y, 160, 0.5f, 0xc084fc, 5); }
}
static void novaBlast(float x, float y, float R, float dmg, uint32_t col) {
    ringFx(x, y, R, 0.5f, col, 6);
    for (size_t i = 0; i < enemies.size(); i++) {
        Enemy& e = enemies[i]; if (e.dead) continue;
        float dx = e.x - x, dy = e.y - y, d = sqrtf(dx * dx + dy * dy);
        if (d < R + e.r) { hurtEnemy(e, dmg, dx, dy, false); if (e.type != T_BOSS) { e.vx += dx / (d + 0.001f) * 320; e.vy += dy / (d + 0.001f) * 320; } }
    }
    for (auto& b : ebul) if (sq(b.x - x) + sq(b.y - y) < R * R) { b.dead = true; addPart(b.x, b.y, 0, 0, 0.25f, 6, 0xffffff); }
}
static void fireSudo() {
    if (G.sudo < 100 || G.state != ST_PLAY) return;
    G.sudo = 0; G.sudoReady = false;
    ringFx(P.x, P.y, 900, 0.7f, 0xc084fc, 12); ringFx(P.x, P.y, 700, 0.55f, 0xffffff, 5);
    addShake(28); hitStop(0.08f); G.flash = 0.55f; camPunch = 0.1f; sfx(S_SUDO); rumble(1, 1, 350);
    floatText(P.x, P.y - 40, "SUDO RM -RF MALWARE", 0xe9d5ff, 2.6f);
    for (size_t i = 0; i < enemies.size(); i++) { Enemy& e = enemies[i]; if (e.dead) continue; float dx = e.x - P.x, dy = e.y - P.y; if (dx * dx + dy * dy < 820.f * 820.f) hurtEnemy(e, 260 + P.level * 14, dx, dy, false); }
    for (auto& b : ebul) b.dead = true;
    lasers.clear();
    fireEvent("sudo", "SUDO RM -RF MALWARE", fmt("Screen wiped. Wave %d, score %s.", G.wave, fmtNum((long)G.score).c_str()), 0, 0xc084fc);
}

// ============================================================================
//  enemies
// ============================================================================
static Enemy& makeEnemy(int type, float x, float y, bool elite) {
    const TypeDef& T = TD[type]; float w = (float)G.wave, hpM = (1 + (w - 1) * 0.24f) * (1.f + 0.35f * (float)(players.size() - 1)), spM = 1 + std::min(0.5f, (w - 1) * 0.03f);
    Enemy e; e.id = nextId++; e.type = type; e.x = x; e.y = y; e.r = T.r * (elite ? 1.3f : 1); e.hp = T.hp * hpM * (elite ? 2.8f : 1); e.maxhp = e.hp;
    e.spd = T.spd * spM * (elite ? 0.9f : 1); e.dmg = T.dmg * (1 + (w - 1) * 0.05f); e.col = T.col; e.t = rndr(0, 10); e.elite = elite; e.dir = rnd01() < 0.5f ? 1 : -1;
    e.fireT = rndr(0.5f, 1.8f); e.st = rndr(1, 2); e.fuse = -1;
    enemies.push_back(e); return enemies.back();
}
static bool spawnPos(float margin, float& ox, float& oy) {
    float z = viewZoom(), vr = sqrtf((float)(GX.W * GX.W + GX.H * GX.H)) / 2 / z + margin;
    for (int k = 0; k < 8; k++) {
        Player& c0 = *randomAlive(); float a = rndr(0, TAU), x = c0.x + cosf(a) * vr, y = c0.y + sinf(a) * vr;
        if (x > WX0 + 30 && x < WX1 - 30 && y > WY0 + 30 && y < WY1 - 30) { ox = x; oy = y; return true; }
    }
    return false;
}
static void refreshBoss() { boss = nullptr; for (auto& e : enemies) if (e.type == T_BOSS && !e.dead) boss = &e; }
static void spawnBoss() {
    G.bossCount++; int kind = (G.bossCount - 1) % 3; float x, y; if (!spawnPos(160, x, y)) { Player& c0 = *randomAlive(); x = c0.x + 500; y = c0.y; }
    Enemy& b = makeEnemy(T_BOSS, x, y, false);
    b.kind = kind; b.col = BOSS_COLS[kind];
    b.hp = b.maxhp = (1800 + G.wave * 150) * (1 + (G.bossCount - 1) * 0.3f) * (1 + (G.wave - 1) * 0.24f) * (1.f + 0.6f * (float)(players.size() - 1));
    b.intro = 1.4f; b.atk = 1.5f; b.sumT = 5; b.phase = 1; b.fuse = 3.5f;
    boss = &b; G.bossAlive = true; camPunch = -0.06f; ringFx(b.x, b.y, 300, 0.8f, b.col, 8);
}
static void ebullet(float x, float y, float dx, float dy, float sp, float dmg, uint32_t col, float r = 7) {
    if (ebul.size() > 460) return;
    ebul.push_back({ x, y, dx * sp, dy * sp, r, dmg, 7, false, col });
}
static void summon(float x, float y, int n, int type) {
    for (int i = 0; i < n; i++) { float a = rndr(0, TAU); Enemy& e = makeEnemy(type, x + cosf(a) * 70, y + sinf(a) * 70, false); e.vx = cosf(a) * 260; e.vy = sinf(a) * 260; }
}
static void addLaser(float x, float y, float ang, float tel, uint32_t col) { lasers.push_back({ x, y, ang, 0, tel, 0.35f, false, false, col }); }
static void updateBoss(Enemy& e, float dt, float nx, float ny, float d) {
    float ratio = e.hp / e.maxhp; e.phase = ratio > 0.66f ? 1 : ratio > 0.33f ? 2 : 3; int ph = e.phase;
    float tx, ty, sp = e.spd * (1 + (ph - 1) * 0.25f);
    if (d > 380) { tx = nx; ty = ny; } else if (d < 250) { tx = -nx; ty = -ny; } else { tx = -ny * e.dir; ty = nx * e.dir; sp *= 0.8f; }
    e.vx = lerpf(e.vx, tx * sp, clampf(3 * dt, 0, 1)); e.vy = lerpf(e.vy, ty * sp, clampf(3 * dt, 0, 1));
    e.atk -= dt; e.sumT -= dt; e.spin += dt * (1 + ph); e.fuse -= dt;
    uint32_t bc = e.kind == 0 ? 0xff4d8d : e.kind == 1 ? 0x4dffd9 : 0xffd94d;
    if (ph == 1 && e.atk <= 0) {
        e.atk = 1.7f; int n = 14; float off = rndr(0, TAU);
        for (int i = 0; i < n; i++) { float a = off + i / (float)n * TAU; ebullet(e.x, e.y, cosf(a), sinf(a), 200, 12, bc); }
        sfx(S_ZAP);
    } else if (ph == 2) {
        if (e.atk <= 0) {
            e.atk = 1.3f; float base = atan2f(ny, nx);
            for (int i = -1; i <= 1; i++) ebullet(e.x, e.y, cosf(base + i * 0.2f), sinf(base + i * 0.2f), 300, 12, bc);
            if (rnd01() < 0.5f) { float off = rndr(0, TAU); for (int i = 0; i < 10; i++) { float a = off + i / 10.f * TAU; ebullet(e.x, e.y, cosf(a), sinf(a), 190, 11, bc); } }
        }
        if (e.sumT <= 0) { e.sumT = 6; summon(e.x, e.y, 5, T_WORM); ringFx(e.x, e.y, 200, 0.4f, e.col, 5); }
    } else if (ph == 3) {
        if (e.atk <= 0) { e.atk = 0.085f; float a = e.spin * 3; ebullet(e.x, e.y, cosf(a), sinf(a), 230, 10, bc, 6); ebullet(e.x, e.y, cosf(a + PI), sinf(a + PI), 230, 10, bc, 6); }
        if (e.sumT <= 0) { e.sumT = 5; summon(e.x, e.y, 6, rnd01() < 0.4f ? T_SPY : T_WORM); }
    }
    if (e.kind == 2 && ph >= 2 && e.fuse <= 0) {   // SEGFAULT: telegraphed laser sweeps
        e.fuse = ph == 3 ? 2.2f : 3.4f;
        float base = atan2f(ny, nx); int n = ph == 3 ? 3 : 2;
        for (int i = 0; i < n; i++) addLaser(e.x, e.y, base + (i - (n - 1) / 2.f) * 0.55f, 0.9f, bc);
        sfx(S_BOSS);
    }
}
static void explodeBomb(Enemy& e) {
    e.dead = true; float R = 130;
    ringFx(e.x, e.y, R, 0.45f, 0xff8a3d, 8); burst(e.x, e.y, 0xff8a3d, 40, 340, 0.6f, 6); burst(e.x, e.y, 0xffffff, 10, 220, 0.3f, 4); addShake(12); sfx(S_BOOM);
    for (auto& pl : players) if (!pl.dead && sq(pl.x - e.x) + sq(pl.y - e.y) < sq(R + pl.r)) hurtPlayerP(pl, 24 + G.wave * 1.2f, (e.x - pl.x) / R, (e.y - pl.y) / R);
    for (size_t i = 0; i < enemies.size(); i++) { Enemy& o = enemies[i]; if (o.dead || &o == &e || o.type == T_BOSS) continue; if (sq(o.x - e.x) + sq(o.y - e.y) < R * R) hurtEnemy(o, 60, o.x - e.x, o.y - e.y, false); }
}
static void updateEnemy(Enemy& e, float dt) {
    Player& T = *nearestPlayer(e.x, e.y); float dx = T.x - e.x, dy = T.y - e.y, d = sqrtf(dx * dx + dy * dy) + 0.0001f, nx = dx / d, ny = dy / d;
    e.t += dt; e.flash = std::max(0.f, e.flash - dt); e.orbCd -= dt;
    if (e.intro > 0) { e.intro -= dt; if (e.type == T_BOSS) return; }
    float sp = e.spd, tx = nx, ty = ny, contact = e.dmg;
    switch (e.type) {
        case T_WORM: { float w = sinf(e.t * 5 + e.id) * 0.5f; tx = nx - ny * w; ty = ny + nx * w; break; }
        case T_RANSOM: { float w = sinf(e.t * 2 + e.id) * 0.25f; tx = nx - ny * w; ty = ny + nx * w; break; }
        case T_SPY:
            if (d < 250) { tx = -nx; ty = -ny; } else if (d < 350) { tx = -ny * e.dir; ty = nx * e.dir; sp *= 0.7f; }
            e.fireT -= dt;
            if (e.fireT <= 0 && d < 720 && !G.demo) { e.fireT = 1.9f + rndr(0, 0.5f); ebullet(e.x, e.y, nx, ny, 250, 10, 0xffd94d, 6); addPart(e.x, e.y, nx * 60, ny * 60, 0.2f, 6, 0xffe14d); }
            break;
        case T_CHARGER:
            e.st -= dt;
            if (e.state == 0) { if (d < 480 && e.st <= 0) { e.state = 1; e.st = 0.75f; } }
            else if (e.state == 1) { sp = 0; if (e.st > 0.3f) { e.cx = nx; e.cy = ny; } if (e.st <= 0) { e.state = 2; e.st = 0.55f; } }
            else if (e.state == 2) { sp = 0; e.vx = e.cx * 560; e.vy = e.cy * 560; contact = e.dmg * 1.2f; if (e.st <= 0) { e.state = 3; e.st = 0.6f; } }
            else { sp = 0; if (e.st <= 0) { e.state = 0; e.st = rndr(1.2f, 2.2f); } }
            break;
        case T_BOMB:
            if (e.fuse < 0 && d < 200) e.fuse = 1.1f;
            if (e.fuse >= 0) { e.fuse -= dt; sp *= 0.35f; if (e.fuse <= 0) { explodeBomb(e); return; } }
            contact = 0; break;
        case T_BOSS: updateBoss(e, dt, nx, ny, d); break;
    }
    if (e.type != T_BOSS && !(e.type == T_CHARGER && e.state == 2)) { e.vx = lerpf(e.vx, tx * sp, clampf(5 * dt, 0, 1)); e.vy = lerpf(e.vy, ty * sp, clampf(5 * dt, 0, 1)); }
    e.x = clampf(e.x + e.vx * dt, WX0 + e.r, WX1 - e.r); e.y = clampf(e.y + e.vy * dt, WY0 + e.r, WY1 - e.r);
    if (contact > 0) for (auto& pl : players) { if (pl.dead) continue; float ddx = pl.x - e.x, ddy = pl.y - e.y, dd = sqrtf(ddx * ddx + ddy * ddy) + 1e-4f; if (dd < pl.r + e.r - 2) hurtPlayerP(pl, contact, -ddx / dd, -ddy / dd); }
}
static void killEnemy(Enemy& e) {
    if (e.dead) return;
    e.dead = true; const TypeDef& T = TD[e.type]; bool isBoss = e.type == T_BOSS; netEvKill(e.x, e.y, e.type, e.elite);
    uint32_t col = e.col;
    burst(e.x, e.y, col, isBoss ? 110 : e.r > 18 ? 28 : 14, 260 + e.r * 4, 0.65f, 5); burst(e.x, e.y, 0xffffff, isBoss ? 30 : 6, 200, 0.35f, 3);
    ringFx(e.x, e.y, e.r * 3 + 24, 0.35f, col, 3);
    spawnShards(e.x, e.y, col, isBoss ? 46 : e.r > 18 ? 12 : 7, 240 + e.r * 3, e.r * 0.7f + 4);
    if (!G.demo) {
        G.streak++; G.comboT = 2.6f; G.combo = std::min(10, 1 + G.streak / 6);
        G.score += T.val * (e.elite ? 3 : 1) * G.combo; G.kills++;
        if (!isBoss && G.sudo < 100) { G.sudo = std::min(100.f, G.sudo + T.xp * 1.1f + 1.2f); if (G.sudo >= 100 && !G.sudoReady) { G.sudoReady = true; sfx(S_READY); floatText(P.x, P.y - 40, "SUDO READY", 0xe9d5ff, 2.4f); } }
    }
    float gv = T.xp * (e.elite ? 3 : 1); int n = isBoss ? 26 : (int)std::min(3.f, std::max(1.f, roundf(gv)));
    for (int i = 0; i < n; i++) {
        if (gems.size() > 320) { if (!G.demo) gainXP(*nearestPlayer(e.x, e.y), gv / n); continue; }
        float a = rndr(0, TAU), s = rndr(60, isBoss ? 420 : 200); gems.push_back({ e.x, e.y, cosf(a) * s, sinf(a) * s, gv / n, 0, false, false });
    }
    if (e.type == T_RANSOM) for (int i = 0; i < 3; i++) { float a = rndr(0, TAU); Enemy& w = makeEnemy(T_WORM, e.x, e.y, false); w.vx = cosf(a) * 240; w.vy = sinf(a) * 240; }
    if (e.elite || isBoss) { hitStop(isBoss ? 0.14f : 0.05f); addShake(isBoss ? 30 : 10); }
    sfx(S_KILL);
    if (isBoss) {
        Enemy* other = nullptr; for (auto& o : enemies) if (o.type == T_BOSS && !o.dead && &o != &e) other = &o;
        boss = other; G.bossAlive = other != nullptr; G.flash = 0.5f; camPunch = 0.08f; rumble(1, 1, 400);
        if (!G.demo) { for (auto& pl : players) { pl.hp = std::min(pl.maxhp, pl.hp + pl.maxhp * 0.4f); if (pl.dead) pl.respawnT = std::min(pl.respawnT, 1.5f); } banner("ROOTKIT PURGED", "+40% HP RESTORED", 0x4ade80);
            fireEvent("bossdead", fmt("ROOTKIT PURGED - %s", BOSS_NAMES[e.kind]), fmt("+40%% HP restored. Score %s.", fmtNum((long)G.score).c_str()), 1, 0x4ade80); }
        for (auto& b : ebul) b.dead = true; lasers.clear();
        ringFx(e.x, e.y, 700, 0.8f, col, 10);
    }
}
static void hurtEnemy(Enemy& e, float dmg, float kx, float ky, bool crit) {
    if (e.dead || e.intro > 0) return;
    e.hp -= dmg; e.flash = 0.09f; netEvHit(e.x, e.y, dmg, crit);
    float kb = e.type == T_BOSS ? 0 : e.type == T_TROJAN ? 40 : 120, l = sqrtf(kx * kx + ky * ky) + 0.0001f; e.vx += kx / l * kb; e.vy += ky / l * kb;
    addPart(e.x, e.y, rndr(-100, 100), rndr(-100, 100), 0.25f, 3, crit ? 0xffe14d : 0xffffff);
    if (crit || rnd01() < 0.35f) floatText(e.x, e.y - e.r, std::to_string((int)roundf(dmg)), crit ? 0xffe14d : 0xffffff, crit ? 3.f : 2.f);
    sfx(S_HIT);
    if (e.hp <= 0) killEnemy(e);
}

// ============================================================================
//  director + world update
// ============================================================================
static void director(float dt) {
    if (!G.demo && G.state == ST_PLAY) {
        int w = 1 + (int)(G.time / 30);
        if (w > G.wave) {
            G.wave = w; G.accent = waveColor(w); banner(fmt("WAVE %d", w), "MALWARE SIGNATURES UPDATED", G.accent); sfx(S_WAVE);
            fireEvent("wave", fmt("KERNEL PANIC - WAVE %d", w), fmt("Malware signatures updated. Score %s, HP %.0f%%.", fmtNum((long)G.score).c_str(), 100.f * P.hp / P.maxhp), 1, G.accent);
            if (w % 5 == 0) {
                G.bossT = 2.6f; banner("WARNING", "ROOTKIT DETECTED", 0xff4d6d); sfx(S_BOSS);
                fireEvent("boss", "ROOTKIT DETECTED", fmt("Boss incoming on wave %d. Brace for impact.", w), 2, 0xff4d6d);
            }
        }
        if (G.bossT > 0) { G.bossT -= dt; if (G.bossT <= 0) { if (G.bossAlive) G.bossT = 3; else spawnBoss(); } }
        if (G.wave >= 3) {
            G.swarmT -= dt;
            if (G.swarmT <= 0) {
                G.swarmT = 42; banner("SWARM DETECTED", "GET OUT OF THE CIRCLE", 0xffa940);
                float z = viewZoom(), vr = sqrtf((float)(GX.W * GX.W + GX.H * GX.H)) / 2 / z + 40;
                for (int i = 0; i < 26; i++) { Player& c0 = *nearestPlayer(0, 0); float a = i / 26.f * TAU, x = c0.x + cosf(a) * vr, y = c0.y + sinf(a) * vr; if (x > WX0 + 20 && x < WX1 - 20 && y > WY0 + 20 && y < WY1 - 20) makeEnemy(T_WORM, x, y, false); }
            }
        }
    }
    G.spawnT -= dt; if (G.spawnT > 0) return;
    int w = G.wave;
    G.spawnT = std::max(0.16f, 1.05f - w * 0.065f) / (1.f + 0.5f * (float)(players.size() - 1)) * (G.bossAlive ? 2.2f : 1.f) * (G.demo ? 2.6f : 1.f);
    if ((int)enemies.size() > (G.demo ? 32 : 260)) return;
    int n = 1 + w / 4 + (rnd01() < 0.25f ? 1 : 0);
    std::vector<int> pool = { T_WORM, T_WORM, T_WORM };
    if (w >= 2) pool.push_back(T_TROJAN); if (w >= 3) { pool.push_back(T_SPY); pool.push_back(T_WORM); } if (w >= 4) pool.push_back(T_RANSOM);
    if (w >= 5) { pool.push_back(T_CHARGER); pool.push_back(T_CHARGER); } if (w >= 6) pool.push_back(T_BOMB);
    for (int i = 0; i < n; i++) { float x, y; if (!spawnPos(50, x, y)) continue; makeEnemy(pool[irnd((int)pool.size())], x, y, w >= 3 && rnd01() < 0.04f + w * 0.004f); }
}
static void buildGrid() {
    if (gridCells.empty()) gridCells.resize(GW * GH);
    for (auto& c : gridCells) c.clear();
    for (auto& e : enemies) if (!e.dead && e.type != T_BOSS) gridCells[cellY(e.y) * GW + cellX(e.x)].push_back(&e);
}
static void separate(float dt) {
    for (auto& e : enemies) {
        if (e.dead || e.type == T_BOSS) continue;
        int cx = cellX(e.x), cy = cellY(e.y);
        for (int oy = -1; oy <= 1; oy++) for (int ox = -1; ox <= 1; ox++) {
            int gx = cx + ox, gy = cy + oy; if (gx < 0 || gy < 0 || gx >= GW || gy >= GH) continue;
            for (Enemy* o : gridCells[gy * GW + gx]) {
                if (o->id <= e.id) continue;
                float ddx = o->x - e.x, ddy = o->y - e.y, rr = e.r + o->r, d2 = ddx * ddx + ddy * ddy;
                if (d2 < rr * rr && d2 > 0.01f) { float d = sqrtf(d2), push = (rr - d) * 0.5f * std::min(1.f, dt * 12), nx = ddx / d, ny = ddy / d; e.x -= nx * push; e.y -= ny * push; o->x += nx * push; o->y += ny * push; }
            }
        }
    }
}
static void chainZap() {
    Enemy* first = nearestEnemy(P.x, P.y, 400); if (!first) return;
    float dmg = 16 + 10 * P.st.chain; std::vector<Pt> pts = { { P.x, P.y }, { first->x, first->y } }; std::vector<int> hit = { first->id };
    hurtEnemy(*first, dmg, first->x - P.x, first->y - P.y, false);
    Enemy* cur = first; float cx = first->x, cy = first->y;
    for (int k = 0; k < 1 + P.st.chain; k++) {
        Enemy* best = nullptr; float bd = 250 * 250;
        for (auto& e : enemies) { if (e.dead || std::find(hit.begin(), hit.end(), e.id) != hit.end()) continue; float d = sq(e.x - cx) + sq(e.y - cy); if (d < bd) { bd = d; best = &e; } }
        if (!best) break;
        hit.push_back(best->id); pts.push_back({ best->x, best->y }); hurtEnemy(*best, dmg, best->x - cx, best->y - cy, false); cur = best; cx = best->x; cy = best->y;
    }
    (void)cur;
    netEvBeam(pts); beams.push_back({ jag(pts), 0.16f, 0.16f, false }); sfx(S_ZAP);
}
static Input readInput();
static Input demoInput() {
    Input in; float a = G.t * 0.55f + P.idx * 2.1f, tx = cosf(a) * 380, ty = sinf(a * 1.3f) * 240;
    in.mx = (tx - P.x) / 160; in.my = (ty - P.y) / 160; in.ang = P.ang;
    Enemy* n = nearestEnemy(P.x, P.y, 700);
    if (n) {
        in.ang = atan2f(n->y - P.y, n->x - P.x); in.fire = true;
        float dx = n->x - P.x, dy = n->y - P.y, d = sqrtf(dx * dx + dy * dy) + 0.001f;
        if (d < 170) { in.mx -= dx / d * 1.6f; in.my -= dy / d * 1.6f; } if (d < 70) in.dash = true;
    }
    return in;
}
static void updateFx(float dt) {
    for (auto& q : parts) { q.life -= dt; float f = powf(q.drag, dt * 60); q.vx *= f; q.vy *= f; q.x += q.vx * dt; q.y += q.vy * dt; if (q.life <= 0) q.dead = true; }
    for (auto& t : texts) { t.life -= dt; t.y -= 60 * dt; if (t.life <= 0) t.dead = true; }
    for (auto& r : rings) { r.t += dt; if (r.t >= r.life) r.dead = true; }
    for (auto& b : beams) { b.life -= dt; if (b.life <= 0) b.dead = true; }
    for (auto& h : shards) { h.life -= dt; float f = powf(0.94f, dt * 60); h.vx *= f; h.vy *= f; h.x += h.vx * dt; h.y += h.vy * dt; h.rot += h.vr * dt; if (h.life <= 0) h.dead = true; }

    parts.erase(std::remove_if(parts.begin(), parts.end(), [](const Part& b) { return b.dead; }), parts.end());
    texts.erase(std::remove_if(texts.begin(), texts.end(), [](const FText& b) { return b.dead; }), texts.end());
    rings.erase(std::remove_if(rings.begin(), rings.end(), [](const RingFx& b) { return b.dead; }), rings.end());
    beams.erase(std::remove_if(beams.begin(), beams.end(), [](const Beam& b) { return b.dead; }), beams.end());
    shards.erase(std::remove_if(shards.begin(), shards.end(), [](const Shard& b) { return b.dead; }), shards.end());
}
static void updateCamera(float dt) {
    float z = viewZoom(), vw = GX.W / z, vh = GX.H / z, lead = P.dead ? 0.f : 50.f;
    camX = lerpf(camX, P.x + cosf(P.ang) * lead, clampf(7 * dt, 0, 1)); camY = lerpf(camY, P.y + sinf(P.ang) * lead, clampf(7 * dt, 0, 1));
    camX = vw >= WX1 - WX0 ? 0 : clampf(camX, WX0 + vw / 2, WX1 - vw / 2); camY = vh >= WY1 - WY0 ? 0 : clampf(camY, WY0 + vh / 2, WY1 - vh / 2);

}
static void openLevelUp();
static void startOffer(Player& p);
static void answerOffer(Player& p, int k);
static void updatePlayer(float dt, const Input& in) {
        P.ang = in.ang;
        float mx = in.mx, my = in.my, ml = sqrtf(mx * mx + my * my); if (ml > 1) { mx /= ml; my /= ml; }
        P.iframes = std::max(0.f, P.iframes - dt); P.dashCd = std::max(0.f, P.dashCd - dt);
        if (in.dash && P.dashCd <= 0 && P.dashT <= 0) {
            float dx = mx, dy = my; if (sqrtf(dx * dx + dy * dy) < 0.1f) { dx = cosf(P.ang); dy = sinf(P.ang); }
            float l = sqrtf(dx * dx + dy * dy) + 0.0001f; P.dashDx = dx / l; P.dashDy = dy / l;
            P.dashT = 0.17f; P.dashCd = P.st.dashCd; P.iframes = std::max(P.iframes, 0.3f); P.dashId++; sfx(S_DASH); addShake(5);
        }
        if (P.dashT > 0) {
            P.dashT -= dt; P.vx = P.dashDx * 1500; P.vy = P.dashDy * 1500;
            addPart(P.x, P.y, rndr(-30, 30), rndr(-30, 30), 0.3f, 10, 0x67e8f9, 0.85f);
            for (size_t i = 0; i < enemies.size(); i++) {
                Enemy& e = enemies[i]; if (e.dead || e.dashId == P.dashId) continue;
                float dx = e.x - P.x, dy = e.y - P.y, rr = e.r + P.r + 12;
                if (dx * dx + dy * dy < rr * rr) { e.dashId = P.dashId; hurtEnemy(e, P.st.dmg * 3 + 20, P.dashDx, P.dashDy, false); }
            }
        } else {
            float f = clampf(14 * dt, 0, 1); P.vx = lerpf(P.vx, mx * P.st.speed, f); P.vy = lerpf(P.vy, my * P.st.speed, f);
            if (ml > 0.2f && rnd01() < 0.6f) addPart(P.x - cosf(P.ang) * 10, P.y - sinf(P.ang) * 10, -P.vx * 0.2f + rndr(-20, 20), -P.vy * 0.2f + rndr(-20, 20), 0.25f, 5, 0x7c3aed);
        }
        P.x = clampf(P.x + P.vx * dt, WX0 + P.r, WX1 - P.r); P.y = clampf(P.y + P.vy * dt, WY0 + P.r, WY1 - P.r);
        if (P.st.regen > 0) P.hp = std::min(P.maxhp, P.hp + P.st.regen * dt);
        P.fireCd -= dt; if (in.fire && P.fireCd <= 0) { shootBullets(P.ang); P.fireCd = 1 / P.st.rate; }
        if (in.sudo) fireSudo();
        if (P.st.orbit > 0) {
            P.orbAng += dt * 3.2f;
            for (int i = 0; i < P.st.orbit; i++) {
                float a = P.orbAng + i * TAU / P.st.orbit, ox = P.x + cosf(a) * 70, oy = P.y + sinf(a) * 70;
                for (size_t k = 0; k < enemies.size(); k++) {
                    Enemy& e = enemies[k]; if (e.dead || e.orbCd > 0) continue;
                    float dx = e.x - ox, dy = e.y - oy, rr = e.r + 15;
                    if (dx * dx + dy * dy < rr * rr) { e.orbCd = 0.22f; hurtEnemy(e, 9 + P.st.dmg * 0.9f, dx, dy, false); }
                }
                for (auto& b : ebul) if (sq(b.x - ox) + sq(b.y - oy) < 400) { b.dead = true; addPart(b.x, b.y, 0, 0, 0.2f, 6, 0xffffff); }
            }
        }
        if (P.st.chain > 0) { P.chainT -= dt; if (P.chainT <= 0) { P.chainT = 1.5f / (1 + 0.15f * P.st.chain); chainZap(); } }
        if (P.st.nova > 0) { P.novaT -= dt; if (P.novaT <= 0) { P.novaT = 3.6f / (1 + 0.12f * P.st.nova); novaBlast(P.x, P.y, 150 + 26 * P.st.nova, 22.f + 12 * P.st.nova, 0xa78bfa); sfx(S_KILL); } }
}
static Input remoteInput(const Player& me) {
    Input in; if (me.inAge > 0.5f) { in.ang = me.ang; return in; }   // stale (lost connection): stand still
    in.mx = me.inMx; in.my = me.inMy; in.ang = me.inAng; in.fire = me.inFire; in.dash = me.inDash; in.sudo = me.inSudo; return in;
}
static void updateDead(Player& me, float dt) {
    if (G.state != ST_PLAY || allDead()) return;
    me.respawnT -= dt; me.offer = false;
    if (me.respawnT <= 0) {
        Player* buddy = nearestPlayer(me.x, me.y); me.dead = false; me.hp = me.maxhp * 0.5f; me.iframes = 2.5f; me.x = buddy->x + 40; me.y = buddy->y; me.vx = me.vy = 0;
        ringFx(me.x, me.y, 240, 0.6f, me.col, 6); burst(me.x, me.y, me.col, 30, 300, 0.6f, 5); sfx(S_LEVEL);
    }
}
static void updateWorld(float dt) {
    G.t += dt; if (G.state == ST_PLAY && !G.demo) G.time += dt;
    G.hurt = std::max(0.f, G.hurt - dt * 2.2f); G.flash = std::max(0.f, G.flash - dt * 2.5f); G.beat = std::max(0.f, G.beat - dt * 4);
    if (G.comboT > 0) { G.comboT -= dt; if (G.comboT <= 0) { G.streak = 0; G.combo = 1; } }
    if (G.banner.on) { G.banner.t += dt; if (G.banner.t > G.banner.dur) G.banner.on = false; }
    G.intensity = G.demo ? 0 : (G.bossAlive || G.bossT > 0) ? 3 : G.wave >= 4 ? 2 : 1;
    refreshBoss();
    for (size_t pi = 0; pi < players.size(); pi++) {
        curP = &players[pi]; Player& me = players[pi];
        if (!me.connected) continue;
        me.inAge += dt;
        if (me.dead) { updateDead(me, dt); continue; }
        Input in;
        if ((int)pi == localIdx) in = (G.demo || AUTOPLAY) ? demoInput() : readInput(); else if (BOTS) in = demoInput(); else in = remoteInput(me);
        updatePlayer(dt, in);
    }
    curP = &players[localIdx];
    if (G.state == ST_PLAY || G.demo) director(dt);
    buildGrid();
    for (size_t i = 0; i < enemies.size(); i++) if (!enemies[i].dead) updateEnemy(enemies[i], dt);
    separate(dt);
    refreshBoss();

    // lasers (SEGFAULT boss)
    for (auto& L : lasers) {
        L.t += dt; float total = L.tel + L.fire; if (L.t > total) { L.dead = true; continue; }
        if (L.t > L.tel) for (auto& pl : players) {
            if (pl.dead) continue;
            float dx = cosf(L.ang), dy = sinf(L.ang), px = pl.x - L.x, py = pl.y - L.y, proj = px * dx + py * dy, perp = fabsf(px * dy - py * dx);
            if (proj > 0 && perp < 22 + pl.r) hurtPlayerP(pl, 20, -dy, dx);
        }
    }
    // player bullets
    for (auto& b : bullets) {
        if (b.hom > 0) {
            Enemy* t = nullptr; float bd = sq(260.f + 90 * b.hom);
            for (auto& e : enemies) { if (e.dead) continue; bool seen = false; for (int h = 0; h < b.nh; h++) if (b.hits[h] == e.id) seen = true; if (seen) continue; float d = sq(e.x - b.x) + sq(e.y - b.y); if (d < bd) { bd = d; t = &e; } }
            if (t) {
                float sp = sqrtf(b.vx * b.vx + b.vy * b.vy), a = atan2f(b.vy, b.vx), diff = atan2f(t->y - b.y, t->x - b.x) - a;
                while (diff > PI) diff -= TAU; while (diff < -PI) diff += TAU;
                a += clampf(diff, -2.6f * b.hom * dt, 2.6f * b.hom * dt); b.vx = cosf(a) * sp; b.vy = sinf(a) * sp;
            }
        }
        b.life -= dt;
        int steps = std::max(1, (int)ceilf(sqrtf(b.vx * b.vx + b.vy * b.vy) * dt / 12)); float sdt = dt / steps;
        for (int s = 0; s < steps && !b.dead; s++) {
            b.x += b.vx * sdt; b.y += b.vy * sdt;
            if (b.x < WX0 || b.x > WX1 || b.y < WY0 || b.y > WY1) { b.dead = true; burst(b.x, b.y, 0x67e8f9, 4, 120, 0.2f, 3); break; }
            int cx = cellX(b.x), cy = cellY(b.y);
            for (int oy = -1; oy <= 1 && !b.dead; oy++) for (int ox = -1; ox <= 1 && !b.dead; ox++) {
                int gx = cx + ox, gy = cy + oy; if (gx < 0 || gy < 0 || gx >= GW || gy >= GH) continue;
                for (Enemy* e : gridCells[gy * GW + gx]) {
                    if (e->dead) continue; bool seen = false; for (int h = 0; h < b.nh; h++) if (b.hits[h] == e->id) seen = true; if (seen) continue;
                    float rr = e->r + b.r, dx = e->x - b.x, dy = e->y - b.y;
                    if (dx * dx + dy * dy < rr * rr) {
                        hurtEnemy(*e, b.dmg, b.vx, b.vy, b.crit); if (b.nh < 8) b.hits[b.nh++] = e->id;
                        if (b.pierce <= 0) { b.dead = true; break; } b.pierce--;
                    }
                }
            }
            if (!b.dead && boss && !boss->dead) {
                bool seen = false; for (int h = 0; h < b.nh; h++) if (b.hits[h] == boss->id) seen = true;
                float rr = boss->r + b.r, dx = boss->x - b.x, dy = boss->y - b.y;
                if (!seen && dx * dx + dy * dy < rr * rr) { hurtEnemy(*boss, b.dmg, b.vx, b.vy, b.crit); if (b.nh < 8) b.hits[b.nh++] = boss->id; if (b.pierce <= 0) b.dead = true; else b.pierce--; }
            }
        }
        if (b.life <= 0) b.dead = true;
    }
    for (auto& b : ebul) {
        b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
        if (b.life <= 0 || b.x < WX0 - 50 || b.x > WX1 + 50 || b.y < WY0 - 50 || b.y > WY1 + 50) { b.dead = true; continue; }
        for (auto& pl : players) {
            if (pl.dead) continue;
            float dx = pl.x - b.x, dy = pl.y - b.y, rr = pl.r + b.r;
            if (dx * dx + dy * dy < rr * rr) { float l = sqrtf(dx * dx + dy * dy) + 0.001f; hurtPlayerP(pl, b.dmg, -dx / l, -dy / l); if (G.demo || pl.iframes > 0) { b.dead = true; burst(b.x, b.y, b.col, 6, 150, 0.3f, 3); break; } }
        }
    }
    for (auto& g : gems) {
        g.t += dt; float f = expf(-4 * dt); g.vx *= f; g.vy *= f;
        Player* tp = nullptr; float bd2 = 1e30f; for (auto& pl : players) { if (pl.dead || !pl.connected) continue; float d2 = sq(pl.x - g.x) + sq(pl.y - g.y); if (d2 < bd2) { bd2 = d2; tp = &pl; } }
        if (tp) {
            float dx = tp->x - g.x, dy = tp->y - g.y, mr = tp->st.magnet;
            if (bd2 < mr * mr || g.t > 24) g.mag = true;
            if (g.mag) { float d = sqrtf(bd2) + 0.001f; g.vx = lerpf(g.vx, dx / d * 640, clampf(10 * dt, 0, 1)); g.vy = lerpf(g.vy, dy / d * 640, clampf(10 * dt, 0, 1)); }
            if (bd2 < sq(tp->r + 10)) { g.dead = true; if (!G.demo) gainXP(*tp, g.v); else tp->xp = 0; if (tp == &players[localIdx]) sfx(S_GEM); else netEvGem(tp->idx); addPart(g.x, g.y, 0, 0, 0.2f, 7, 0x7dd3fc); }
        }
        g.x += g.vx * dt; g.y += g.vy * dt;
    }
    updateFx(dt); updateCamera(dt);

    enemies.erase(std::remove_if(enemies.begin(), enemies.end(), [](const Enemy& e) { return e.dead; }), enemies.end());
    bullets.erase(std::remove_if(bullets.begin(), bullets.end(), [](const Bullet& b) { return b.dead; }), bullets.end());
    ebul.erase(std::remove_if(ebul.begin(), ebul.end(), [](const EBullet& b) { return b.dead; }), ebul.end());
    gems.erase(std::remove_if(gems.begin(), gems.end(), [](const Gem& b) { return b.dead; }), gems.end());
    parts.erase(std::remove_if(parts.begin(), parts.end(), [](const Part& b) { return b.dead; }), parts.end());
    texts.erase(std::remove_if(texts.begin(), texts.end(), [](const FText& b) { return b.dead; }), texts.end());
    rings.erase(std::remove_if(rings.begin(), rings.end(), [](const RingFx& b) { return b.dead; }), rings.end());
    beams.erase(std::remove_if(beams.begin(), beams.end(), [](const Beam& b) { return b.dead; }), beams.end());
    lasers.erase(std::remove_if(lasers.begin(), lasers.end(), [](const Laser& b) { return b.dead; }), lasers.end());
    shards.erase(std::remove_if(shards.begin(), shards.end(), [](const Shard& b) { return b.dead; }), shards.end());
    refreshBoss();
    for (auto& pl : players) {
        if (pl.pending <= 0) continue;
        if (G.demo) { pl.pending = 0; continue; }
        if (AUTOPLAY) { int u = irnd(NUPG); pl.ups[u]++; UPGS[u].fn(pl); pl.pending--; continue; }
        if (G.state != ST_PLAY) continue;
        if (!MP()) { curP = &pl; openLevelUp(); curP = &players[localIdx]; } else if (!pl.offer) startOffer(pl);
    }
    for (auto& pl : players) if (pl.offer) { pl.offerT -= dt; if (pl.offerT <= 0) answerOffer(pl, irnd(3)); }
}

// ============================================================================
//  state machine
// ============================================================================
static int menuSel = 0, cardSel = 0;
static void applyAudioSettings() {
    AU.sfxVol.store(CFG.sfxOn ? 0.9f : 0.f); AU.master.store(CFG.master);
    float t = !CFG.musOn ? 0.f : (G.state == ST_PLAY || G.state == ST_TITLE || G.state == ST_DYING) ? 0.5f : 0.2f; AU.musTarget.store(t);
}
static void setState(State s) { G.state = s; menuSel = 0; cardSel = 0; applyAudioSettings(); }
static void resetWorld(bool demo, int nPlayers = 1) {
    enemies.clear(); bullets.clear(); ebul.clear(); gems.clear(); parts.clear(); texts.clear(); rings.clear(); beams.clear(); lasers.clear(); shards.clear();
    boss = nullptr; players.assign(nPlayers, Player());
    for (int i = 0; i < nPlayers; i++) { players[i].idx = i; players[i].col = PCOLS[i & 3]; players[i].xpNeed = xpFor(1); players[i].x = (i - (nPlayers - 1) / 2.f) * 70.f; snprintf(players[i].name, sizeof players[i].name, "P%d", i + 1); }
    if (localIdx >= nPlayers) localIdx = 0; curP = &players[localIdx];
    int keepBest = 0; (void)keepBest;
    G.demo = demo; G.t = 0; G.time = 0; G.wave = demo ? 3 : 1; G.score = 0; G.kills = 0; G.streak = 0; G.combo = 1; G.comboT = 0; G.sudo = 0; G.hitstop = 0; G.timeScale = 1;
    G.shake = 0; G.hurt = 0; G.flash = 0; G.bossAlive = false; G.bossCount = 0; G.bossT = 0; G.swarmT = 40; G.spawnT = 0.5f; G.pending = 0; G.banner.on = false; G.deathT = 0; G.sudoReady = false;
    G.accent = waveColor(G.wave); G.newBest = false; camX = 0; camY = 0; camPunch = 0;
}
static void startGame(int nPlayers = 1) {
    resetWorld(false, nPlayers); banner("WAVE 1", "DEFEND /BOOT", waveColor(1)); setState(ST_PLAY); sfx(S_UI);
    fireEvent("start", "KERNEL PANIC", "Malware is flooding /boot. Defend the kernel.", 0, waveColor(1));
}
static void toMenu() { netShutdown(); resetWorld(true); setState(ST_TITLE); }
static void gameOverNow() {
    G.newBest = (long)G.score > STATS.best;
    STATS.runs++; STATS.totalKills += G.kills;
    if (G.newBest) { STATS.best = (long)G.score; STATS.bestWave = G.wave; STATS.bestTime = G.time; }
    saveStats();
    G.quote = QUOTES[irnd((int)(sizeof(QUOTES) / sizeof(QUOTES[0])))];
    setState(ST_OVER); netSendOver();
    fireEvent("gameover", "SYSTEM HALTED", fmt("Wave %d, score %s, %d kills.", G.wave, fmtNum((long)G.score).c_str(), G.kills), 1, 0xef4444);
    if (G.newBest) fireEvent("highscore", "NEW HIGH SCORE", fmt("%s points on wave %d.", fmtNum((long)G.score).c_str(), G.wave), 1, 0xfacc15);
}
static int lvOf(int i) { return P.ups[i]; }
static void rollChoices(const Player& p, int out[3]) {
    std::vector<int> pool; for (int i = 0; i < NUPG; i++) if (p.ups[i] < UPGS[i].max && !(UPGS[i].heal && p.hp > p.maxhp * 0.75f)) pool.push_back(i);
    auto wt = [&](int i) { return UPGS[i].heal ? 0.6f : (UPGS[i].nw && !p.ups[i]) ? 1.6f : 1.f; };
    for (int k = 0; k < 3; k++) {
        if (pool.empty()) { out[k] = -1; continue; }
        float tot = 0; for (int i : pool) tot += wt(i);
        float r = rnd01() * tot; size_t idx = 0;
        for (size_t j = 0; j < pool.size(); j++) { r -= wt(pool[j]); if (r <= 0) { idx = j; break; } }
        out[k] = pool[idx]; pool.erase(pool.begin() + idx);
    }
}
static void levelEvent(const Player& p) { if (p.level % 5 == 0 && &p == &players[localIdx]) fireEvent("levelup", fmt("LEVEL %d", p.level), "Patch installed. You are getting dangerous.", 0, 0xc084fc); }
static void openLevelUp() {   // single player: pauses the game
    P.pending--; rollChoices(P, G.choices);
    G.lvT = SDL_GetTicks(); setState(ST_LEVELUP); sfx(S_LEVEL); camPunch = 0.05f; levelEvent(P);
}
static void chooseUpgrade(int k) {
    if (G.state != ST_LEVELUP || SDL_GetTicks() - G.lvT < 350) return;
    int i = G.choices[k]; if (i < 0) return;
    P.ups[i]++; UPGS[i].fn(P); floatText(P.x, P.y - 30, UPGS[i].name, 0xe9d5ff, 2.4f); sfx(S_UI);
    if (P.pending > 0) openLevelUp(); else setState(ST_PLAY);
}
static void netSendOffer(Player& p);
static void startOffer(Player& p) {   // co-op: the offer runs alongside the game, auto-picks after 14 s
    p.pending--; rollChoices(p, p.choices); p.offer = true; p.offerT = 14.f; levelEvent(p);
    if (p.remote) netSendOffer(p); else { G.lvT = SDL_GetTicks(); sfx(S_LEVEL); }
}
static void answerOffer(Player& p, int k) {   // k may come straight from the network: never trust it as an index
    if (!p.offer) return;
    if (k < 0 || k > 2 || p.choices[k] < 0) { k = -1; for (int j = 0; j < 3; j++) if (p.choices[j] >= 0) { k = j; break; } }   // out of range or invalid slot: fall back to the first valid one
    if (k < 0) { p.offer = false; return; }                                                                                     // nothing valid to pick
    int i = p.choices[k]; if (i < 0 || i >= NUPG) { p.offer = false; return; }
    p.ups[i]++; UPGS[i].fn(p); p.offer = false; floatText(p.x, p.y - 30, UPGS[i].name, 0xe9d5ff, 2.4f);
    if (!p.remote) sfx(S_UI);
}

// ============================================================================
//  multiplayer: host-authoritative co-op over the encrypted transport in net.h
//  Host simulates everything. Clients send inputs (60 Hz) and receive snapshots (30 Hz), filtered to what is near them.
// ============================================================================
enum : uint8_t { R_JOIN = 1, R_CHOOSE = 2, R_LEAVE = 3, R_ACCEPT = 10, R_REJECT = 11, R_LOBBY = 12, R_START = 13, R_BANNER = 14, R_OFFER = 15, R_OVER = 16,
                 U_INPUT = 20, U_SNAP = 30, U_ENEMIES = 31, U_BULLETS = 32, U_EBUL = 33, U_GEMS = 34 };
enum : uint8_t { EV_HIT = 1, EV_KILL = 2, EV_SFX = 3, EV_RING = 4, EV_SHAKE = 5, EV_HURT = 6, EV_GEM = 7 };
struct NetEv { uint8_t k; int16_t x, y; uint8_t a, b; };
static const uint32_t PAL[26] = { 0xa855f7, 0x22d3ee, 0xf472b6, 0xfb923c, 0x4ade80, 0x60a5fa, 0xfacc15, 0xef4444, 0xffffff, 0xc084fc, 0xff8a3d, 0xa78bfa, 0x67e8f9, 0xf472b6, 0x4ade80, 0xfb923c,
                                  0xff4d8d, 0x4dffd9, 0xffd94d, 0xff4d6d, 0xff3d81, 0x35f0c8, 0xffd23d, 0x7c3aed, 0xffa940, 0xff5f7e };
struct Slot { bool used = false; uint32_t sid = 0; char name[16] = { 0 }; };
struct CEnemy { uint16_t id; uint8_t tf; float x, y, vx, vy; uint8_t hp, aux; };
struct CBullet { float x, y, vx, vy; uint8_t fl; };
struct CEBul { float x, y, vx, vy, r; uint8_t col; };
struct CGem { float x, y; uint8_t mag; };
struct Gather { uint32_t tick = 0; uint8_t total = 0, mask = 0; std::vector<uint8_t> part[4]; };
struct CPl { float x = 0, y = 0, vx = 0, vy = 0; };
struct MPS {
    uint8_t secret[16] = { 0 }; double tRoutes = 0;
    net::Host host; net::Client cli; bool hostUp = false, everConnected = false, botClient = false; std::string code, notice, joinAddr, joinCode; uint16_t port = 47474; std::vector<std::string> addrs;
    int field = 0; Slot slots[4]; std::vector<std::string> roster; uint16_t seqIn[4] = { 0, 0, 0, 0 }; int expectClients = 0;
    uint32_t tick = 0, lastTick = 0; double tSnap = 0, tKeep = 0, tIn = 0, snapAt = 0, listAt[4] = { 0, 0, 0, 0 }, shootT = 0; uint16_t inSeq = 0;
    std::vector<NetEv> evq; std::vector<std::vector<Pt>> beamq;
    std::vector<CEnemy> cEn; std::vector<CBullet> cBu; std::vector<CEBul> cEb; std::vector<CGem> cGm; Gather gEn, gBu, gEb, gGm; CPl cpl[4];
    long snapsRx = 0, listsRx = 0, evRx = 0, badRx = 0; uint32_t lastSnapTick = 0;
};
static MPS M;

// ---- reaching the host from the internet with no server: IPv6, UPnP port mapping (optional), STUN, or VPN/LAN addresses ----
#ifdef HAVE_MINIUPNPC
#include <miniupnpc/miniupnpc.h>
#include <miniupnpc/upnpcommands.h>
#endif
struct UpnpState { std::mutex m; std::string ext; bool done = false, ok = false; };
static std::shared_ptr<UpnpState> UPS;
#ifdef HAVE_MINIUPNPC
static UPNPUrls gUpUrls; static IGDdatas gUpData; static bool gUpMapped = false; static std::string gUpPort; static std::mutex gUpMx;
static void upnpStart(uint16_t port) {   // asks the router (UPnP IGD) to forward our UDP port; runs off-thread because discovery blocks for ~2 s
    UPS = std::make_shared<UpnpState>(); auto st = UPS;
    std::thread([st, port]() {
        int err = 0; UPNPDev* dev = upnpDiscover(1500, nullptr, nullptr, UPNP_LOCAL_PORT_ANY, 0, 2, &err);
        if (dev) {
            UPNPUrls urls; IGDdatas data; char lan[64] = { 0 }, wan[64] = { 0 };
#if MINIUPNPC_API_VERSION >= 18
            int r = UPNP_GetValidIGD(dev, &urls, &data, lan, sizeof lan, wan, sizeof wan);   // newer miniupnpc also reports the WAN address
#else
            int r = UPNP_GetValidIGD(dev, &urls, &data, lan, sizeof lan); (void)wan;
#endif
            if (r == 1) {
                std::string p = std::to_string(port); char ext[64] = { 0 };
                if (UPNP_AddPortMapping(urls.controlURL, data.first.servicetype, p.c_str(), p.c_str(), lan, "Kernel Panic", "UDP", nullptr, "3600") == 0 &&
                    UPNP_GetExternalIPAddress(urls.controlURL, data.first.servicetype, ext) == 0 && ext[0]) {
                    std::lock_guard<std::mutex> g(gUpMx); gUpUrls = urls; gUpData = data; gUpMapped = true; gUpPort = p;
                    std::lock_guard<std::mutex> l(st->m); st->ext = ext; st->ok = true;
                } else FreeUPNPUrls(&urls);
            } else if (r) FreeUPNPUrls(&urls);
            freeUPNPDevlist(dev);
        }
        std::lock_guard<std::mutex> l(st->m); st->done = true;
    }).detach();
}
static void upnpStop() {
    std::lock_guard<std::mutex> g(gUpMx);
    if (gUpMapped) { UPNP_DeletePortMapping(gUpUrls.controlURL, gUpData.first.servicetype, gUpPort.c_str(), "UDP", nullptr); FreeUPNPUrls(&gUpUrls); gUpMapped = false; }
    UPS.reset();
}
#else
static void upnpStart(uint16_t) { UPS.reset(); }
static void upnpStop() { UPS.reset(); }
#endif
struct Route { std::string label; net::Addr a; };
static std::vector<Route> gRoutes;
static bool privateV4(uint32_t ip) { return (ip >> 24) == 10 || (ip >> 20) == (172u << 4 | 1u) || (ip >> 16) == (192u << 8 | 168u) || (ip >> 22) == (100u << 2 | 1u) || (ip >> 24) == 127; }
static void refreshRoutes(uint16_t port, bool haveStun, const net::Addr& stunEp) {
    std::vector<Route> v6, pub, other;
    for (auto& a : net::localEndpoints(port)) {
        if (a.ss.ss_family == AF_INET6) v6.push_back({ "IPV6", a });
        else { uint32_t ip = ntohl(((const sockaddr_in*)&a.ss)->sin_addr.s_addr); other.push_back({ (ip >> 22) == (100u << 2 | 1u) ? "VPN" : "LAN", a }); }
    }
    std::string upExt; if (UPS) { std::lock_guard<std::mutex> l(UPS->m); if (UPS->ok) upExt = UPS->ext; }
    net::Addr pa; bool have = false; std::string how;
    if (!upExt.empty() && net::resolve(upExt + ":" + std::to_string(port), port, pa, true) && !privateV4(ntohl(((sockaddr_in*)&pa.ss)->sin_addr.s_addr))) { have = true; how = "PUBLIC (UPNP)"; }
    else if (haveStun && stunEp.ss.ss_family == AF_INET) { pa = stunEp; have = true; how = "PUBLIC (STUN)"; }
    if (have) pub.push_back({ how, pa });
    gRoutes.clear(); for (auto& r : v6) gRoutes.push_back(r); for (auto& r : pub) gRoutes.push_back(r); for (auto& r : other) gRoutes.push_back(r);
}
static int16_t q16(float v, float scale) { return (int16_t)clampf(v * scale, -32000.f, 32000.f); }
static int palIdx(uint32_t c) { for (int i = 0; i < 26; i++) if (PAL[i] == c) return i; return 0; }
static void pushEv(uint8_t k, float x, float y, int a, int b) {
    if (mpRole != 1 || M.evq.size() >= 40) return;
    M.evq.push_back({ k, q16(x, 8), q16(y, 8), (uint8_t)clampf((float)a, 0, 255), (uint8_t)clampf((float)b, 0, 255) });
}
static void netEvSfx(int n) { static const int ok[] = { S_DASH, S_SUDO, S_BOSS, S_WAVE, S_ZAP, S_BOOM, S_DIE, S_READY }; if (mpRole != 1) return; for (int v : ok) if (v == n) { pushEv(EV_SFX, 0, 0, n, 0); return; } }
static void netEvRing(float x, float y, float mx, uint32_t col) { pushEv(EV_RING, x, y, (int)(mx / 8), palIdx(col)); }
static void netEvShake(float a) { if (a >= 20) pushEv(EV_SHAKE, 0, 0, (int)a, 0); }
static void netEvHit(float x, float y, float dmg, bool crit) { pushEv(EV_HIT, x, y, (int)dmg, crit); }
static void netEvKill(float x, float y, int type, bool elite) { pushEv(EV_KILL, x, y, type, elite ? 1 : 0); }
static void netEvHurt(int idx) { pushEv(EV_HURT, 0, 0, idx, 0); }
static void netEvGem(int idx) { pushEv(EV_GEM, 0, 0, idx, 0); }
static void netEvBeam(const std::vector<Pt>& pts) { if (mpRole != 1 || M.beamq.size() >= 3 || pts.size() > 8) return; M.beamq.push_back(pts); }

static std::string cleanName(const std::string& in) { std::string o; for (char c : in) { if (isalnum((unsigned char)c) || c == '_' || c == '-' || c == '.') o += c; if (o.size() >= 12) break; } return o.empty() ? "PLAYER" : o; }
static std::string myName() { const char* u = getenv("USER"); return cleanName(u ? u : "PLAYER"); }
static std::string netInvite() { std::vector<net::Addr> eps; for (auto& r : gRoutes) eps.push_back(r.a); if (eps.empty()) { net::Addr l; net::resolve("127.0.0.1:" + std::to_string(M.port), M.port, l); eps.push_back(l); } return net::makeInvite(M.secret, eps); }
static int playerBySid(uint32_t sid) { for (auto& p : players) if (p.remote && p.sid == sid) return p.idx; return -1; }
static std::vector<std::string> rosterNow() {
    if (mpRole != 1) return M.roster;
    std::vector<std::string> r = { myName() }; for (auto& s : M.slots) if (s.used) r.push_back(s.name); return r;
}
static void relToAll(const uint8_t* b, size_t n) { for (auto& s : M.slots) if (s.used) M.host.sendR(s.sid, b, n); }
static void broadcastLobby() {
    uint8_t b[200]; net::Writer w(b, sizeof b); auto r = rosterNow(); w.u8(R_LOBBY); w.u8((uint8_t)r.size()); for (auto& n : r) w.str(n, 12); if (w.ok) relToAll(b, w.n);
}
static void netBanner(const std::string& t, const std::string& sub, uint32_t col) {
    if (mpRole != 1 || !M.hostUp) return;
    uint8_t b[120]; net::Writer w(b, sizeof b); w.u8(R_BANNER); w.str(t, 28); w.str(sub, 32); w.u32(col); if (w.ok) relToAll(b, w.n);
}
static void netSendOffer(Player& p) { if (mpRole != 1 || !p.remote) return; uint8_t b[8]; net::Writer w(b, sizeof b); w.u8(R_OFFER); for (int k = 0; k < 3; k++) w.i8((int8_t)p.choices[k]); M.host.sendR(p.sid, b, w.n); }
static void netSendOver() {
    if (mpRole != 1 || !M.hostUp) return;
    uint8_t b[40]; net::Writer w(b, sizeof b); w.u8(R_OVER); w.u32((uint32_t)G.score); w.u8((uint8_t)G.wave); w.u16((uint16_t)std::min(65535.f, G.time)); w.u16((uint16_t)std::min(65535, G.kills)); w.u8(G.newBest ? 1 : 0); w.u32((uint32_t)STATS.best);
    for (int i = 0; i < 6; i++) if (G.quote == QUOTES[i]) w.u8((uint8_t)i); if (w.ok) relToAll(b, w.n);
}
static void netShutdown() {
    upnpStop(); gRoutes.clear(); if (M.hostUp) { M.host.stop(); M.hostUp = false; }
    if (M.cli.st != net::Client::IDLE) M.cli.stop();
    mpRole = 0; M.everConnected = false; for (auto& s : M.slots) s = Slot(); M.roster.clear(); M.code.clear(); M.evq.clear(); M.beamq.clear();
    SDL_StopTextInput();
}

// ---- host ------------------------------------------------------------------
static bool netStartHost() {
    netShutdown(); M.notice.clear();
    uint8_t raw[16]; if (sodium_init() < 0) { M.notice = "CRYPTO INIT FAILED"; return false; }
    randombytes_buf(raw, 16);
    if (const char* fixed = getenv("KP_CODE")) { net::decodeCode(fixed, raw); }   // dev/test hook only
    M.code = net::encodeCode(raw); memcpy(M.secret, raw, 16);
    uint16_t want = getenv("KP_PORT") ? (uint16_t)atoi(getenv("KP_PORT")) : 47474;
    if (!M.host.start(want, raw) && !M.host.start(0, raw)) { M.notice = "COULD NOT OPEN A UDP PORT"; return false; }
    M.port = M.host.sock.port(); M.addrs = net::localAddresses(); M.hostUp = true; mpRole = 1; localIdx = 0;
    M.host.startStun(); if (CFG.upnp) upnpStart(M.port); refreshRoutes(M.port, false, net::Addr()); M.tRoutes = 0;
    resetWorld(true); mpRole = 1; setState(ST_LOBBY); return true;
}
static void netHostStart() {
    if (!M.hostUp) { startGame(); return; }
    std::vector<uint32_t> sids; std::vector<std::string> names = { myName() };
    for (auto& s : M.slots) if (s.used) { if (M.host.peers.count(s.sid)) { sids.push_back(s.sid); names.push_back(s.name); } else s = Slot(); }
    int n = (int)names.size(); mpRole = 1; localIdx = 0;
    startGame(n);
    for (int i = 0; i < n; i++) { snprintf(players[i].name, sizeof players[i].name, "%s", names[i].c_str()); if (i > 0) { players[i].remote = true; players[i].sid = sids[i - 1]; } }
    for (int i = 1; i < n; i++) { uint8_t b[120]; net::Writer w(b, sizeof b); w.u8(R_START); w.u8((uint8_t)n); w.u8((uint8_t)i); for (auto& nm : names) w.str(nm, 12); if (w.ok) M.host.sendR(sids[i - 1], b, w.n); }
}
static void hostRel(uint32_t sid, const std::vector<uint8_t>& d) {
    net::Reader r(d.data(), d.size()); uint8_t k = r.u8(); if (!r.ok) return;
    if (k == R_JOIN) {
        std::string name = cleanName(r.str(15)); if (!r.ok) return;
        for (auto& s : M.slots) if (s.used && s.sid == sid) return;
        auto rej = [&](const char* why) { uint8_t b[64]; net::Writer w(b, sizeof b); w.u8(R_REJECT); w.str(why, 40); M.host.sendR(sid, b, w.n); };
        if (G.state != ST_LOBBY) { rej("game already in progress"); return; }
        for (auto& s : M.slots) if (!s.used) { s.used = true; s.sid = sid; snprintf(s.name, sizeof s.name, "%s", name.c_str()); uint8_t b[4]; net::Writer w(b, sizeof b); w.u8(R_ACCEPT); M.host.sendR(sid, b, w.n); broadcastLobby(); sfx(S_UI); return; }
        rej("room is full");
    } else if (k == R_CHOOSE) { int pi = playerBySid(sid); uint8_t c = r.u8(); if (pi >= 0 && r.ok) answerOffer(players[pi], c); }
    else if (k == R_LEAVE) M.host.drop(sid);
}
static void hostInput(uint32_t sid, const std::vector<uint8_t>& d) {
    net::Reader r(d.data(), d.size()); if (r.u8() != U_INPUT) return; uint16_t seq = r.u16(); int8_t mx = r.i8(), my = r.i8(); uint16_t ang = r.u16(); uint8_t fl = r.u8(); if (!r.ok) return;
    int pi = playerBySid(sid); if (pi < 0 || pi > 3) return; Player& p = players[pi];
    if ((int16_t)(uint16_t)(seq - M.seqIn[pi]) <= 0 && p.inAge < 5) return;   // stale or duplicate
    M.seqIn[pi] = seq; p.inMx = clampf(mx / 127.f, -1, 1); p.inMy = clampf(my / 127.f, -1, 1); p.inAng = ang * TAU / 65535.f; p.inFire = fl & 1; p.inDash = fl & 2; p.inSudo = fl & 4; p.inAge = 0;
}
static bool inRange(float x, float y, float cx, float cy) { return fabsf(x - cx) < 1500 && fabsf(y - cy) < 950; }
static void sendChunks(uint32_t sid, uint8_t kind, uint32_t tick, size_t recSize, const std::vector<uint8_t>& blob) {
    size_t per = 900 / recSize, nrec = blob.size() / recSize; if (nrec > 4 * per) nrec = 4 * per; size_t nparts = std::max<size_t>(1, (nrec + per - 1) / per);
    for (size_t i = 0; i < nparts; i++) {
        size_t a = i * per, b = std::min(nrec, a + per); uint8_t buf[1100]; net::Writer w(buf, sizeof buf);
        w.u8(kind); w.u32(tick); w.u8((uint8_t)i); w.u8((uint8_t)nparts); w.u8((uint8_t)(b - a)); w.raw(blob.data() + a * recSize, (b - a) * recSize); if (w.ok) M.host.sendU(sid, buf, w.n);
    }
}
static void hostSnapshot() {
    M.tick++;
    for (auto& kv : M.host.peers) {
        if (!kv.second.confirmed) continue; uint32_t sid = kv.first; int pi = playerBySid(sid); if (pi < 0) continue;
        float cx = players[pi].x, cy = players[pi].y;
        uint8_t buf[1200]; net::Writer w(buf, sizeof buf);
        w.u8(U_SNAP); w.u32(M.tick); w.u8((uint8_t)std::min(255, G.wave)); w.u32((uint32_t)std::max(0.0, G.score)); w.u16((uint16_t)std::min(65535, G.kills)); w.u32((uint32_t)(G.time * 1000)); w.u8((uint8_t)G.combo);
        w.u8((uint8_t)clampf(G.comboT * 90, 0, 255)); w.u8((uint8_t)clampf(G.sudo, 0, 100)); w.u8((uint8_t)players.size());
        for (auto& p : players) {
            uint8_t fl = (p.dead ? 1 : 0) | (p.connected ? 2 : 0) | (p.dashT > 0 ? 4 : 0) | (p.iframes > 0 ? 8 : 0) | (p.offer ? 16 : 0);
            w.u8(fl); w.i16(q16(p.x, 16)); w.i16(q16(p.y, 16)); w.i16(q16(p.vx, 4)); w.i16(q16(p.vy, 4)); w.u8((uint8_t)(fmodf(p.ang + TAU * 4, TAU) / TAU * 255));
            w.u16((uint16_t)clampf(p.hp * 10, 0, 65535)); w.u16((uint16_t)clampf(p.maxhp * 10, 0, 65535)); w.u8((uint8_t)std::min(255, p.level)); w.u16((uint16_t)clampf(p.xp * 4, 0, 65535)); w.u16((uint16_t)clampf(p.xpNeed * 4, 0, 65535));
            w.u8((uint8_t)clampf(p.dashCd / p.st.dashCd * 255, 0, 255)); w.u8((uint8_t)std::min(255, p.st.orbit)); w.u8((uint8_t)std::min(255, p.st.count)); w.u8((uint8_t)clampf(p.respawnT * 10, 0, 255));
        }
        size_t nl = std::min<size_t>(6, lasers.size()); w.u8((uint8_t)nl);
        for (size_t i = 0; i < nl; i++) { auto& L = lasers[i]; w.i16(q16(L.x, 16)); w.i16(q16(L.y, 16)); w.i16((int16_t)clampf(L.ang * 1000, -32000, 32000)); w.u8((uint8_t)clampf(L.t * 100, 0, 255)); w.u8((uint8_t)palIdx(L.col)); }
        w.u8((uint8_t)M.evq.size()); for (auto& e : M.evq) { w.u8(e.k); w.i16(e.x); w.i16(e.y); w.u8(e.a); w.u8(e.b); }
        w.u8((uint8_t)M.beamq.size()); for (auto& b : M.beamq) { w.u8((uint8_t)b.size()); for (auto& p : b) { w.i16(q16(p.x, 8)); w.i16(q16(p.y, 8)); } }
        if (w.ok) M.host.sendU(sid, buf, w.n);
        std::vector<uint8_t> en, bu, eb, gm;
        for (auto& e : enemies) {
            if (e.dead || (!inRange(e.x, e.y, cx, cy) && e.type != T_BOSS)) continue;
            uint8_t rec[16]; net::Writer rw(rec, sizeof rec); uint8_t tf = (e.type & 7) | (e.elite ? 8 : 0) | (e.flash > 0 ? 16 : 0) | ((e.state & 3) << 5);
            uint8_t aux = 0; if (e.type == T_CHARGER) aux = (uint8_t)(fmodf(atan2f(e.cy, e.cx) + TAU, TAU) / TAU * 255); else if (e.type == T_BOMB) aux = e.fuse < 0 ? 0 : (uint8_t)clampf(e.fuse * 200, 1, 255);
            else if (e.type == T_BOSS) aux = (e.kind & 3) | (((e.phase - 1) & 3) << 2) | (e.intro > 0 ? 16 : 0);
            rw.u16((uint16_t)(e.id & 0xFFFF)); rw.u8(tf); rw.i16(q16(e.x, 16)); rw.i16(q16(e.y, 16)); rw.i8((int8_t)clampf(e.vx / 6, -127, 127)); rw.i8((int8_t)clampf(e.vy / 6, -127, 127)); rw.u8((uint8_t)clampf(e.hp / e.maxhp * 255, 0, 255)); rw.u8(aux);
            en.insert(en.end(), rec, rec + rw.n);
        }
        for (auto& b : bullets) { if (b.dead || !inRange(b.x, b.y, cx, cy)) continue; uint8_t rec[8]; net::Writer rw(rec, sizeof rec); rw.i16(q16(b.x, 16)); rw.i16(q16(b.y, 16)); rw.i8((int8_t)clampf(b.vx / 8, -127, 127)); rw.i8((int8_t)clampf(b.vy / 8, -127, 127)); rw.u8(b.crit ? 1 : 0); bu.insert(bu.end(), rec, rec + rw.n); }
        for (auto& b : ebul) { if (b.dead || !inRange(b.x, b.y, cx, cy)) continue; uint8_t rec[8]; net::Writer rw(rec, sizeof rec); rw.i16(q16(b.x, 16)); rw.i16(q16(b.y, 16)); rw.i8((int8_t)clampf(b.vx / 4, -127, 127)); rw.i8((int8_t)clampf(b.vy / 4, -127, 127)); rw.u8((uint8_t)clampf(b.r * 4, 0, 255)); rw.u8((uint8_t)palIdx(b.col)); eb.insert(eb.end(), rec, rec + rw.n); }
        for (auto& g : gems) { if (g.dead || !inRange(g.x, g.y, cx, cy)) continue; uint8_t rec[8]; net::Writer rw(rec, sizeof rec); rw.i16(q16(g.x, 16)); rw.i16(q16(g.y, 16)); rw.u8(g.mag ? 1 : 0); gm.insert(gm.end(), rec, rec + rw.n); }
        sendChunks(sid, U_ENEMIES, M.tick, 11, en); sendChunks(sid, U_BULLETS, M.tick, 6, bu); sendChunks(sid, U_EBUL, M.tick, 8, eb); sendChunks(sid, U_GEMS, M.tick, 5, gm);
    }
    M.evq.clear(); M.beamq.clear();
}
static void hostPump(float dt) {
    if (!M.hostUp) return;
    M.host.poll();
    M.tRoutes += dt; if (M.tRoutes > 1.0 && G.state == ST_LOBBY) { M.tRoutes = 0; refreshRoutes(M.port, M.host.havePublic, M.host.publicEp); }
    for (auto& e : M.host.ev) {
        if (e.kind == net::Event::REL) hostRel(e.sid, e.data);
        else if (e.kind == net::Event::UNREL) hostInput(e.sid, e.data);
        else if (e.kind == net::Event::DISCONNECTED) {
            bool lobby = G.state == ST_LOBBY; for (auto& s : M.slots) if (s.used && s.sid == e.sid) s = Slot();
            for (auto& p : players) if (p.remote && p.sid == e.sid && !lobby) { p.connected = false; p.dead = true; p.offer = false; floatText(p.x, p.y - 30, "DISCONNECTED", 0xff8fa0, 2.4f); }
            if (lobby) broadcastLobby();
        }
    }
    M.host.ev.clear();
    M.tKeep += dt; if (M.tKeep > 0.1) { M.tKeep = 0; for (auto& kv : M.host.peers) if (kv.second.confirmed) M.host.sendU(kv.first, nullptr, 0); }
    bool live = G.state == ST_PLAY || G.state == ST_DYING || G.state == ST_PAUSE;
    M.tSnap += dt; if (live && M.tSnap >= 1.0 / 30) { M.tSnap = 0; hostSnapshot(); }
}

// ---- client ----------------------------------------------------------------
static bool netStartJoin() {
    netShutdown(); M.notice.clear();
    std::string in = M.joinAddr; while (!in.empty() && isspace((unsigned char)in.back())) in.pop_back(); while (!in.empty() && isspace((unsigned char)in.front())) in.erase(in.begin());
    bool ok;
    if (in.size() > 3 && (in[0] == 'K' || in[0] == 'k') && (in[1] == 'P' || in[1] == 'p') && in[2] == '-') ok = M.cli.connectInvite(in);   // the normal case: one pasted invite
    else { std::string addr = in, code = M.joinCode; size_t h = addr.find('#'); if (h != std::string::npos) { code = addr.substr(h + 1); addr = addr.substr(0, h); } ok = M.cli.connect(addr, code); }   // legacy address + code (LAN/testing)
    if (!ok) { M.notice = M.cli.err; return false; }
    mpRole = 2; M.everConnected = false; M.roster.clear(); resetWorld(true); mpRole = 2; setState(ST_LOBBY); return true;
}
static void clientEvent(const NetEv& e) {
    float x = e.x / 8.f, y = e.y / 8.f; M.evRx++;
    switch (e.k) {
        case EV_HIT: { bool crit = e.b != 0; addPart(x, y, rndr(-100, 100), rndr(-100, 100), 0.25f, 3, crit ? 0xffe14d : 0xffffff); if (crit || rnd01() < 0.35f) floatText(x, y - 12, std::to_string((int)e.a), crit ? 0xffe14d : 0xffffff, crit ? 3.f : 2.f); sfx(S_HIT); break; }
        case EV_KILL: { int t = e.a % 7; uint32_t col = TD[t].col; bool isB = t == T_BOSS; float r = TD[t].r; burst(x, y, col, isB ? 110 : r > 18 ? 28 : 14, 260 + r * 4, 0.65f, 5); burst(x, y, 0xffffff, isB ? 30 : 6, 200, 0.35f, 3);
            ringFx(x, y, r * 3 + 24, 0.35f, col, 3); spawnShards(x, y, col, isB ? 46 : r > 18 ? 12 : 7, 240 + r * 3, r * 0.7f + 4); sfx(S_KILL); if (isB || e.b) addShake(isB ? 30.f : 10.f); break; }
        case EV_SFX: if (e.a <= S_BOOM) sfx(e.a); break;
        case EV_RING: ringFx(x, y, e.a * 8.f, 0.5f, PAL[e.b % 26], 5); break;
        case EV_SHAKE: addShake((float)e.a); break;
        case EV_HURT: if (e.a == localIdx) { G.hurt = 1; addShake(11); sfx(S_HURT); rumble(0.6f, 0.9f, 180); } else if (e.a < players.size()) burst(players[e.a].x, players[e.a].y, 0xff5f7e, 14, 260, 0.5f, 4); break;
        case EV_GEM: if (e.a == localIdx) sfx(S_GEM); break;
    }
}
static void clientSnap(const uint8_t* d, size_t n) {
    net::Reader r(d, n); r.u8(); uint32_t tick = r.u32(); if (!r.ok || (M.lastSnapTick && (int32_t)(tick - M.lastSnapTick) <= 0)) return;
    int wave = std::max(1, (int)r.u8()); uint32_t score = r.u32(); int kills = r.u16(); uint32_t tms = r.u32(); int combo = r.u8(); float comboT = r.u8() / 90.f; float sudo = r.u8(); int np = r.u8();
    if (!r.ok || np < 1 || np > 4 || np != (int)players.size()) return;
    struct TP { uint8_t fl; float x, y, vx, vy, ang, hp, maxhp, xp, xpNeed, dashF, resp; uint8_t lvl, orbit, count; } tp[4];
    for (int i = 0; i < np; i++) { TP& t = tp[i]; t.fl = r.u8(); t.x = r.i16() / 16.f; t.y = r.i16() / 16.f; t.vx = r.i16() / 4.f; t.vy = r.i16() / 4.f; t.ang = r.u8() * TAU / 255.f; t.hp = r.u16() / 10.f; t.maxhp = r.u16() / 10.f; t.lvl = r.u8(); t.xp = r.u16() / 4.f; t.xpNeed = r.u16() / 4.f; t.dashF = r.u8() / 255.f; t.orbit = r.u8(); t.count = r.u8(); t.resp = r.u8() / 10.f; }
    int nl = r.u8(); if (nl > 6) return; std::vector<Laser> ls; for (int i = 0; i < nl; i++) { float x = r.i16() / 16.f, y = r.i16() / 16.f, a = r.i16() / 1000.f, t = r.u8() / 100.f; int c = r.u8(); ls.push_back({ x, y, a, t, 0.9f, 0.35f, false, false, PAL[c % 26] }); }
    int ne = r.u8(); if (ne > 40) return; std::vector<NetEv> evs; for (int i = 0; i < ne; i++) { NetEv e; e.k = r.u8(); e.x = r.i16(); e.y = r.i16(); e.a = r.u8(); e.b = r.u8(); evs.push_back(e); }
    int nb = r.u8(); if (nb > 3) return; std::vector<std::vector<Pt>> bms; for (int i = 0; i < nb; i++) { int np2 = r.u8(); if (np2 > 8) return; std::vector<Pt> v; for (int k = 0; k < np2; k++) { float x = r.i16() / 8.f, y = r.i16() / 8.f; v.push_back({ x, y }); } bms.push_back(v); }
    if (!r.ok) { M.badRx++; return; }   // only ever apply fully valid snapshots
    M.lastSnapTick = tick; M.snapAt = net::nowSec(); M.snapsRx++;
    if (wave != G.wave) { G.wave = wave; G.accent = waveColor(wave); }
    G.score = score; G.kills = kills; G.time = tms / 1000.f; G.combo = combo; G.comboT = comboT; G.sudo = sudo; G.sudoReady = sudo >= 100;
    for (int i = 0; i < np; i++) {
        Player& p = players[i]; TP& t = tp[i]; bool wasDead = p.dead; p.dead = t.fl & 1; p.connected = (t.fl & 2) != 0; p.dashT = (t.fl & 4) ? 0.1f : 0; p.iframes = (t.fl & 8) ? 0.3f : 0; if (i != localIdx) p.offer = (t.fl & 16) != 0;
        M.cpl[i] = { t.x, t.y, t.vx, t.vy }; p.ang = i == localIdx ? p.ang : t.ang; p.hp = t.hp; p.maxhp = std::max(1.f, t.maxhp); p.level = t.lvl; p.xp = t.xp; p.xpNeed = std::max(1.f, t.xpNeed); p.dashCd = (1.f - t.dashF) * p.st.dashCd; p.st.orbit = t.orbit; p.st.count = t.count; p.respawnT = t.resp;
        if (!wasDead && p.dead) { burst(p.x, p.y, p.col, 70, 420, 1.0f, 6); spawnShards(p.x, p.y, p.col, 26, 380, 16); ringFx(p.x, p.y, 500, 0.8f, p.col, 8); sfx(S_DIE); addShake(i == localIdx ? 26.f : 12.f); }
        if (wasDead && !p.dead) { ringFx(p.x, p.y, 240, 0.6f, p.col, 6); sfx(S_LEVEL); }
    }
    lasers = ls; for (auto& e : evs) clientEvent(e); for (auto& b : bms) if (beams.size() < 60) beams.push_back({ jag(b), 0.16f, 0.16f, false });
}
static bool gather(Gather& g, uint32_t tick, uint8_t part, uint8_t total, const uint8_t* p, size_t len, std::vector<uint8_t>& out) {
    if (total < 1 || total > 4 || part >= total) return false;
    if (tick != g.tick) { if (g.tick && (int32_t)(tick - g.tick) < 0) return false; g = Gather(); g.tick = tick; g.total = total; }
    if (g.total != total || ((g.mask >> part) & 1)) return false;
    g.part[part].assign(p, p + len); g.mask |= (uint8_t)(1u << part);
    if (g.mask != (uint8_t)((1u << total) - 1)) return false;
    out.clear(); for (int i = 0; i < total; i++) out.insert(out.end(), g.part[i].begin(), g.part[i].end()); return true;
}
static void clientList(const uint8_t* d, size_t n) {
    net::Reader r(d, n); uint8_t kind = r.u8(); uint32_t tick = r.u32(); uint8_t part = r.u8(), total = r.u8(), count = r.u8(); if (!r.ok) return;
    size_t rec = kind == U_ENEMIES ? 11 : kind == U_BULLETS ? 6 : kind == U_EBUL ? 8 : kind == U_GEMS ? 5 : 0; if (!rec || (size_t)count * rec != r.left()) { M.badRx++; return; }
    Gather& g = kind == U_ENEMIES ? M.gEn : kind == U_BULLETS ? M.gBu : kind == U_EBUL ? M.gEb : M.gGm; std::vector<uint8_t> all;
    if (!gather(g, tick, part, total, r.cur(), r.left(), all)) return;
    net::Reader rr(all.data(), all.size()); double now = net::nowSec(); M.listsRx++;
    if (kind == U_ENEMIES) { std::vector<CEnemy> v; while (rr.left() >= 11 && v.size() < 400) { CEnemy c; c.id = rr.u16(); c.tf = rr.u8(); c.x = rr.i16() / 16.f; c.y = rr.i16() / 16.f; c.vx = rr.i8() * 6.f; c.vy = rr.i8() * 6.f; c.hp = rr.u8(); c.aux = rr.u8(); v.push_back(c); } M.cEn.swap(v); M.listAt[0] = now; }
    else if (kind == U_BULLETS) { std::vector<CBullet> v; while (rr.left() >= 6 && v.size() < 500) { CBullet c; c.x = rr.i16() / 16.f; c.y = rr.i16() / 16.f; c.vx = rr.i8() * 8.f; c.vy = rr.i8() * 8.f; c.fl = rr.u8(); v.push_back(c); } M.cBu.swap(v); M.listAt[1] = now; }
    else if (kind == U_EBUL) { std::vector<CEBul> v; while (rr.left() >= 8 && v.size() < 500) { CEBul c; c.x = rr.i16() / 16.f; c.y = rr.i16() / 16.f; c.vx = rr.i8() * 4.f; c.vy = rr.i8() * 4.f; c.r = rr.u8() / 4.f; c.col = rr.u8(); v.push_back(c); } M.cEb.swap(v); M.listAt[2] = now; }
    else { std::vector<CGem> v; while (rr.left() >= 5 && v.size() < 500) { CGem c; c.x = rr.i16() / 16.f; c.y = rr.i16() / 16.f; c.mag = rr.u8(); v.push_back(c); } M.cGm.swap(v); M.listAt[3] = now; }
}
static void clientRel(const std::vector<uint8_t>& d) {
    net::Reader r(d.data(), d.size()); uint8_t k = r.u8(); if (!r.ok) return;
    if (k == R_ACCEPT) { /* joined; the lobby list follows */ }
    else if (k == R_REJECT) { M.notice = "HOST SAYS: " + r.str(40); if (r.ok) { M.cli.stop(); mpRole = 0; setState(ST_JOIN); SDL_StartTextInput(); } }
    else if (k == R_LOBBY) { int n = r.u8(); if (!r.ok || n < 1 || n > 4) return; std::vector<std::string> v; for (int i = 0; i < n; i++) v.push_back(cleanName(r.str(12))); if (r.ok) M.roster = v; }
    else if (k == R_START) {
        int n = r.u8(), my = r.u8(); if (!r.ok || n < 1 || n > 4 || my >= n) return; std::vector<std::string> names; for (int i = 0; i < n; i++) names.push_back(cleanName(r.str(12))); if (!r.ok) return;
        mpRole = 2; localIdx = my; resetWorld(false, n); mpRole = 2; curP = &players[my];
        for (int i = 0; i < n; i++) { snprintf(players[i].name, sizeof players[i].name, "%s", names[i].c_str()); players[i].remote = i != my; }
        M.lastSnapTick = 0; M.cEn.clear(); M.cBu.clear(); M.cEb.clear(); M.cGm.clear(); M.gEn = M.gBu = M.gEb = M.gGm = Gather(); for (auto& c : M.cpl) c = CPl(); M.snapAt = net::nowSec(); setState(ST_PLAY);
    }
    else if (k == R_BANNER) { std::string t = r.str(28), s2 = r.str(32); uint32_t col = r.u32(); if (r.ok) { G.banner.on = true; G.banner.t = 0; G.banner.dur = 2.4f; G.banner.text = t; G.banner.sub = s2; G.banner.col = col; } }
    else if (k == R_OFFER) { int8_t c[3]; for (int i = 0; i < 3; i++) c[i] = r.i8(); if (!r.ok) return; for (int i = 0; i < 3; i++) P.choices[i] = (c[i] >= 0 && c[i] < NUPG) ? c[i] : -1; P.offer = true; P.offerT = 14.f; sfx(S_LEVEL); }
    else if (k == R_OVER) {
        uint32_t sc = r.u32(); int wv = r.u8(); int tm = r.u16(); int kl = r.u16(); int nb = r.u8(); uint32_t best = r.u32(); int qi = r.u8(); if (!r.ok) return;
        G.score = sc; G.wave = wv; G.time = (float)tm; G.kills = kl; G.newBest = nb != 0; if (best > (uint32_t)STATS.best) STATS.best = (long)best; G.quote = QUOTES[qi % 6]; P.offer = false; setState(ST_OVER);
    }
}
static void clientBuildLists(double now) {
    double a0 = clampf((float)(now - M.listAt[0]), 0, 0.2f), a1 = clampf((float)(now - M.listAt[1]), 0, 0.2f), a2 = clampf((float)(now - M.listAt[2]), 0, 0.2f);
    enemies.clear();
    for (auto& c : M.cEn) {
        Enemy e; e.id = c.id; e.type = c.tf & 7; if (e.type > 6) continue; e.elite = (c.tf >> 3) & 1; e.flash = ((c.tf >> 4) & 1) ? 0.09f : 0.f; e.state = (c.tf >> 5) & 3; const TypeDef& T = TD[e.type];
        e.r = T.r * (e.elite ? 1.3f : 1.f); e.col = T.col; e.x = c.x + c.vx * (float)a0; e.y = c.y + c.vy * (float)a0; e.vx = c.vx; e.vy = c.vy; e.maxhp = 1000; e.hp = c.hp / 255.f * 1000.f; e.t = G.t + c.id * 0.37f;
        if (e.type == T_CHARGER) { float a = c.aux * TAU / 255.f; e.cx = cosf(a); e.cy = sinf(a); }
        else if (e.type == T_BOMB) e.fuse = c.aux ? c.aux / 200.f : -1.f;
        else if (e.type == T_BOSS) { e.kind = c.aux & 3; if (e.kind > 2) e.kind = 0; e.phase = 1 + ((c.aux >> 2) & 3); e.intro = ((c.aux >> 4) & 1) ? 0.7f : 0.f; e.col = BOSS_COLS[e.kind]; e.atk = 1; }
        enemies.push_back(e);
    }
    bullets.clear(); for (auto& c : M.cBu) { Bullet b; memset(&b, 0, sizeof b); b.x = c.x + c.vx * (float)a1; b.y = c.y + c.vy * (float)a1; b.vx = c.vx; b.vy = c.vy; b.r = 5; b.crit = c.fl & 1; bullets.push_back(b); }
    ebul.clear(); for (auto& c : M.cEb) { EBullet b; b.x = c.x + c.vx * (float)a2; b.y = c.y + c.vy * (float)a2; b.vx = c.vx; b.vy = c.vy; b.r = c.r; b.dmg = 0; b.life = 1; b.dead = false; b.col = PAL[c.col % 26]; ebul.push_back(b); }
    gems.clear(); for (auto& c : M.cGm) { Gem g; g.x = c.x; g.y = c.y; g.vx = g.vy = 0; g.v = 1; g.t = G.t + c.x * 0.01f; g.mag = c.mag; g.dead = false; gems.push_back(g); }
}
static void clientSendInput(float dt) {
    M.tIn += dt; if (M.tIn < 1.0 / 60) return; M.tIn = 0;
    Input in = M.botClient ? demoInput() : readInput();
    uint8_t b[16]; net::Writer w(b, sizeof b); w.u8(U_INPUT); w.u16(++M.inSeq); w.i8((int8_t)lroundf(clampf(in.mx, -1, 1) * 127)); w.i8((int8_t)lroundf(clampf(in.my, -1, 1) * 127));
    w.u16((uint16_t)(fmodf(in.ang + TAU * 4, TAU) / TAU * 65535)); w.u8((in.fire ? 1 : 0) | (in.dash ? 2 : 0) | (in.sudo ? 4 : 0)); if (w.ok) M.cli.sendU(b, w.n);
    P.ang = in.ang; M.shootT -= 1.0 / 60; if (in.fire && M.shootT <= 0) { sfx(S_SHOOT); M.shootT = 1 / 4.5; }
}
static void clientUpdate(float dt) {   // the client does not simulate: it presents the latest host state
    double now = net::nowSec(); G.t += dt;
    G.hurt = std::max(0.f, G.hurt - dt * 2.2f); G.flash = std::max(0.f, G.flash - dt * 2.5f); G.beat = std::max(0.f, G.beat - dt * 4);
    if (G.banner.on) { G.banner.t += dt; if (G.banner.t > G.banner.dur) G.banner.on = false; }
    float age = clampf((float)(now - M.snapAt), 0, 0.2f);
    for (size_t i = 0; i < players.size() && i < 4; i++) { Player& p = players[i]; p.x = M.cpl[i].x + M.cpl[i].vx * age; p.y = M.cpl[i].y + M.cpl[i].vy * age; p.orbAng += dt * 3.2f; if (p.offer && (int)i == localIdx) p.offerT -= dt; }
    if (P.offer && P.offerT <= -2) P.offer = false;
    clientBuildLists(now); refreshBoss(); G.bossAlive = boss != nullptr; G.intensity = G.bossAlive ? 3 : G.wave >= 4 ? 2 : 1;
    for (auto& L : lasers) { L.t += dt; if (L.t > L.tel + L.fire) L.dead = true; }
    lasers.erase(std::remove_if(lasers.begin(), lasers.end(), [](const Laser& b) { return b.dead; }), lasers.end());
    updateFx(dt); updateCamera(dt);
}
static void clientPump(float dt) {
    M.cli.poll();
    for (auto& e : M.cli.ev) {
        if (e.kind == net::Event::CONNECTED) { M.everConnected = true; uint8_t b[32]; net::Writer w(b, sizeof b); w.u8(R_JOIN); w.str(myName(), 12); M.cli.sendR(b, w.n); }
        else if (e.kind == net::Event::REL) clientRel(e.data);
        else if (e.kind == net::Event::UNREL && !e.data.empty()) { if (e.data[0] == U_SNAP) clientSnap(e.data.data(), e.data.size()); else clientList(e.data.data(), e.data.size()); }
        else if (e.kind == net::Event::DISCONNECTED) { /* handled through the FAILED state below */ }
    }
    M.cli.ev.clear();
    if (M.cli.st == net::Client::FAILED && mpRole == 2) {
        std::string why = M.cli.err; bool wasIn = M.everConnected; if (G.state == ST_LOBBY && !wasIn) { M.notice = why; return; }   // still on the connect screen: show the error there
        toMenu(); M.notice = wasIn ? "DISCONNECTED: " + why : why; return;
    }
    if (M.cli.st == net::Client::CONNECTED) {
        if (G.state == ST_PLAY || G.state == ST_PAUSE) clientSendInput(dt);
        else { M.tKeep += dt; if (M.tKeep > 0.1) { M.tKeep = 0; M.cli.sendU(nullptr, 0); } }
    }
}
static void netPump(float dt) { if (mpRole == 1) hostPump(dt); else if (mpRole == 2) clientPump(dt); }
static void clientChoose(int k) {
    if (mpRole != 2 || !P.offer || k < 0 || k > 2 || P.choices[k] < 0) return;
    uint8_t b[4]; net::Writer w(b, sizeof b); w.u8(R_CHOOSE); w.u8((uint8_t)k); M.cli.sendR(b, w.n); P.offer = false; sfx(S_UI);
}

// ============================================================================
//  input
// ============================================================================
static Input readInput() {
    Input in; in.ang = P.ang; if (G.state == ST_PAUSE) return in;   // a menu is open: stand still
    const Uint8* ks = SDL_GetKeyboardState(nullptr);
    float mx = 0, my = 0;
    if (ks[SDL_SCANCODE_A] || ks[SDL_SCANCODE_LEFT]) mx -= 1; if (ks[SDL_SCANCODE_D] || ks[SDL_SCANCODE_RIGHT]) mx += 1;
    if (ks[SDL_SCANCODE_W] || ks[SDL_SCANCODE_UP]) my -= 1; if (ks[SDL_SCANCODE_S] || ks[SDL_SCANCODE_DOWN]) my += 1;
    in.ang = P.ang; bool aimed = false;
    if (pad) {
        auto ax = [&](SDL_GameControllerAxis a) { float v = SDL_GameControllerGetAxis(pad, a) / 32767.f; return fabsf(v) < 0.18f ? 0.f : v; };
        float lx = ax(SDL_CONTROLLER_AXIS_LEFTX), ly = ax(SDL_CONTROLLER_AXIS_LEFTY), rx = ax(SDL_CONTROLLER_AXIS_RIGHTX), ry = ax(SDL_CONTROLLER_AXIS_RIGHTY);
        mx += lx; my += ly;
        if (sqrtf(rx * rx + ry * ry) > 0.3f) { in.ang = atan2f(ry, rx); in.fire = true; aimed = true; }
        if (SDL_GameControllerGetAxis(pad, SDL_CONTROLLER_AXIS_TRIGGERRIGHT) > 8000 || SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_RIGHTSHOULDER)) in.fire = true;
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_A) || SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_LEFTSHOULDER)) in.dash = true;
        if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_B) || SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_X)) in.sudo = true;
    }
    if (mouseSeen) {
        float z = viewZoom(), wx = camX + (mouseX - GX.W / 2.f) / z, wy = camY + (mouseY - GX.H / 2.f) / z;
        if (!aimed) in.ang = atan2f(wy - P.y, wx - P.x);
        if (mouseDown) in.fire = true;
    }
    if (ks[SDL_SCANCODE_SPACE] || ks[SDL_SCANCODE_LSHIFT] || ks[SDL_SCANCODE_RSHIFT]) in.dash = true;
    if (ks[SDL_SCANCODE_E] || ks[SDL_SCANCODE_Q]) in.sudo = true;
    in.mx = mx; in.my = my; return in;
}

// ============================================================================
//  rendering
// ============================================================================
static Col colOf(uint32_t h, float a = 1.f) { return hexc(h, a); }
static inline Pt toScreen(float x, float y, float z, float sx, float sy) { return { (x - camX) * z + GX.W * 0.5f + sx, (y - camY) * z + GX.H * 0.5f + sy }; }
static void polyPts(Pt* out, int n, float cx, float cy, float r, float rot) { for (int i = 0; i < n; i++) { float a = rot + i * TAU / n; out[i] = { cx + cosf(a) * r, cy + sinf(a) * r }; } }
static void shape(Pt* p, int n, Col fill, Col line, float w) { GX.mode(SDL_BLENDMODE_BLEND); GX.polyFill(p, n, fill); GX.mode(SDL_BLENDMODE_ADD); GX.polyStroke(p, n, true, w, line); }

// ---- models: every enemy is a small assembly of shaded parts (fan-gradient hulls, plates, rim light, animated details) ----
struct Xf { float cx, cy, ca, sa, r; Pt p(float x, float y) const { return { cx + (x * ca - y * sa) * r, cy + (x * sa + y * ca) * r }; } };
static Col shade(uint32_t h, float k, float a = 1.f) { Col c = hexc(h, a); c.r = (uint8_t)clampf(c.r * k, 0, 255); c.g = (uint8_t)clampf(c.g * k, 0, 255); c.b = (uint8_t)clampf(c.b * k, 0, 255); return c; }
static void hullFill(const Pt* p, int n, Pt c, Col cc, Col ec) { GX.mode(SDL_BLENDMODE_BLEND); GX.polyFillGrad(p, n, c, cc, ec); }
static void hullLine(const Pt* p, int n, bool closed, float w, Col c) { GX.mode(SDL_BLENDMODE_ADD); GX.polyStroke(p, n, closed, w, c); }
static void segLine(Pt a, Pt b, float w, Col c) { GX.mode(SDL_BLENDMODE_ADD); GX.line(a.x, a.y, b.x, b.y, w, c); }
static void arcStroke(float cx, float cy, float r, float a0, float a1, float w, Col c) {
    int seg = std::max(3, (int)((a1 - a0) / TAU * 40));
    for (int i = 0; i < seg; i++) { float u0 = lerpf(a0, a1, i / (float)seg), u1 = lerpf(a0, a1, (i + 1) / (float)seg); GX.line(cx + cosf(u0) * r, cy + sinf(u0) * r, cx + cosf(u1) * r, cy + sinf(u1) * r, w, c); }
}
static Pt centroid(const Pt* p, int n) { Pt c = { 0, 0 }; for (int i = 0; i < n; i++) { c.x += p[i].x; c.y += p[i].y; } return { c.x / n, c.y / n }; }
static void plate(float cx, float cy, float r0, float r1, float a0, float a1, Col cc, Col ec, Col rim, float lw) {
    Pt q[4] = { { cx + cosf(a0) * r0, cy + sinf(a0) * r0 }, { cx + cosf(a0) * r1, cy + sinf(a0) * r1 }, { cx + cosf(a1) * r1, cy + sinf(a1) * r1 }, { cx + cosf(a1) * r0, cy + sinf(a1) * r0 } };
    hullFill(q, 4, centroid(q, 4), cc, ec); hullLine(q, 4, true, lw, rim);
}
static void drawBoss(const Enemy& e, float z, Pt c, float R, bool fl, float lw) {
    Col base = fl ? WHITE : colOf(e.col), mid = fl ? colOf(0xffffff, 0.9f) : shade(e.col, 0.5f, 0.97f), dark = fl ? colOf(0xffffff, 0.8f) : shade(e.col, 0.13f, 0.97f);
    Player& pt = *nearestPlayer(e.x, e.y); float face = atan2f(pt.y - e.y, pt.x - e.x), sc = e.intro > 0 ? 1 - e.intro / 1.4f : 1.f; R *= sc;
    if (e.intro > 0) { base.a = 130; }
    float rot = e.t * 0.4f;
    if (e.kind == 0) {   // HYDRA: three heads on necks
        for (int i = 0; i < 3; i++) {
            float a = e.t * 0.7f + i * TAU / 3, snap = e.atk < 0.25f ? 1.f : 0.f; Pt hp = { c.x + cosf(a) * R * 1.5f, c.y + sinf(a) * R * 1.5f };
            segLine(c, hp, lw * 3.2f, withA(base, 0.35f)); segLine(c, hp, lw * 1.2f, base);
            Pt hx[6]; polyPts(hx, 6, hp.x, hp.y, R * 0.27f, a); hullFill(hx, 6, hp, mid, dark); hullLine(hx, 6, true, lw, base);
            float ea = atan2f(P.y - hp.y / 1.f + 0.f, 0) * 0; (void)ea; float fa = atan2f((P.y - e.y), (P.x - e.x));
            GX.mode(SDL_BLENDMODE_ADD); GX.fillCircle(hp.x + cosf(fa) * R * 0.07f, hp.y + sinf(fa) * R * 0.07f, R * (0.07f + 0.04f * snap), WHITE, 10);
            segLine({ hp.x + cosf(a) * R * 0.2f, hp.y + sinf(a) * R * 0.2f }, { hp.x + cosf(a + 0.5f) * R * 0.42f, hp.y + sinf(a + 0.5f) * R * 0.42f }, lw, base);
            segLine({ hp.x + cosf(a) * R * 0.2f, hp.y + sinf(a) * R * 0.2f }, { hp.x + cosf(a - 0.5f) * R * 0.42f, hp.y + sinf(a - 0.5f) * R * 0.42f }, lw, base);
        }
    } else if (e.kind == 1) {   // ZERO-DAY: crystal spikes
        for (int i = 0; i < 8; i++) {
            float a = e.t * 0.3f + i * TAU / 8, len = R * (1.55f + 0.16f * sinf(e.t * 3 + i * 1.7f));
            Pt sp[3] = { { c.x + cosf(a - 0.2f) * R * 0.85f, c.y + sinf(a - 0.2f) * R * 0.85f }, { c.x + cosf(a) * len, c.y + sinf(a) * len }, { c.x + cosf(a + 0.2f) * R * 0.85f, c.y + sinf(a + 0.2f) * R * 0.85f } };
            hullFill(sp, 3, { c.x + cosf(a) * R, c.y + sinf(a) * R }, mid, dark); hullLine(sp, 3, true, lw, base);
            GX.mode(SDL_BLENDMODE_ADD, GX.glowT); GX.glow(sp[1].x, sp[1].y, R * 0.16f, withA(base, 0.7f));
        }
    } else {   // SEGFAULT: fractured shards that jitter like a corrupted buffer
        int seed = (int)(e.t * 9); for (int i = 0; i < 6; i++) {
            uint32_t h = (uint32_t)(seed * 2654435761u + i * 40503u); float jx = ((h & 255) / 255.f - 0.5f) * R * 0.18f, jy = (((h >> 8) & 255) / 255.f - 0.5f) * R * 0.18f, a = rot + i * TAU / 6;
            Pt sh[3] = { { c.x + jx + cosf(a) * R * 0.9f, c.y + jy + sinf(a) * R * 0.9f }, { c.x + jx + cosf(a + 0.5f) * R * 1.35f, c.y + jy + sinf(a + 0.5f) * R * 1.35f }, { c.x + jx + cosf(a + 1.0f) * R * 0.9f, c.y + jy + sinf(a + 1.0f) * R * 0.9f } };
            hullFill(sh, 3, centroid(sh, 3), mid, dark); hullLine(sh, 3, true, lw, base);
        }
        if (((int)(e.t * 6)) % 5 == 0) { float y = c.y + (((seed * 37) % 100) / 100.f - 0.5f) * R * 2; segLine({ c.x - R * 1.6f, y }, { c.x + R * 1.6f, y }, lw * 0.8f, withA(base, 0.6f)); }
    }
    for (int i = 0; i < 8; i++) plate(c.x, c.y, R * 0.7f, R, rot + i * TAU / 8 + 0.06f, rot + (i + 1) * TAU / 8 - 0.06f, mid, dark, base, lw);   // outer armor ring
    for (int i = 0; i < 6; i++) { float a = -e.t * 0.9f + i * TAU / 6; arcStroke(c.x, c.y, R * 0.6f, a, a + 0.75f, lw * 1.2f, withA(base, 0.85f)); }   // inner ring
    GX.mode(SDL_BLENDMODE_BLEND); GX.fillCircle(c.x, c.y, R * 0.44f, dark, 28);
    GX.mode(SDL_BLENDMODE_ADD); GX.ringStroke(c.x, c.y, R * 0.44f, lw, base, 28);
    float pulse = 1 + sinf(e.t * 6) * 0.06f; Pt iris = { c.x + cosf(face) * R * 0.11f, c.y + sinf(face) * R * 0.11f };
    Col core = e.phase == 3 ? colOf(0xffffff, 0.6f + 0.4f * sinf(e.t * 14)) : base;
    GX.mode(SDL_BLENDMODE_ADD, GX.glowT); GX.glow(iris.x, iris.y, R * 0.75f, withA(core, 0.6f));
    GX.mode(SDL_BLENDMODE_ADD); GX.fillCircle(iris.x, iris.y, R * 0.24f * pulse, core, 22); GX.fillCircle(iris.x + cosf(face) * R * 0.05f, iris.y + sinf(face) * R * 0.05f, R * 0.09f, colOf(0x120818), 12);
    if (e.phase == 3) for (int i = 0; i < 7; i++) { uint32_t h = (uint32_t)(i * 7919 + (int)(e.t * 12) * 104729u); float a = i * TAU / 7 + (h & 63) / 64.f * 0.4f, l = R * (0.55f + (h % 40) / 100.f); segLine({ c.x + cosf(a) * R * 0.44f, c.y + sinf(a) * R * 0.44f }, { c.x + cosf(a) * l, c.y + sinf(a) * l }, lw * 0.7f, colOf(0xffffff, 0.8f)); }
    for (int i = 0; i < 4; i++) { float a = e.t * 1.6f + i * TAU / 4; GX.mode(SDL_BLENDMODE_ADD, GX.glowT); GX.glow(c.x + cosf(a) * R * 1.12f, c.y + sinf(a) * R * 1.12f, R * 0.16f, withA(base, 0.9f)); }
}
static void drawEnemy(const Enemy& e, float z, float sx, float sy) {
    Pt c = toScreen(e.x, e.y, z, sx, sy); float r = e.r * z, lw = std::max(1.2f, (e.type == T_BOSS ? 3.2f : 2.0f) * z);
    bool fl = e.flash > 0; Col rim = fl ? WHITE : colOf(e.col), hc = fl ? colOf(0xffffff, 0.92f) : shade(e.col, 0.42f, 0.96f), he = fl ? colOf(0xffffff, 0.85f) : shade(e.col, 0.11f, 0.96f);
    GX.mode(SDL_BLENDMODE_ADD, GX.glowT); GX.glow(c.x, c.y, r * 2.6f, colOf(e.col, e.type == T_BOSS ? 0.5f : 0.3f));
    Player& pt = *nearestPlayer(e.x, e.y); float face = atan2f(pt.y - e.y, pt.x - e.x); Pt pts[16];
    switch (e.type) {
        case T_WORM: {   // segmented body with a wiggling tail, mandibles and eyes
            float a = (fabsf(e.vx) + fabsf(e.vy) > 1) ? atan2f(e.vy, e.vx) : face; Xf x = { c.x, c.y, cosf(a), sinf(a), r };
            for (int i = 3; i >= 1; i--) { Pt sp = x.p(-i * 0.95f, sinf(e.t * 9 - i * 1.2f) * 0.38f); float sr = r * (0.78f - 0.13f * i); GX.mode(SDL_BLENDMODE_BLEND); GX.fillCircle(sp.x, sp.y, sr, he, 14); GX.mode(SDL_BLENDMODE_ADD); GX.ringStroke(sp.x, sp.y, sr, lw * 0.8f, withA(rim, 0.85f), 14); }
            Pt h[6] = { x.p(1.15f, 0), x.p(0.4f, -0.62f), x.p(-0.5f, -0.55f), x.p(-0.75f, 0), x.p(-0.5f, 0.55f), x.p(0.4f, 0.62f) };
            hullFill(h, 6, x.p(0.1f, 0), hc, he); hullLine(h, 6, true, lw, rim);
            segLine(x.p(1.05f, -0.18f), x.p(1.6f, -0.62f), lw * 0.9f, rim); segLine(x.p(1.05f, 0.18f), x.p(1.6f, 0.62f), lw * 0.9f, rim);
            GX.mode(SDL_BLENDMODE_ADD); Pt e1 = x.p(0.45f, -0.25f), e2 = x.p(0.45f, 0.25f); GX.fillCircle(e1.x, e1.y, r * 0.13f, WHITE, 8); GX.fillCircle(e2.x, e2.y, r * 0.13f, WHITE, 8); break; }
        case T_TROJAN: {   // armored plates around a glowing core
            float rot = e.t * 0.6f;
            for (int i = 0; i < 6; i++) plate(c.x, c.y, r * 0.6f, r, rot + i * TAU / 6 + 0.09f, rot + (i + 1) * TAU / 6 - 0.09f, hc, he, rim, lw);
            polyPts(pts, 6, c.x, c.y, r * 0.52f, -rot); hullFill(pts, 6, c, he, he); hullLine(pts, 6, true, lw * 0.8f, withA(rim, 0.7f));
            float pu = 1 + 0.2f * sinf(e.t * 5); GX.mode(SDL_BLENDMODE_ADD, GX.glowT); GX.glow(c.x, c.y, r * 0.8f, colOf(0xffd08a, 0.7f)); GX.mode(SDL_BLENDMODE_ADD); GX.fillCircle(c.x, c.y, r * 0.2f * pu, colOf(0xfff0d0), 12); break; }
        case T_SPY: {   // a blinking, scanning eye inside corner brackets
            for (int i = 0; i < 4; i++) { float a = PI / 4 + i * PI / 2 + e.t * 0.5f; Pt k = { c.x + cosf(a) * r * 1.3f, c.y + sinf(a) * r * 1.3f }; segLine(k, { k.x - cosf(a + 0.9f) * r * 0.42f, k.y - sinf(a + 0.9f) * r * 0.42f }, lw, withA(rim, 0.9f)); segLine(k, { k.x - cosf(a - 0.9f) * r * 0.42f, k.y - sinf(a - 0.9f) * r * 0.42f }, lw, withA(rim, 0.9f)); }
            float bl = fmodf(e.t + e.id * 0.37f, 3.4f), lid = bl > 3.22f ? 0.12f : 1.f; int n = 0;
            for (int k = 0; k <= 8; k++) { float u = -1 + 2 * k / 8.f; pts[n++] = { c.x + u * r * 1.05f, c.y - (1 - u * u) * r * 0.62f * lid }; }
            for (int k = 7; k >= 1; k--) { float u = -1 + 2 * k / 8.f; pts[n++] = { c.x + u * r * 1.05f, c.y + (1 - u * u) * r * 0.62f * lid }; }
            hullFill(pts, n, c, hc, he); hullLine(pts, n, true, lw, rim);
            Pt ip = { c.x + cosf(face) * r * 0.22f, c.y + sinf(face) * r * 0.12f * lid }; GX.mode(SDL_BLENDMODE_ADD); GX.fillCircle(ip.x, ip.y, r * 0.34f * lid, withA(rim, 0.9f), 14); GX.rect(ip.x - r * 0.05f, ip.y - r * 0.3f * lid, r * 0.1f, r * 0.6f * lid, colOf(0x120818));
            for (int i = 0; i < 8; i += 2) arcStroke(c.x, c.y, r * 1.62f, e.t * 1.4f + i * TAU / 8, e.t * 1.4f + i * TAU / 8 + 0.45f, lw * 0.7f, withA(rim, 0.45f)); break; }
        case T_RANSOM: {   // a rotating crate with a padlock stamped on it
            float rr = e.t * 0.8f; Xf x = { c.x, c.y, cosf(rr), sinf(rr), r * 1.05f }; Pt sq4[4] = { x.p(-1, -1), x.p(1, -1), x.p(1, 1), x.p(-1, 1) };
            hullFill(sq4, 4, c, hc, he); hullLine(sq4, 4, true, lw, rim); Pt in4[4] = { x.p(-0.7f, -0.7f), x.p(0.7f, -0.7f), x.p(0.7f, 0.7f), x.p(-0.7f, 0.7f) }; hullLine(in4, 4, true, lw * 0.6f, withA(rim, 0.5f));
            Pt body[4] = { { c.x - r * 0.42f, c.y - r * 0.02f }, { c.x + r * 0.42f, c.y - r * 0.02f }, { c.x + r * 0.42f, c.y + r * 0.55f }, { c.x - r * 0.42f, c.y + r * 0.55f } };
            hullFill(body, 4, centroid(body, 4), colOf(0xffd0d0, 0.9f), shade(e.col, 0.9f, 0.9f)); GX.mode(SDL_BLENDMODE_ADD); arcStroke(c.x, c.y - r * 0.02f, r * 0.27f, PI, TAU, lw * 1.1f, WHITE); GX.fillCircle(c.x, c.y + r * 0.24f, r * 0.07f, colOf(0x2a0a0a), 8); break; }
        case T_CHARGER: {   // fins, a racing stripe, and an engine flame while dashing
            float a = (e.state == 1 || e.state == 2) ? atan2f(e.cy, e.cx) : face; Xf x = { c.x, c.y, cosf(a), sinf(a), r };
            if (e.state == 1) { GX.mode(SDL_BLENDMODE_ADD); float al = 0.35f + 0.35f * sinf(e.t * 40); for (int k = 0; k < 10; k++) GX.line(c.x + x.ca * (r + k * 52 * z), c.y + x.sa * (r + k * 52 * z), c.x + x.ca * (r + k * 52 * z + 26 * z), c.y + x.sa * (r + k * 52 * z + 26 * z), 3 * z, colOf(0xff5f7e, al)); Pt n = x.p(1.3f, 0); GX.mode(SDL_BLENDMODE_ADD, GX.glowT); GX.glow(n.x, n.y, r * 1.2f, colOf(0xff8fa0, 0.9f)); }
            float fl2 = e.state == 2 ? 2.2f : 0.5f + 0.2f * sinf(e.t * 30); Pt f[3] = { x.p(-0.55f, -0.22f), x.p(-0.55f - fl2, 0), x.p(-0.55f, 0.22f) }; GX.mode(SDL_BLENDMODE_ADD); GX.polyFill(f, 3, colOf(e.state == 2 ? 0xffffff : 0xffd08a, 0.8f));
            Pt h[6] = { x.p(1.3f, 0), x.p(0.25f, -0.5f), x.p(-0.9f, -0.95f), x.p(-0.5f, 0), x.p(-0.9f, 0.95f), x.p(0.25f, 0.5f) };
            hullFill(h, 6, x.p(0.2f, 0), hc, he); hullLine(h, 6, true, lw, e.state == 1 && ((int)(e.t * 20) & 1) ? WHITE : rim); segLine(x.p(0.95f, 0), x.p(-0.35f, 0), lw * 0.8f, withA(rim, 0.7f)); break; }
        case T_BOMB: {   // hazard-striped sphere with a lit fuse
            float pulse = e.fuse >= 0 ? 0.5f + 0.5f * sinf(e.t * (10 + (1.1f - e.fuse) * 22)) : 0.f;
            GX.mode(SDL_BLENDMODE_BLEND); GX.fillCircle(c.x, c.y, r, he, 22);
            for (int i = 0; i < 8; i++) { float a0 = e.t * 0.5f + i * TAU / 8, a1 = a0 + TAU / 16; GX.mode(SDL_BLENDMODE_ADD); arcStroke(c.x, c.y, r * 0.8f, a0, a1, r * 0.3f, i % 2 ? colOf(0xffa940, 0.9f) : colOf(0x3a1a06, 0.9f)); }
            GX.mode(SDL_BLENDMODE_ADD); GX.ringStroke(c.x, c.y, r, lw, mixc(rim, WHITE, pulse), 22); GX.mode(SDL_BLENDMODE_ADD, GX.glowT); GX.glow(c.x, c.y, r * 1.2f, colOf(0xff8a3d, 0.4f + 0.5f * pulse));
            GX.mode(SDL_BLENDMODE_ADD); GX.fillCircle(c.x, c.y, r * (0.28f + 0.2f * pulse), mixc(colOf(0xffd08a), WHITE, pulse), 14);
            Pt sp = { c.x + r * 0.25f, c.y - r * 1.2f }; segLine({ c.x, c.y - r * 0.95f }, sp, lw * 0.8f, colOf(0xc8a070)); GX.mode(SDL_BLENDMODE_ADD, GX.glowT); GX.glow(sp.x, sp.y, r * (0.4f + 0.2f * sinf(e.t * 40)), colOf(0xfff0a0, 0.9f));
            if (e.fuse >= 0) { GX.mode(SDL_BLENDMODE_ADD); GX.ringStroke(c.x, c.y, 130 * z, 2 * z, colOf(0xff8a3d, 0.25f + 0.4f * pulse), 48); } break; }
        case T_BOSS: drawBoss(e, z, c, r, fl, lw); break;
    }
    if (e.elite) { GX.mode(SDL_BLENDMODE_ADD); GX.ringStroke(c.x, c.y, r + 7 * z, 1.6f * z, colOf(0xffffff, 0.5f + 0.3f * sinf(e.t * 8)), 24); arcStroke(c.x, c.y, r + 12 * z, e.t * 2, e.t * 2 + 1.2f, 1.6f * z, colOf(0xffffff, 0.8f)); }
}
static void drawPlayerShip(float z, float sx, float sy) {
    Pt c = toScreen(P.x, P.y, z, sx, sy); float ca = cosf(P.ang), sa = sinf(P.ang), spd = sqrtf(P.vx * P.vx + P.vy * P.vy);
    float lat = spd > 5 ? clampf((-sa * P.vx + ca * P.vy) / 285.f, -1, 1) : 0.f;   // banking: lateral velocity tilts the wings
    Xf x = { c.x, c.y, ca, sa, 1.25f * z }; float al = (P.iframes > 0 && !G.demo && ((int)(G.t * 30) & 1)) ? 0.35f : 1.f;
    GX.mode(SDL_BLENDMODE_ADD, GX.glowT); GX.glow(c.x, c.y, 50 * z, colOf(P.col, 0.42f * al)); GX.glow(c.x, c.y, 92 * z, colOf(0x7c3aed, 0.26f * al));
    float flame = clampf(spd / 285.f, 0, 1.4f) * 15 + 4 + sinf(G.t * 60) * 1.6f; if (P.dashT > 0) flame = 30;
    Pt fl[3] = { x.p(-11, -3), x.p(-11 - flame, 0), x.p(-11, 3) }; GX.mode(SDL_BLENDMODE_ADD); GX.polyFill(fl, 3, colOf(P.col, 0.75f * al)); Pt fl2[3] = { x.p(-11, -1.5f), x.p(-11 - flame * 0.6f, 0), x.p(-11, 1.5f) }; GX.polyFill(fl2, 3, colOf(0xffffff, 0.9f * al));
    for (int sgn = -1; sgn <= 1; sgn += 2) {   // swept wings with a small pod on each tip
        float bank = 1 - 0.28f * lat * sgn, tipx = -16 + 3 * lat * sgn; Pt w[5] = { x.p(5, sgn * 5.f), x.p(-6, sgn * 17.5f * bank), x.p(tipx, sgn * 15 * bank), x.p(-15, sgn * 7), x.p(-10, sgn * 4.5f) };
        hullFill(w, 5, x.p(-6, sgn * 9.f), colOf(0x1b3550, al), colOf(0x0a1622, al)); hullLine(w, 5, true, 2.f * z, colOf(P.col, al));
        Pt pod = x.p(-6, sgn * 17.5f * bank); GX.mode(SDL_BLENDMODE_ADD, GX.glowT); GX.glow(pod.x, pod.y, 6 * z, colOf(0xc084fc, 0.9f * al));
    }
    Pt h[8] = { x.p(19, 0), x.p(8, -4.5f), x.p(-2, -6.5f), x.p(-11, -4), x.p(-9, 0), x.p(-11, 4), x.p(-2, 6.5f), x.p(8, 4.5f) };
    hullFill(h, 8, x.p(4, 0), colOf(0x2a5680, al), colOf(0x0d1b2a, al)); hullLine(h, 8, true, 2.4f * z, colOf(P.col, al));
    segLine(x.p(14, 0), x.p(-6, 0), 1.2f * z, colOf(0xa5f3fc, 0.55f * al));
    int nb = std::min(P.st.count, 5); for (int i = 0; i < nb; i++) { float o = (i - (nb - 1) / 2.f) * 2.2f; segLine(x.p(12, o), x.p(21, o * 1.4f), 1.8f * z, colOf(0xe0f7ff, al)); }
    GX.mode(SDL_BLENDMODE_ADD, GX.glowT); Pt ck = x.p(6, 0); GX.glow(ck.x, ck.y, 9 * z, colOf(0xe0f7ff, al)); GX.mode(SDL_BLENDMODE_ADD); GX.fillCircle(ck.x, ck.y, 2.6f * z, WHITE, 8);
    if (P.iframes > 0 && !G.demo) { Pt sh[6]; polyPts(sh, 6, c.x, c.y, 24 * z, G.t * 3); GX.mode(SDL_BLENDMODE_ADD); GX.polyStroke(sh, 6, true, 2 * z, colOf(P.col, 0.5f * P.iframes)); }
}
static void drawBackground(float z, float sx, float sy) {
    static const char* GL[] = { "0X7F", "SUDO", "RM -RF", "/DEV/NULL", "0101", "EMERGE", "CHMOD", "SIGKILL", "0XDEAD", "RING0", "/BOOT", "PANIC", "FORK()", "0XFF" };
    struct BG { float x, y, s; int t; float sp; }; static std::vector<BG> bg;
    if (bg.empty()) for (int i = 0; i < 46; i++) bg.push_back({ rnd01(), rnd01(), rndr(0.3f, 0.9f), irnd(14), rndr(0.006f, 0.02f) });
    for (auto& g : bg) {
        g.y += g.sp * 0.016f; if (g.y > 1.05f) { g.y = -0.05f; g.x = rnd01(); }
        float px = fmodf(fmodf(g.x - camX * 0.00012f * g.s, 1.f) + 1.f, 1.f);
        GX.text(GL[g.t], px * GX.W, g.y * GX.H, 1.6f * std::max(1.f, GX.H / 720.f), colOf(0xa78bfa, 0.05f + 0.08f * g.s));
    }
    Col ac = colOf(G.accent); float pulse = G.beat * 0.07f + (G.bossAlive ? 0.03f : 0.f);
    Pt a = toScreen(WX0, WY0, z, sx, sy), b = toScreen(WX1, WY1, z, sx, sy);
    GX.mode(SDL_BLENDMODE_BLEND); GX.rect(a.x, a.y, b.x - a.x, b.y - a.y, colOf(0x0a0518));
    {   // parallax nebula clouds + twinkling stars, tinted by the current wave color
        struct Neb { float x, y, r; int hue; }; static const Neb nb[7] = { { -900, -500, 700, 0 }, { 600, -700, 620, 1 }, { 1100, 300, 760, 0 }, { -300, 500, 680, 2 }, { -1200, 400, 560, 1 }, { 200, -100, 820, 2 }, { 900, 800, 500, 0 } };
        GX.mode(SDL_BLENDMODE_ADD, GX.glowT);
        for (auto& n : nb) { Pt p = toScreen(n.x - camX * 0.35f + camX, n.y - camY * 0.35f + camY, z, sx, sy); Col cc = n.hue == 0 ? colOf(G.accent, 0.10f) : n.hue == 1 ? colOf(0x2244aa, 0.08f) : colOf(0x7a1f6a, 0.07f); GX.glow(p.x, p.y, n.r * z, cc); }
        struct Star { float x, y, pf, ph; }; static std::vector<Star> stars; if (stars.empty()) for (int i = 0; i < 110; i++) stars.push_back({ rnd01(), rnd01(), rndr(0.15f, 0.55f), rndr(0, TAU) });
        for (auto& st : stars) { float px = fmodf(fmodf(st.x - camX * 0.0002f * st.pf, 1.f) + 1.f, 1.f), py = fmodf(fmodf(st.y - camY * 0.0002f * st.pf, 1.f) + 1.f, 1.f); float tw = 0.5f + 0.5f * sinf(G.t * 2 + st.ph); GX.glow(px * GX.W, py * GX.H, 2.5f + st.pf * 3, colOf(0xcfd8ff, 0.10f + 0.20f * tw * st.pf)); }
    }
    float vx0 = camX - GX.W / 2 / z, vx1 = camX + GX.W / 2 / z, vy0 = camY - GX.H / 2 / z, vy1 = camY + GX.H / 2 / z;
    float ax0 = std::max(vx0, WX0), ax1 = std::min(vx1, WX1), ay0 = std::max(vy0, WY0), ay1 = std::min(vy1, WY1); const float S = 100;
    GX.mode(SDL_BLENDMODE_ADD);
    for (float x = ceilf(ax0 / S) * S; x <= ax1; x += S) { bool major = ((int)roundf(x / S)) % 5 == 0; Pt p0 = toScreen(x, ay0, z, sx, sy), p1 = toScreen(x, ay1, z, sx, sy); GX.line(p0.x, p0.y, p1.x, p1.y, major ? 1.6f : 1.f, withA(ac, (major ? 0.20f : 0.10f) + pulse)); }
    for (float y = ceilf(ay0 / S) * S; y <= ay1; y += S) { bool major = ((int)roundf(y / S)) % 5 == 0; Pt p0 = toScreen(ax0, y, z, sx, sy), p1 = toScreen(ax1, y, z, sx, sy); GX.line(p0.x, p0.y, p1.x, p1.y, major ? 1.6f : 1.f, withA(ac, (major ? 0.20f : 0.10f) + pulse)); }
    Col bc = G.bossAlive ? colOf(0xff3d81) : ac; Pt q[4] = { a, { b.x, a.y }, b, { a.x, b.y } };
    GX.polyStroke(q, 4, true, 14, withA(bc, 0.12f + pulse)); GX.polyStroke(q, 4, true, 6, withA(bc, 0.35f)); GX.polyStroke(q, 4, true, 2, colOf(0xffffff, 0.85f));
}
static void drawWorld(float z, float sx, float sy) {
    for (auto& g : gems) {
        Pt c = toScreen(g.x, g.y, z, sx, sy); GX.mode(SDL_BLENDMODE_ADD, GX.glowT); GX.glow(c.x, c.y, 16 * z, colOf(0x38bdf8, 0.55f));
        float k = fabsf(cosf(g.t * 3)), w = (2.2f + 3.2f * k) * z, hh = 6 * z;   // tumbling crystal: width breathes as it turns
        Pt lf[3] = { { c.x, c.y - hh }, { c.x, c.y + hh }, { c.x - w, c.y } }, rt[3] = { { c.x, c.y - hh }, { c.x + w, c.y }, { c.x, c.y + hh } };
        GX.mode(SDL_BLENDMODE_BLEND); GX.polyFill(lf, 3, colOf(0xe0f7ff)); GX.polyFill(rt, 3, colOf(0x60b8f0));
    }
    for (auto& L : lasers) {
        Pt a = toScreen(L.x, L.y, z, sx, sy); float ex = cosf(L.ang), ey = sinf(L.ang), len = 4000 * z; GX.mode(SDL_BLENDMODE_ADD);
        if (L.t < L.tel) { float al = 0.25f + 0.35f * sinf(L.t * 40); GX.line(a.x, a.y, a.x + ex * len, a.y + ey * len, 2.f * z + 1, colOf(L.col, al)); }
        else { float k = 1 - (L.t - L.tel) / L.fire; GX.line(a.x, a.y, a.x + ex * len, a.y + ey * len, 46 * z * (0.5f + k), colOf(L.col, 0.35f * k)); GX.line(a.x, a.y, a.x + ex * len, a.y + ey * len, 16 * z * (0.5f + k), colOf(0xffffff, 0.9f * k)); }
    }
    for (auto& e : enemies) if (!e.dead) drawEnemy(e, z, sx, sy);
    GX.mode(SDL_BLENDMODE_ADD, GX.glowT);
    for (auto& b : bullets) { Pt c = toScreen(b.x, b.y, z, sx, sy); GX.glow(c.x, c.y, (b.crit ? 20 : 15) * z, b.crit ? colOf(0xffe14d, 0.85f) : colOf(0x67e8f9, 0.85f)); }
    GX.mode(SDL_BLENDMODE_ADD);
    for (auto& b : bullets) { Pt c = toScreen(b.x, b.y, z, sx, sy); GX.line(c.x, c.y, c.x - b.vx * 0.04f * z, c.y - b.vy * 0.04f * z, 3.4f * z, b.crit ? colOf(0xffe14d, 0.9f) : colOf(0xa5f3fc, 0.9f)); }
    GX.mode(SDL_BLENDMODE_ADD, GX.glowT);
    for (auto& b : ebul) { Pt c = toScreen(b.x, b.y, z, sx, sy); GX.glow(c.x, c.y, b.r * 3.2f * z, colOf(b.col, 0.8f)); }
    GX.mode(SDL_BLENDMODE_ADD);
    for (auto& b : ebul) { Pt c = toScreen(b.x, b.y, z, sx, sy); GX.fillCircle(c.x, c.y, b.r * 0.55f * z, WHITE, 8); }
    for (auto& pl : players) {
        if (pl.dead || !pl.connected) continue; curP = &pl;
        drawPlayerShip(z, sx, sy);
        for (int i = 0; i < P.st.orbit; i++) {
            float a = P.orbAng + i * TAU / P.st.orbit; Pt o = toScreen(P.x + cosf(a) * 70, P.y + sinf(a) * 70, z, sx, sy);
            GX.mode(SDL_BLENDMODE_ADD, GX.glowT); GX.glow(o.x, o.y, 30 * z, colOf(0xc084fc, 0.6f));
            Pt bl[4]; polyPts(bl, 4, o.x, o.y, 13 * z, PI / 4 + G.t * 8); hullFill(bl, 4, { o.x, o.y }, colOf(0x7c3aed), colOf(0x2a0f5a)); hullLine(bl, 4, true, 2 * z, colOf(0xf5e8ff));
        }
    }
    curP = &players[localIdx];
    GX.mode(SDL_BLENDMODE_ADD, GX.glowT);
    for (auto& q : parts) { float k = q.life / q.max; Pt c = toScreen(q.x, q.y, z, sx, sy); GX.glow(c.x, c.y, q.s * (0.6f + k) * 2.2f * z, colOf(q.col, clampf(k * 1.2f, 0, 1))); }
    GX.mode(SDL_BLENDMODE_ADD);
    for (auto& r : rings) { float k = r.t / r.life, rad = r.max * (1 - powf(1 - k, 3)); Pt c = toScreen(r.x, r.y, z, sx, sy); GX.ringStroke(c.x, c.y, rad * z, (r.w * (1 - k) + 1) * z, colOf(r.col, (1 - k) * 0.9f)); }
    for (auto& pl : players) if (players.size() > 1 && !pl.dead && pl.connected) { Pt c = toScreen(pl.x, pl.y, z, sx, sy); float hr = clampf(pl.hp / pl.maxhp, 0, 1);
        GX.mode(SDL_BLENDMODE_BLEND); GX.text(pl.name, c.x, c.y - 38 * z, 1.3f, colOf(pl.col, 0.9f), 1); GX.rect(c.x - 18 * z, c.y - 26 * z, 36 * z, 3.f, colOf(0x000000, 0.6f)); GX.rect(c.x - 18 * z, c.y - 26 * z, 36 * z * hr, 3.f, hr > 0.4f ? colOf(0x4ade80) : colOf(0xfb7185));
        GX.mode(SDL_BLENDMODE_ADD); }
    for (auto& h : shards) { float k = h.life / h.max; Pt c = toScreen(h.x, h.y, z, sx, sy); float cx2 = cosf(h.rot) * h.len * 0.5f * z, cy2 = sinf(h.rot) * h.len * 0.5f * z; GX.line(c.x - cx2, c.y - cy2, c.x + cx2, c.y + cy2, 2.4f * z, colOf(h.col, k)); }
    for (auto& b : beams) { std::vector<Pt> p; for (auto& q : b.pts) p.push_back(toScreen(q.x, q.y, z, sx, sy)); float al = b.life / b.max; GX.polyStroke(p.data(), (int)p.size(), false, 5 * z, colOf(0xa5f3fc, al)); GX.polyStroke(p.data(), (int)p.size(), false, 2 * z, colOf(0xffffff, al)); }
    for (auto& t : texts) { Pt c = toScreen(t.x, t.y, z, sx, sy); float k = t.life / t.max; Col cc = colOf(t.col, clampf(k * 1.6f, 0, 1)); GX.text(t.s, c.x, c.y, t.size * z * 1.3f, colOf(0x000000, cc.a / 255.f * 0.7f), 1); GX.text(t.s, c.x - 0.5f, c.y - 1, t.size * z * 1.3f, cc, 1); }
}

// ---- HUD and menus (drawn on the final framebuffer, crisp) ----
struct Rect { float x, y, w, h; }; static std::vector<Rect> menuRects, cardRects;
static bool inRect(const Rect& r, float x, float y) { return x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h; }
static void panel(float x, float y, float w, float h, Col edge, Col fill) {
    GX.mode(SDL_BLENDMODE_BLEND); GX.rect(x, y, w, h, fill); GX.mode(SDL_BLENDMODE_ADD);
    GX.line(x, y, x + w, y, 2, edge); GX.line(x, y + h, x + w, y + h, 2, edge); GX.line(x, y, x, y + h, 2, edge); GX.line(x + w, y, x + w, y + h, 2, edge);
}
static void drawHUD(float U) {
    float pad = 14 * U, W = (float)GX.W;
    GX.mode(SDL_BLENDMODE_BLEND); GX.rect(0, 0, W, 6 * U, colOf(0xffffff, 0.08f));
    GX.rect(0, 0, W * clampf(P.xp / P.xpNeed, 0, 1), 6 * U, colOf(0x8b5cf6)); GX.rect(0, 0, W * clampf(P.xp / P.xpNeed, 0, 1) * 0.5f, 6 * U, colOf(0x67e8f9, 0.6f));
    float hx = pad, hy = pad + 10 * U, hw = std::min(250 * U, W * 0.42f), hh = 15 * U, hr = clampf(P.hp / P.maxhp, 0, 1);
    GX.rect(hx - 2, hy - 2, hw + 4, hh + 4, colOf(0x000000, 0.55f));
    Col hc = hr > 0.55f ? colOf(0x4ade80) : hr > 0.3f ? colOf(0xfacc15) : colOf(0xfb7185); if (hr < 0.3f) hc.a = (uint8_t)(255 * (0.65f + 0.35f * sinf(G.t * 10)));
    GX.rect(hx, hy, hw * hr, hh, hc);
    GX.text(fmt("HP %d / %d", (int)ceilf(P.hp), (int)ceilf(P.maxhp)), hx + 6 * U, hy + 3.5f * U, 1.2f * U, colOf(0x0b0614));
    GX.text(fmt("LV %d", P.level), hx, hy + hh + 6 * U, 1.7f * U, colOf(0xc084fc));
    float sr = G.sudo / 100, sw = hw * 0.62f, sy = hy + hh + 30 * U;
    GX.rect(hx - 2, sy - 2, sw + 4, 9 * U + 4, colOf(0x000000, 0.55f)); Col sc = sr >= 1 ? colOf(0xf5d0fe, 0.7f + 0.3f * sinf(G.t * 12)) : colOf(0xa855f7); GX.rect(hx, sy, sw * sr, 9 * U, sc);
    GX.text(sr >= 1 ? "SUDO READY [E]" : "SUDO", hx + sw + 10 * U, sy + 1 * U, 1.3f * U, sr >= 1 ? colOf(0xf5d0fe) : colOf(0xa597c9));
    float dp = 1.f - clampf(P.dashCd / P.st.dashCd, 0, 1);
    GX.rect(hx - 2, sy + 16 * U - 2, sw + 4, 7 * U + 4, colOf(0x000000, 0.55f)); GX.rect(hx, sy + 16 * U, sw * dp, 7 * U, dp >= 1 ? colOf(0x67e8f9) : colOf(0x3b82a0));
    GX.text(dp >= 1 ? "DASH [SPACE]" : "DASH", hx + sw + 10 * U, sy + 16 * U, 1.3f * U, dp >= 1 ? colOf(0x67e8f9) : colOf(0xa597c9));
    GX.text(fmt("WAVE %d", G.wave), W / 2, pad, 3.f * U, colOf(0xffffff), 1); GX.text(fmtTime(G.time), W / 2, pad + 26 * U, 2.f * U, colOf(0xa597c9), 1);
    if (G.combo > 1) { GX.text(fmt("X%d COMBO", G.combo), W / 2, pad + 46 * U, 2.4f * U, colOf(0xffe14d), 1); GX.rect(W / 2 - 50 * U, pad + 68 * U, 100 * U * clampf(G.comboT / 2.6f, 0, 1), 3 * U, colOf(0xffe14d, 0.6f)); }
    GX.text(fmtNum((long)G.score), W - pad, pad, 3.f * U, colOf(0xffffff), 2); GX.text(fmt("%d KILLS", G.kills), W - pad, pad + 26 * U, 1.6f * U, colOf(0xa597c9), 2);
    if (boss && !boss->dead) {
        float bw = std::min(W * 0.62f, 620.f), bx = (W - bw) / 2, by = pad + 96 * U, rr = clampf(boss->hp / boss->maxhp, 0, 1);
        GX.text(BOSS_NAMES[boss->kind], W / 2, by - 18 * U, 2.f * U, colOf(boss->col), 1);
        GX.rect(bx - 2, by, bw + 4, 12 * U + 4, colOf(0x000000, 0.6f)); GX.rect(bx, by + 2, bw * rr, 12 * U, colOf(boss->col));
        GX.rect(bx + bw * 0.33f, by + 2, 2, 12 * U, colOf(0x000000, 0.6f)); GX.rect(bx + bw * 0.66f, by + 2, 2, 12 * U, colOf(0x000000, 0.6f));
        float z = viewZoom(), sx = (boss->x - camX) * z + W / 2, sy2 = (boss->y - camY) * z + GX.H / 2;
        if (sx < 0 || sx > W || sy2 < 0 || sy2 > GX.H) {
            float cx = clampf(sx, 30, W - 30), cy = clampf(sy2, 120, GX.H - 40), a = atan2f(sy2 - GX.H / 2.f, sx - W / 2.f), ca = cosf(a), sa = sinf(a);
            Pt t[3] = { { cx + ca * 14, cy + sa * 14 }, { cx - ca * 10 - sa * 10, cy - sa * 10 + ca * 10 }, { cx - ca * 10 + sa * 10, cy - sa * 10 - ca * 10 } };
            GX.polyFill(t, 3, colOf(boss->col, 0.6f + 0.3f * sinf(G.t * 8)));
        }
    }
    if (G.banner.on) {
        auto& b = G.banner; float k = b.t / b.dur, a = k < 0.12f ? k / 0.12f : k > 0.8f ? (1 - k) / 0.2f : 1.f, sc = 1 + (1 - clampf(k / 0.12f, 0, 1)) * 0.3f;
        GX.textGlow(b.text, W / 2, GX.H * 0.26f, 6.f * U * sc, colOf(b.col, a), 1);
        if (!b.sub.empty()) GX.text(b.sub, W / 2, GX.H * 0.26f + 58 * U, 2.f * U, colOf(0xe9d5ff, a), 1);
    }
}
static std::string onoff(bool b) { return b ? "ON" : "OFF"; }
struct MItem { std::string label; int id; };
enum { M_BOOT, M_RESUME, M_RESTART, M_BLOOM, M_SHAKE, M_NOTIFY, M_HOOKS, M_MUSIC, M_SFX, M_FULL, M_QUIT, M_MENU, M_HOST, M_JOIN, M_CONNECT, M_BACK, M_START, M_COPY, M_LEAVE, M_UPNP };
static std::vector<MItem> menuItems() {
    std::vector<MItem> v;
    if (G.state == ST_LOBBY) { if (mpRole == 1) return { { "START GAME", M_START }, { "COPY INVITE", M_COPY }, { "LEAVE", M_LEAVE } }; return { { "LEAVE", M_LEAVE } }; }
    if (G.state == ST_JOIN) return { { "CONNECT", M_CONNECT }, { "BACK", M_BACK } };
    if (G.state == ST_TITLE) v = { { "BOOT (SOLO)", M_BOOT }, { "HOST CO-OP", M_HOST }, { "JOIN CO-OP", M_JOIN } };
    else if (G.state == ST_PAUSE) { v.push_back({ "RESUME", M_RESUME }); if (!MP()) v.push_back({ "RESTART", M_RESTART }); }
    else if (G.state == ST_OVER) { if (mpRole == 2) return { { "LEAVE", M_MENU } }; return { { mpRole == 1 ? "REBOOT (SAME TEAM)" : "REBOOT", M_BOOT }, { "MENU", M_MENU } }; }
    v.push_back({ "BLOOM: " + onoff(CFG.bloom), M_BLOOM }); v.push_back({ "SCREEN SHAKE: " + onoff(CFG.shake), M_SHAKE });
    v.push_back({ "DESKTOP NOTIFY: " + onoff(CFG.notify), M_NOTIFY }); v.push_back({ "HOOKS: " + onoff(CFG.hooks), M_HOOKS });
    v.push_back({ "MUSIC: " + onoff(CFG.musOn), M_MUSIC }); v.push_back({ "SFX: " + onoff(CFG.sfxOn), M_SFX }); if (G.state == ST_TITLE) v.push_back({ "AUTO PORT-OPEN (UPNP): " + onoff(CFG.upnp), M_UPNP }); v.push_back({ "FULLSCREEN", M_FULL });
    if (G.state == ST_PAUSE) v.push_back({ MP() ? "LEAVE GAME" : "QUIT TO MENU", M_MENU }); else v.push_back({ "QUIT", M_QUIT });
    return v;
}
static void toggleFullscreen() {
    CFG.fullscreen = !CFG.fullscreen; SDL_SetWindowFullscreen(gWindow, CFG.fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0); saveSettings();
}
static void activate(int id) {
    sfx(S_UI);
    switch (id) {
        case M_BOOT: if (mpRole == 1) netHostStart(); else startGame(); break;
        case M_RESUME: setState(ST_PLAY); break; case M_RESTART: startGame(); break;
        case M_BLOOM: CFG.bloom = !CFG.bloom; break; case M_SHAKE: CFG.shake = !CFG.shake; break; case M_NOTIFY: CFG.notify = !CFG.notify; break; case M_HOOKS: CFG.hooks = !CFG.hooks; break;
        case M_MUSIC: CFG.musOn = !CFG.musOn; applyAudioSettings(); break; case M_SFX: CFG.sfxOn = !CFG.sfxOn; applyAudioSettings(); break;
        case M_FULL: toggleFullscreen(); break; case M_QUIT: quitRequested = true; break; case M_MENU: toMenu(); break;
        case M_UPNP: CFG.upnp = !CFG.upnp; break;
        case M_HOST: netStartHost(); break;
        case M_JOIN: M.notice.clear(); SDL_StartTextInput(); setState(ST_JOIN); break;
        case M_CONNECT: netStartJoin(); break;
        case M_BACK: SDL_StopTextInput(); setState(ST_TITLE); break;
        case M_START: netHostStart(); break;
        case M_COPY: SDL_SetClipboardText(netInvite().c_str()); M.notice = "INVITE COPIED TO CLIPBOARD"; break;
        case M_LEAVE: toMenu(); break;
    }
    saveSettings();
}
static void drawMenu(float U, float top) {
    auto items = menuItems(); menuRects.clear(); bool dense = items.size() > 8; float bw = 320 * U, bh = (dense ? 27 : 34) * U, gap = (dense ? 5 : 8) * U, x = (GX.W - bw) / 2, y = top;
    for (size_t i = 0; i < items.size(); i++) {
        Rect r = { x, y, bw, bh }; menuRects.push_back(r);
        bool hov = mouseSeen && inRect(r, mouseX, mouseY), sel = (int)i == menuSel; if (hov) menuSel = (int)i;
        bool primary = items[i].id == M_BOOT || items[i].id == M_RESUME;
        panel(r.x, r.y, r.w, r.h, colOf(sel || hov ? 0xc084fc : 0x7c3aed, sel || hov ? 1.f : 0.7f), colOf(sel || hov ? 0x3b1a75 : 0x160a30, 0.85f));
        GX.text(items[i].label, x + bw / 2, y + (bh - 14 * U * 1.1f) / 2, (primary ? 2.4f : dense ? 1.6f : 1.8f) * U, sel || hov ? WHITE : colOf(0xd8c8ff), 1);
        y += bh + gap;
    }
}
static Rect fieldRects[2], offerRects[3];
static std::vector<std::string> wrapStr(const std::string& s2, size_t w) { std::vector<std::string> v; for (size_t i = 0; i < s2.size(); i += w) v.push_back(s2.substr(i, w)); if (v.empty()) v.push_back(""); return v; }
static void drawLobby(float U) {
    float W = (float)GX.W, H = (float)GX.H; bool host = mpRole == 1; GX.overlayFull(colOf(0x07040f, 0.62f));
    GX.text(host ? "// CO-OP LOBBY - YOU ARE THE HOST" : "// CO-OP LOBBY", W / 2, H * 0.05f, 1.5f * U, colOf(0xa597c9), 1);
    GX.textGlow(host ? "INVITE FRIENDS" : "JOINING", W / 2, H * 0.05f + 22 * U, 4.6f * U, WHITE, 1);
    float y = H * 0.05f + 70 * U;
    if (host) {
        GX.text("SEND THIS ONE CODE - THEY PASTE IT UNDER JOIN CO-OP", W / 2, y, 1.3f * U, colOf(0xa597c9), 1); y += 22 * U;
        for (auto& ln : wrapStr(netInvite(), 40)) { GX.text(ln, W / 2, y, 1.6f * U, colOf(0xffe14d), 1); y += 19 * U; }
        y += 6 * U; bool pubFound = false;
        for (auto& r : gRoutes) { if (r.label.rfind("PUBLIC", 0) == 0) pubFound = true; GX.text(r.label + "  " + r.a.str(), W / 2, y, 1.2f * U, colOf(0x67e8f9), 1); y += 16 * U; }
        if (!pubFound) { bool stunBusy = M.host.stunPending(); GX.text(stunBusy ? "LOOKING UP YOUR PUBLIC IPV4 ADDRESS..." : "NO PUBLIC IPV4 FOUND - FRIENDS NEED IPV6, A VPN (TAILSCALE) OR THE SAME LAN", W / 2, y, 1.2f * U, colOf(stunBusy ? 0xa597c9 : 0xfb923c), 1); y += 16 * U; }
        GX.text("ONLY PEOPLE WITH THIS CODE CAN CONNECT. ALL TRAFFIC IS ENCRYPTED. TURN OFF ANY VPN THAT BLOCKS INCOMING.", W / 2, y, 1.05f * U, colOf(0x8bd8a0), 1); y += 22 * U;
    } else {
        bool fail = M.cli.st == net::Client::FAILED; std::string st = M.cli.st == net::Client::CONNECTING ? "CONNECTING..." : M.cli.st == net::Client::CONNECTED ? "CONNECTED - WAITING FOR THE HOST TO START" : "COULD NOT CONNECT";
        GX.text(st, W / 2, y, 2.2f * U, fail ? colOf(0xfb7185) : colOf(0xe9d5ff), 1); y += 32 * U;
        if (!M.notice.empty()) { GX.text(M.notice, W / 2, y, 1.4f * U, colOf(0xfb7185), 1); y += 26 * U; }
    }
    auto r = rosterNow();
    for (int i = 0; i < 4; i++) {
        bool have = i < (int)r.size(); panel(W / 2 - 170 * U, y, 340 * U, 26 * U, colOf(have ? PCOLS[i] : 0x3b2a6a, 0.8f), colOf(0x0a0518, 0.7f));
        GX.mode(SDL_BLENDMODE_ADD); GX.fillCircle(W / 2 - 152 * U, y + 13 * U, 6 * U, colOf(have ? PCOLS[i] : 0x3b2a6a), 12);
        GX.text(have ? r[i] : "WAITING...", W / 2 - 132 * U, y + 6 * U, 1.7f * U, have ? WHITE : colOf(0x6b5a9a)); if (have && i == 0 && host) GX.text("HOST", W / 2 + 160 * U, y + 8 * U, 1.3f * U, colOf(0xffe14d), 2);
        y += 31 * U;
    }
    if (host && !M.notice.empty()) GX.text(M.notice, W / 2, y + 2 * U, 1.4f * U, colOf(0x8bd8a0), 1);
    drawMenu(U, y + 14 * U);
}
static void drawJoin(float U) {
    float W = (float)GX.W, H = (float)GX.H; GX.overlayFull(colOf(0x07040f, 0.62f));
    GX.textGlow("JOIN CO-OP", W / 2, H * 0.09f, 6.f * U, WHITE, 1);
    float y = H * 0.09f + 76 * U, bw = std::min(600 * U, W - 40 * U);
    GX.text("PASTE THE INVITE YOUR FRIEND SENT YOU (CTRL+V)", W / 2 - bw / 2, y, 1.4f * U, colOf(0xa597c9)); y += 24 * U;
    std::string shown = M.joinAddr; if ((int)(G.t * 2) & 1) shown += "_"; auto lines = wrapStr(shown, 42); float bh = std::max(1, (int)lines.size()) * 19.f * U + 18 * U;
    fieldRects[0] = { W / 2 - bw / 2, y, bw, bh }; fieldRects[1] = { 0, 0, 0, 0 }; panel(fieldRects[0].x, y, bw, bh, colOf(0xc084fc), colOf(0x160a30, 0.9f));
    if (M.joinAddr.empty()) GX.text("KP-XXXXX-XXXXX-...", fieldRects[0].x + 12 * U, y + 9 * U, 1.6f * U, colOf(0x6b5a9a));
    else for (size_t i = 0; i < lines.size(); i++) GX.text(lines[i], fieldRects[0].x + 12 * U, y + 9 * U + i * 19 * U, 1.6f * U, WHITE);
    y += bh + 14 * U;
    if (!M.notice.empty()) { GX.text(M.notice, W / 2, y, 1.6f * U, colOf(0xfb7185), 1); y += 30 * U; }
    drawMenu(U, y + 8 * U);
}
static void drawTeam(float U) {
    if (players.size() < 2) return; float x = 14 * U, y = 14 * U + 96 * U;
    for (auto& pl : players) {
        if ((int)pl.idx == localIdx) continue; float hr = clampf(pl.hp / pl.maxhp, 0, 1);
        GX.mode(SDL_BLENDMODE_BLEND); GX.fillCircle(x + 5 * U, y + 6 * U, 5 * U, colOf(pl.col, pl.connected ? 1.f : 0.3f), 10); GX.text(pl.name, x + 16 * U, y, 1.5f * U, colOf(pl.col));
        GX.rect(x + 16 * U, y + 16 * U, 110 * U, 6 * U, colOf(0x000000, 0.55f)); GX.rect(x + 16 * U, y + 16 * U, 110 * U * hr, 6 * U, pl.dead ? colOf(0x555555) : hr > 0.4f ? colOf(0x4ade80) : colOf(0xfb7185));
        GX.text(!pl.connected ? "LEFT" : pl.dead ? fmt("DOWN %d", (int)ceilf(pl.respawnT)) : fmt("LV %d", pl.level), x + 134 * U, y + 12 * U, 1.2f * U, colOf(0xa597c9)); y += 32 * U;
    }
}
static void drawOffer(float U) {
    float W = (float)GX.W, H = (float)GX.H;
    if (P.dead && players.size() > 1 && G.state != ST_OVER) GX.text(fmt("YOU ARE DOWN - BACK IN %d", (int)ceilf(P.respawnT)), W / 2, H * 0.5f, 2.6f * U, colOf(0xfb7185, 0.8f + 0.2f * sinf(G.t * 6)), 1);
    if (!MP() || !P.offer) return;
    float cw = std::min(210 * U, (W - 40 * U) / 3), ch = 100 * U, gap = 10 * U, x0 = (W - (cw * 3 + gap * 2)) / 2, y = H - ch - 40 * U;
    GX.text(fmt("PATCH READY - PICK ONE (1/2/3 OR CLICK) - %d S", std::max(0, (int)ceilf(P.offerT))), W / 2, y - 24 * U, 1.5f * U, colOf(0xe9d5ff), 1);
    for (int k = 0; k < 3; k++) {
        int ui = P.choices[k]; offerRects[k] = { x0 + k * (cw + gap), y, cw, ch }; if (ui < 0 || ui >= NUPG) continue; const Upg& u = UPGS[ui]; Rect& r = offerRects[k];
        bool hov = mouseSeen && inRect(r, mouseX, mouseY); panel(r.x, r.y, r.w, r.h, colOf(hov ? 0x67e8f9 : 0x7c3aed), colOf(0x160a30, 0.94f));
        GX.text(u.tag, r.x + 10 * U, r.y + 8 * U, 1.1f * U, colOf(0x67e8f9)); GX.text(fmt("%d", k + 1), r.x + r.w - 16 * U, r.y + 8 * U, 1.5f * U, colOf(0xa597c9));
        GX.text(u.name, r.x + 10 * U, r.y + 26 * U, 1.4f * U, WHITE); GX.text(u.d1, r.x + 10 * U, r.y + 52 * U, 1.15f * U, colOf(0xa597c9)); GX.text(u.d2, r.x + 10 * U, r.y + 66 * U, 1.15f * U, colOf(0xa597c9));
    }
}
static void drawOverlays(float U) {
    float W = (float)GX.W, H = (float)GX.H;
    if (G.state == ST_JOIN) { drawJoin(U); return; }
    if (G.state == ST_LOBBY) { drawLobby(U); return; }
    if (G.state == ST_TITLE) {
        GX.overlayFull(colOf(0x07040f, 0.55f));
        GX.text("GENTOO // RING 0 // NATIVE BUILD", W / 2, H * 0.13f, 1.5f * U, colOf(0xa597c9), 1);
        float glitch = (fmodf(G.t, 4.2f) > 4.0f) ? rndr(-6, 6) : 0;
        GX.textGlow("KERNEL PANIC", W / 2 + glitch, H * 0.19f, std::min(8.f * U, W / 82.f), WHITE, 1);
        GX.text("MALWARE IS FLOODING /BOOT. YOU ARE THE LAST DAEMON STANDING.", W / 2, H * 0.19f + 90 * U, 1.6f * U, colOf(0xd8c8ff), 1);
        drawMenu(U, H * 0.19f + 130 * U);
        GX.text("WASD MOVE  MOUSE AIM+FIRE  SPACE DASH  E SUDO  P PAUSE  F11 FULLSCREEN  F12 SCREENSHOT", W / 2, H - 46 * U, 1.3f * U, colOf(0xa597c9), 1);
        if (!M.notice.empty()) GX.text(M.notice, W / 2, H - 70 * U, 1.6f * U, colOf(0xfb7185), 1);
        if (STATS.best > 0) GX.text(fmt("BEST %s  WAVE %d  %s  RUNS %d", fmtNum(STATS.best).c_str(), STATS.bestWave, fmtTime(STATS.bestTime).c_str(), STATS.runs), W / 2, H - 26 * U, 1.5f * U, colOf(0xc084fc), 1);
    } else if (G.state == ST_PAUSE) {
        GX.overlayFull(colOf(0x06030e, 0.72f)); GX.textGlow(MP() ? "MENU" : "PAUSED", W / 2, H * 0.16f, 6.f * U, WHITE, 1); if (MP()) GX.text("THE GAME KEEPS RUNNING", W / 2, H * 0.16f + 66 * U, 1.6f * U, colOf(0xfb7185), 1); drawMenu(U, H * 0.16f + 90 * U);
    } else if (G.state == ST_LEVELUP) {
        GX.overlayFull(colOf(0x06030e, 0.72f)); GX.text("// PATCH AVAILABLE", W / 2, H * 0.14f, 1.6f * U, colOf(0xa597c9), 1); GX.textGlow("CHOOSE AN UPGRADE", W / 2, H * 0.14f + 26 * U, 4.f * U, WHITE, 1);
        cardRects.clear(); float cw = std::min(230 * U, (W - 60 * U) / 3), ch = 230 * U, gap = 16 * U, x0 = (W - (cw * 3 + gap * 2)) / 2, y = H * 0.36f;
        for (int k = 0; k < 3; k++) {
            int ui = G.choices[k]; Rect r = { x0 + k * (cw + gap), y, cw, ch }; cardRects.push_back(r); if (ui < 0) continue;
            bool hov = mouseSeen && inRect(r, mouseX, mouseY); if (hov) cardSel = k; bool sel = cardSel == k; const Upg& u = UPGS[ui];
            float lift = sel ? -8 * U : 0;
            panel(r.x, r.y + lift, r.w, r.h, colOf(sel ? 0x67e8f9 : 0x7c3aed), colOf(0x160a30, 0.92f));
            GX.text(u.tag, r.x + 14 * U, r.y + lift + 14 * U, 1.3f * U, colOf(0x67e8f9)); GX.text(fmt("%d", k + 1), r.x + r.w - 20 * U, r.y + lift + 12 * U, 1.8f * U, colOf(0xa597c9));
            GX.text(u.name, r.x + 14 * U, r.y + lift + 44 * U, 1.7f * U, WHITE); GX.text(u.d1, r.x + 14 * U, r.y + lift + 96 * U, 1.4f * U, colOf(0xa597c9)); GX.text(u.d2, r.x + 14 * U, r.y + lift + 96 * U + 18 * U, 1.4f * U, colOf(0xa597c9));
            GX.text(u.heal ? "INSTANT" : fmt("LV %d > %d", lvOf(ui), lvOf(ui) + 1), r.x + 14 * U, r.y + lift + ch - 30 * U, 1.5f * U, colOf(0xc084fc));
        }
        GX.text("CLICK  OR  1 2 3  OR  ARROWS + ENTER", W / 2, y + ch + 30 * U, 1.4f * U, colOf(0xa597c9), 1);
    } else if (G.state == ST_OVER) {
        GX.overlayFull(colOf(0x3c061e, 0.55f)); GX.text("KERNEL PANIC - NOT SYNCING", W / 2, H * 0.12f, 1.6f * U, colOf(0xa597c9), 1); GX.textGlow("SYSTEM HALTED", W / 2, H * 0.12f + 26 * U, 6.f * U, WHITE, 1);
        GX.text(G.quote, W / 2, H * 0.12f + 92 * U, 1.6f * U, colOf(0xfb7185), 1);
        if (G.newBest) GX.text("NEW HIGH SCORE", W / 2, H * 0.12f + 120 * U, 2.4f * U, colOf(0xffe14d, 0.7f + 0.3f * sinf(G.t * 6)), 1);
        const char* lab[6] = { "SCORE", "WAVE", "TIME", "KILLS", "LEVEL", "BEST" }; std::string val[6] = { fmtNum((long)G.score), std::to_string(G.wave), fmtTime(G.time), std::to_string(G.kills), std::to_string(P.level), fmtNum(STATS.best) };
        float cw = 150 * U, chh = 62 * U, gx = 12 * U, x0 = (W - (cw * 3 + gx * 2)) / 2, y0 = H * 0.12f + 160 * U;
        for (int i = 0; i < 6; i++) { float x = x0 + (i % 3) * (cw + gx), y = y0 + (i / 3) * (chh + gx); panel(x, y, cw, chh, colOf(0x7c3aed, 0.6f), colOf(0x0a0518, 0.7f)); GX.text(val[i], x + cw / 2, y + 10 * U, 2.6f * U, WHITE, 1); GX.text(lab[i], x + cw / 2, y + 42 * U, 1.2f * U, colOf(0xa597c9), 1); }
        drawMenu(U, y0 + 2 * (chh + gx) + 14 * U);
    }
}
static void renderFrame(float dt) {
    float U = clampf(GX.H / 720.f, 0.8f, 2.2f); baseZoom = clampf(sqrtf((float)(GX.W * GX.H)) / 1000.f, 0.62f, 1.25f) * (GX.H > 1400 ? 1.3f : 1.f);
    G.shake *= powf(0.0008f, dt); if (G.shake < 0.05f) G.shake = 0; camPunch *= powf(0.02f, dt);
    float sx = rndr(-1, 1) * G.shake, sy = rndr(-1, 1) * G.shake, z = viewZoom();
    GX.beginScene(); drawBackground(z, sx, sy); drawWorld(z, sx, sy); GX.flush();
    GX.compose(CFG.bloom, G.hurt > 0.3f ? G.hurt * 5.f * GX.winScale : 0.f);
    GX.mode(SDL_BLENDMODE_BLEND); GX.vignette(colOf(0x04020a, 1)); if (G.hurt > 0) GX.vignette(colOf(0xff2850, G.hurt * 0.75f));
    if (G.flash > 0) { GX.mode(SDL_BLENDMODE_ADD); GX.rect(0, 0, (float)GX.W, (float)GX.H, colOf(0xf5e8ff, clampf(G.flash, 0, 0.8f))); }
    if (!G.demo && (G.state == ST_PLAY || G.state == ST_DYING || G.state == ST_PAUSE || G.state == ST_LEVELUP)) { drawHUD(U); drawTeam(U); drawOffer(U); }
    drawOverlays(U); GX.flush();
}

// ============================================================================
//  main
// ============================================================================
static void openPad() { if (pad) return; for (int i = 0; i < SDL_NumJoysticks(); i++) if (SDL_IsGameController(i)) { pad = SDL_GameControllerOpen(i); if (pad) break; } }
static void menuNav(int dir) { int n = (int)menuItems().size(); if (n) menuSel = (menuSel + dir + n) % n; sfx(S_UI); }
static void handleKey(SDL_Scancode sc) {
    if (sc == SDL_SCANCODE_F11) { toggleFullscreen(); return; }
    if (sc == SDL_SCANCODE_F12) { std::string dir = homeDir() + "/Pictures"; mkdirs(dir); GX.screenshot(dir + fmt("/kernel-panic-%u.bmp", SDL_GetTicks())); return; }
    if (G.state == ST_JOIN) {
        std::string& f = M.joinAddr;
        if (sc == SDL_SCANCODE_ESCAPE) { activate(M_BACK); return; }
        if (sc == SDL_SCANCODE_BACKSPACE) { if (!f.empty()) f.pop_back(); return; }
        if (sc == SDL_SCANCODE_RETURN || sc == SDL_SCANCODE_KP_ENTER) { netStartJoin(); return; }
        if (sc == SDL_SCANCODE_V && (SDL_GetModState() & KMOD_CTRL)) {
            char* t = SDL_GetClipboardText(); std::string p = t ? t : ""; if (t) SDL_free(t);
            std::string clean; for (char c : p) if ((unsigned char)c > 32 && (unsigned char)c < 127) clean += c; f = clean.substr(0, 300);
        }
        return;
    }
    if (G.state == ST_LOBBY && sc == SDL_SCANCODE_ESCAPE) { toMenu(); return; }
    if (MP() && G.state == ST_PLAY && P.offer) { int k = sc == SDL_SCANCODE_1 ? 0 : sc == SDL_SCANCODE_2 ? 1 : sc == SDL_SCANCODE_3 ? 2 : -1; if (k >= 0) { if (mpRole == 1) answerOffer(P, k); else clientChoose(k); return; } }
    if (G.state == ST_LEVELUP) {
        if (sc == SDL_SCANCODE_1) chooseUpgrade(0); else if (sc == SDL_SCANCODE_2) chooseUpgrade(1); else if (sc == SDL_SCANCODE_3) chooseUpgrade(2);
        else if (sc == SDL_SCANCODE_LEFT || sc == SDL_SCANCODE_A) cardSel = (cardSel + 2) % 3; else if (sc == SDL_SCANCODE_RIGHT || sc == SDL_SCANCODE_D) cardSel = (cardSel + 1) % 3;
        else if (sc == SDL_SCANCODE_RETURN || sc == SDL_SCANCODE_SPACE) chooseUpgrade(cardSel);
        return;
    }
    if (G.state == ST_PLAY) { if (sc == SDL_SCANCODE_P || sc == SDL_SCANCODE_ESCAPE) setState(ST_PAUSE); return; }
    if (G.state == ST_PAUSE && (sc == SDL_SCANCODE_P || sc == SDL_SCANCODE_ESCAPE)) { setState(ST_PLAY); return; }
    if (G.state == ST_TITLE || G.state == ST_PAUSE || G.state == ST_OVER || G.state == ST_LOBBY) {
        if (sc == SDL_SCANCODE_UP || sc == SDL_SCANCODE_W) menuNav(-1); else if (sc == SDL_SCANCODE_DOWN || sc == SDL_SCANCODE_S) menuNav(1);
        else if (sc == SDL_SCANCODE_RETURN || sc == SDL_SCANCODE_SPACE) { auto it = menuItems(); if (menuSel < (int)it.size()) activate(it[menuSel].id); }
        else if (sc == SDL_SCANCODE_ESCAPE && G.state == ST_TITLE) quitRequested = true;
    }
}

static SDL_Surface* makeIcon(int S) {
    SDL_Surface* s = SDL_CreateRGBSurfaceWithFormat(0, S, S, 32, SDL_PIXELFORMAT_RGBA32); if (!s) return nullptr; Uint32* px = (Uint32*)s->pixels;
    static const float hull[6][2] = { { 0, -0.68f }, { 0.13f, -0.22f }, { 0.2f, 0.36f }, { 0, 0.22f }, { -0.2f, 0.36f }, { -0.13f, -0.22f } };
    static const float wr[4][2] = { { 0.1f, -0.06f }, { 0.64f, 0.44f }, { 0.5f, 0.52f }, { 0.12f, 0.26f } }, wl[4][2] = { { -0.1f, -0.06f }, { -0.12f, 0.26f }, { -0.5f, 0.52f }, { -0.64f, 0.44f } };
    auto inside = [](const float (*p)[2], int n, float x, float y) { bool in = false; for (int i = 0, j = n - 1; i < n; j = i++) if (((p[i][1] > y) != (p[j][1] > y)) && (x < (p[j][0] - p[i][0]) * (y - p[i][1]) / (p[j][1] - p[i][1]) + p[i][0])) in = !in; return in; };
    auto edge = [](const float (*p)[2], int n, float x, float y) { float best = 9; for (int i = 0, j = n - 1; i < n; j = i++) { float ax = p[j][0], ay = p[j][1], bx = p[i][0], by = p[i][1], dx = bx - ax, dy = by - ay, t = clampf(((x - ax) * dx + (y - ay) * dy) / (dx * dx + dy * dy), 0, 1), ex = ax + dx * t - x, ey = ay + dy * t - y; best = std::min(best, sqrtf(ex * ex + ey * ey)); } return best; };
    for (int yy = 0; yy < S; yy++) for (int xx = 0; xx < S; xx++) {
        float u = (xx + 0.5f) / S * 2 - 1, v = (yy + 0.5f) / S * 2 - 1, qx = fabsf(u) - 0.8f, qy = fabsf(v) - 0.8f;
        float d = sqrtf(std::max(qx, 0.f) * std::max(qx, 0.f) + std::max(qy, 0.f) * std::max(qy, 0.f)) + std::min(std::max(qx, qy), 0.f) - 0.18f, alpha = clampf(0.5f - d * S * 0.5f, 0, 1);
        float r2 = u * u + (v - 0.1f) * (v - 0.1f); float R = 22 + 60 * expf(-r2 * 2.2f), G2 = 8 + 26 * expf(-r2 * 2.2f), B = 50 + 110 * expf(-r2 * 2.0f);
        float glowD = std::min(edge(hull, 6, u, v), std::min(edge(wr, 4, u, v), edge(wl, 4, u, v))); float glow = expf(-glowD * 9.f) * 0.55f;
        R += 60 * glow; G2 += 220 * glow; B += 240 * glow;
        bool in = inside(hull, 6, u, v) || inside(wr, 4, u, v) || inside(wl, 4, u, v);
        if (in) { R = 14; G2 = 30; B = 58; }
        if (glowD < 0.028f) { R = 150; G2 = 245; B = 255; }
        float cx = u, cy = v + 0.02f; float ck = expf(-(cx * cx + cy * cy) * 900.f); R += 230 * ck; G2 += 240 * ck; B += 255 * ck;
        px[yy * S + xx] = SDL_MapRGBA(s->format, (Uint8)clampf(R, 0, 255), (Uint8)clampf(G2, 0, 255), (Uint8)clampf(B, 0, 255), (Uint8)(alpha * 255));
    }
    return s;
}
static void usage() {
    printf("KERNEL PANIC - native SDL2 build\n  --windowed / --fullscreen   --no-bloom   --no-notify   --no-hooks   --no-vsync   --help\n  --host [--port N]                 host a co-op game (prints the invite in the lobby)\n  --join KP-INVITE                  join a co-op game with a pasted invite\n"
           "Config: %s/config.ini   Hooks: %s/on_<event>   Stats: %s/stats.txt\nEvents: start wave boss bossdead sudo levelup gameover highscore\n",
           cfgDir.c_str(), hooksDir.c_str(), dataDir.c_str());
}

int main(int argc, char** argv) {
    signal(SIGCHLD, SIG_IGN); signal(SIGPIPE, SIG_IGN);
    cfgDir = xdgDir("XDG_CONFIG_HOME", "/.config") + "/kernel-panic"; dataDir = xdgDir("XDG_DATA_HOME", "/.local/share") + "/kernel-panic"; cacheDir = xdgDir("XDG_CACHE_HOME", "/.cache") + "/kernel-panic"; hooksDir = cfgDir + "/hooks";
    mkdirs(cfgDir); mkdirs(hooksDir); mkdirs(dataDir); mkdirs(cacheDir);
    loadSettings(); loadStats();
    bool headless = getenv("KP_HEADLESS") != nullptr; int frames = getenv("KP_FRAMES") ? atoi(getenv("KP_FRAMES")) : 0; bool wantHost = false, wantJoin = false;
    if (argc >= 4 && std::string(argv[1]) == "--dump-icon") { SDL_Surface* ic = makeIcon(atoi(argv[3])); if (!ic) return 1; SDL_SaveBMP(ic, argv[2]); SDL_FreeSurface(ic); return 0; }
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        if (a == "--help" || a == "-h") { usage(); return 0; } else if (a == "--fullscreen") CFG.fullscreen = true; else if (a == "--windowed") CFG.fullscreen = false;
        else if (a == "--no-bloom") CFG.bloom = false; else if (a == "--no-notify") CFG.notify = false; else if (a == "--no-hooks") CFG.hooks = false; else if (a == "--no-vsync") CFG.vsync = false;
        else if (a == "--host") wantHost = true; else if (a == "--join" && i + 1 < argc) { M.joinAddr = argv[++i]; wantJoin = true; } else if (a == "--code" && i + 1 < argc) M.joinCode = argv[++i]; else if (a == "--port" && i + 1 < argc) setenv("KP_PORT", argv[++i], 1);
    }
    setenv("SDL_VIDEO_X11_WMCLASS", "kernel-panic", 0); setenv("SDL_VIDEO_WAYLAND_WMCLASS", "kernel-panic", 0); SDL_SetHint(SDL_HINT_APP_NAME, "Kernel Panic");
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMECONTROLLER | SDL_INIT_HAPTIC | SDL_INIT_TIMER | SDL_INIT_EVENTS) != 0) { fprintf(stderr, "SDL_Init: %s\n", SDL_GetError()); return 1; }
    SDL_SetHint(SDL_HINT_VIDEO_ALLOW_SCREENSAVER, "0");
    if (!GX.init(headless, CFG.fullscreen)) return 1;
    gWindow = GX.win; if (SDL_Surface* ic = makeIcon(128)) { SDL_SetWindowIcon(GX.win, ic); SDL_FreeSurface(ic); }
    if (!AU.init()) fprintf(stderr, "audio unavailable: %s\n", SDL_GetError());
    applyAudioSettings(); openPad();
    resetWorld(true); setState(ST_TITLE);
    if (getenv("KP_SHOW_JOIN")) { M.joinAddr = getenv("KP_SHOW_JOIN"); if (M.joinAddr == "-") M.joinAddr.clear(); setState(ST_JOIN); }   // dev aid for screenshots
    int autoHostN = 0; if (getenv("KP_NET_LOSS")) net::g_lossPct = atoi(getenv("KP_NET_LOSS"));
    if (getenv("KP_HOST_AUTO")) { autoHostN = atoi(getenv("KP_HOST_AUTO")); netStartHost(); }
    else if (wantHost) netStartHost();
    if (getenv("KP_JOIN")) { M.joinAddr = getenv("KP_JOIN"); if (getenv("KP_CODE")) M.joinCode = getenv("KP_CODE"); M.botClient = getenv("KP_BOT") != nullptr; netStartJoin(); }
    else if (wantJoin) netStartJoin();
    if (getenv("KP_PLAYERS")) { int n = std::max(1, std::min(4, atoi(getenv("KP_PLAYERS")))); mpRole = n > 1 ? 1 : 0; BOTS = true; startGame(n); AUTOPLAY = true; }
    else if (getenv("KP_AUTOSTART")) { startGame(); AUTOPLAY = true; if (getenv("KP_START_TIME")) G.time = (float)atof(getenv("KP_START_TIME")); }
    if (getenv("KP_SHOWCASE")) {   // dev aid: freeze one of every enemy in a row for screenshots
        startGame(); AUTOPLAY = false; enemies.clear(); G.spawnT = 1e9f; G.banner.on = false; int bk = atoi(getenv("KP_SHOWCASE"));
        int types[6] = { T_WORM, T_TROJAN, T_SPY, T_RANSOM, T_CHARGER, T_BOMB };
        for (int i = 0; i < 6; i++) { Enemy& e = makeEnemy(types[i], -520 + i * 208.f, -250, false); e.spd = 0; e.fireT = 1e9f; e.st = 1e9f; }
        for (int i = 0; i < 6; i++) { Enemy& e = makeEnemy(types[i], -520 + i * 208.f, -110, i % 2 == 1); e.spd = 0; e.fireT = 1e9f; e.st = 1e9f; if (i == 4) e.state = 1, e.st = 1e9f; if (i == 5) e.fuse = 0.6f; }
        G.bossCount = bk; spawnBoss(); Enemy* b = boss; if (b) { b->x = 0; b->y = 200; b->intro = 0; b->atk = b->sumT = b->fuse = 1e9f; b->spd = 0; b->hp = b->maxhp * (bk == 2 ? 0.2f : bk == 1 ? 0.5f : 0.9f); }
    }

    if (getenv("KP_FUZZ")) {   // dev/test hook: fuzz the message handlers
        long iters = atol(getenv("KP_FUZZ")); mpRole = 1; startGame(2); mpRole = 1; players[1].remote = true; players[1].sid = 77; players[1].offer = true; players[1].choices[0] = 1; long parsedSnaps = 0;
        for (long i = 0; i < iters; i++) {
            uint8_t b[1200]; size_t n = randombytes_uniform(400); randombytes_buf(b, n); std::vector<uint8_t> v(b, b + n);
            switch (i % 6) {
                case 0: if (n) v[0] = 1 + randombytes_uniform(4); hostRel(77, v); break;
                case 1: if (n) v[0] = U_INPUT; hostInput(77, v); break;
                case 2: { if (n) v[0] = 10 + randombytes_uniform(8); if (n && v[0] == R_START && (i & 1)) v[0] = R_LOBBY; clientRel(v); if (G.state != ST_PLAY) { players.assign(2, Player()); players[0].idx = 0; players[1].idx = 1; localIdx = 0; curP = &players[0]; setState(ST_PLAY); } break; }
                case 3: { net::Writer w(b, sizeof b); w.u8(U_SNAP); w.u32((uint32_t)(i + 10)); for (int k = 0; k < 14; k++) w.u8((uint8_t)randombytes_uniform(256)); w.u8((uint8_t)players.size());
                    for (size_t p = 0; p < players.size() * 23; p++) w.u8((uint8_t)randombytes_uniform(256));
                    int nl = randombytes_uniform(8); w.u8((uint8_t)nl); for (int k = 0; k < nl * 8; k++) w.u8((uint8_t)randombytes_uniform(256));
                    int ne = randombytes_uniform(43); w.u8((uint8_t)ne); for (int k = 0; k < ne; k++) { w.u8((uint8_t)(randombytes_uniform(4) ? 1 + randombytes_uniform(7) : randombytes_uniform(256))); for (int q = 0; q < 6; q++) w.u8((uint8_t)randombytes_uniform(256)); }
                    int nb = randombytes_uniform(5); w.u8((uint8_t)nb); for (int k = 0; k < nb; k++) { int np2 = randombytes_uniform(10); w.u8((uint8_t)np2); for (int q = 0; q < np2 * 4; q++) w.u8((uint8_t)randombytes_uniform(256)); }
                    if (w.ok) { long before = M.snapsRx; clientSnap(b, w.n); parsedSnaps += M.snapsRx - before; } break; }
                case 4: { net::Writer w(b, sizeof b); uint8_t kind = U_ENEMIES + randombytes_uniform(4); size_t rec = kind == U_ENEMIES ? 11 : kind == U_BULLETS ? 6 : kind == U_EBUL ? 8 : 5; int cnt = randombytes_uniform(60);
                    w.u8(kind); w.u32((uint32_t)(i / 6)); uint8_t total = 1 + randombytes_uniform(4); w.u8(randombytes_uniform(5)); w.u8(total); w.u8((uint8_t)cnt); for (size_t k = 0; k < cnt * rec; k++) w.u8((uint8_t)randombytes_uniform(256)); if (randombytes_uniform(4) == 0 && w.n > 3) w.n -= 2; clientList(b, w.n); break; }
                case 5: { clientBuildLists(net::nowSec()); refreshBoss(); for (auto& e : enemies) if (e.type > 6) abort(); updateFx(0.016f); break; }
            }
            if (i % 5000 == 0) { players[0].dead = false; }
            if (i % 97 == 0) { players[1].offer = true; players[1].choices[0] = players[1].choices[1] = players[1].choices[2] = -1; std::vector<uint8_t> ch = { R_CHOOSE, (uint8_t)(3 + randombytes_uniform(253)) }; hostRel(77, ch); }   // regression: out-of-range choice while no option is valid
        }
        printf("fuzz done: %ld iterations, %ld snapshots fully parsed, state=%d players=%zu\n", iters, parsedSnaps, (int)G.state, players.size()); if (AU.dev) SDL_CloseAudioDevice(AU.dev); return 0;
    }
    const char* shotDir = getenv("KP_SHOT_DIR"); int shotEvery = getenv("KP_SHOT_EVERY") ? atoi(getenv("KP_SHOT_EVERY")) : 0;

    uint64_t prev = SDL_GetPerformanceCounter(); const double freq = (double)SDL_GetPerformanceFrequency(); int frameNo = 0; int lastBeat = 0;
    while (!quitRequested) {
        SDL_Event ev;
        while (SDL_PollEvent(&ev)) {
            switch (ev.type) {
                case SDL_QUIT: quitRequested = true; break;
                case SDL_WINDOWEVENT:
                    if (ev.window.event == SDL_WINDOWEVENT_SIZE_CHANGED || ev.window.event == SDL_WINDOWEVENT_RESIZED) GX.buildTargets();
                    if (ev.window.event == SDL_WINDOWEVENT_FOCUS_LOST && CFG.autopause && G.state == ST_PLAY && !MP()) setState(ST_PAUSE);
                    break;
                case SDL_KEYDOWN: if (!ev.key.repeat || (G.state == ST_JOIN && ev.key.keysym.scancode == SDL_SCANCODE_BACKSPACE)) handleKey(ev.key.keysym.scancode); break;
                case SDL_TEXTINPUT: if (G.state == ST_JOIN) { std::string& f = M.joinAddr; for (const char* c = ev.text.text; *c; c++) if ((unsigned char)*c > 32 && (unsigned char)*c < 127 && f.size() < 300u) f += *c; } break;
                case SDL_MOUSEMOTION: mouseSeen = true; mouseX = ev.motion.x * GX.winScale; mouseY = ev.motion.y * GX.winScale; break;
                case SDL_MOUSEBUTTONDOWN:
                    mouseSeen = true; mouseX = ev.button.x * GX.winScale; mouseY = ev.button.y * GX.winScale;
                    if (ev.button.button == SDL_BUTTON_LEFT) {
                        mouseDown = true;
                        if (MP() && G.state == ST_PLAY && P.offer) for (int k = 0; k < 3; k++) if (inRect(offerRects[k], mouseX, mouseY)) { if (mpRole == 1) answerOffer(P, k); else clientChoose(k); }
                        if (G.state == ST_JOIN) for (int f = 0; f < 2; f++) if (inRect(fieldRects[f], mouseX, mouseY)) M.field = f;
                        if (G.state == ST_LEVELUP) { for (size_t k = 0; k < cardRects.size(); k++) if (inRect(cardRects[k], mouseX, mouseY)) chooseUpgrade((int)k); }
                        else if (G.state == ST_TITLE || G.state == ST_PAUSE || G.state == ST_OVER || G.state == ST_LOBBY || G.state == ST_JOIN) { auto it = menuItems(); for (size_t k = 0; k < menuRects.size() && k < it.size(); k++) if (inRect(menuRects[k], mouseX, mouseY)) { activate(it[k].id); break; } }
                    }
                    break;
                case SDL_MOUSEBUTTONUP: if (ev.button.button == SDL_BUTTON_LEFT) mouseDown = false; break;
                case SDL_CONTROLLERDEVICEADDED: openPad(); break;
                case SDL_CONTROLLERDEVICEREMOVED: if (pad) { SDL_GameControllerClose(pad); pad = nullptr; } break;
                case SDL_CONTROLLERBUTTONDOWN: {
                    int b = ev.cbutton.button;
                    if (b == SDL_CONTROLLER_BUTTON_START) { if (G.state == ST_PLAY) setState(ST_PAUSE); else if (G.state == ST_PAUSE) setState(ST_PLAY); }
                    else if (G.state == ST_LEVELUP) { if (b == SDL_CONTROLLER_BUTTON_DPAD_LEFT) cardSel = (cardSel + 2) % 3; else if (b == SDL_CONTROLLER_BUTTON_DPAD_RIGHT) cardSel = (cardSel + 1) % 3; else if (b == SDL_CONTROLLER_BUTTON_A) chooseUpgrade(cardSel); }
                    else if (G.state == ST_TITLE || G.state == ST_PAUSE || G.state == ST_OVER) { if (b == SDL_CONTROLLER_BUTTON_DPAD_UP) menuNav(-1); else if (b == SDL_CONTROLLER_BUTTON_DPAD_DOWN) menuNav(1); else if (b == SDL_CONTROLLER_BUTTON_A) { auto it = menuItems(); if (menuSel < (int)it.size()) activate(it[menuSel].id); } }
                    break; }
                default: break;
            }
        }
        uint64_t now = SDL_GetPerformanceCounter(); float dt = (float)((now - prev) / freq); prev = now;
        if (headless) dt = 1.f / 60.f;
        dt = clampf(dt, 0.0005f, 0.05f);
        float sim = dt * G.timeScale; if (G.hitstop > 0) { G.hitstop -= dt; sim = 0; }
        AU.intensity.store(G.intensity); int bc = AU.beat.load(); if (bc != lastBeat) { lastBeat = bc; G.beat = 1; }
        netPump(dt);
        if (headless && autoHostN > 0 && frameNo == 100) { printf("INVITE %s\n", netInvite().c_str()); fflush(stdout); }
        bool simState = G.state == ST_PLAY || G.state == ST_TITLE || G.state == ST_DYING || ((G.state == ST_JOIN || G.state == ST_LOBBY) && G.demo) || (mpRole == 1 && G.state == ST_PAUSE);
        if (mpRole == 2 && !G.demo && (G.state == ST_PLAY || G.state == ST_PAUSE)) clientUpdate(dt);
        else if (simState) { if (sim > 0) updateWorld(sim); }
        if (autoHostN > 0 && G.state == ST_LOBBY && (int)rosterNow().size() >= autoHostN + 1) { netHostStart(); AUTOPLAY = true; BOTS = false; }
        if (G.state == ST_DYING) { G.deathT -= dt; if (G.deathT <= 0) { G.timeScale = 1; gameOverNow(); } }
        renderFrame(dt);
        frameNo++;
        if (shotDir && shotEvery > 0 && frameNo % shotEvery == 0) GX.screenshot(fmt("%s/frame_%05d.bmp", shotDir, frameNo));
        SDL_RenderPresent(GX.rd);
        if (frames > 0 && frameNo >= frames) break;
        if (headless) SDL_Delay(0);
    }
    if (headless) printf("frames=%d state=%d wave=%d score=%ld kills=%d hp=%.0f enemies=%zu audioCb=%ld nan=%ld peak=%.3f\n", frameNo, (int)G.state, G.wave, (long)G.score, G.kills, P.hp, enemies.size(), AU.cbCount.load(), AU.nanCount.load(), AU.peak.load());
    if (headless && mpRole) printf("mp: role=%d players=%zu snaps=%ld lists=%ld events=%ld bad=%ld clientEnemies=%zu bullets=%zu hostEnemies=%zu wave=%d score=%ld\n", mpRole, players.size(), M.snapsRx, M.listsRx, M.evRx, M.badRx, M.cEn.size(), M.cBu.size(), enemies.size(), G.wave, (long)G.score);
    netShutdown(); saveSettings();
    if (AU.dev) SDL_CloseAudioDevice(AU.dev);
    SDL_Quit();
    return 0;
}
