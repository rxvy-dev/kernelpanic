# KERNEL PANIC (native)

Neon twin-stick roguelite for Linux with **peer-to-peer co-op (up to 4 players)**. C++17 + SDL2 + libsodium. No assets: graphics are vector-drawn, audio is synthesized live.

## Build
Needs a C++17 compiler, SDL2, and libsodium; `libnotify` and `miniupnpc` are optional (desktop notifications and automatic router port-opening — the game runs fine without either).

    # Gentoo
    sudo emerge --ask media-libs/libsdl2 dev-libs/libsodium x11-libs/libnotify net-libs/miniupnpc
    # Arch / Manjaro
    sudo pacman -S --needed sdl2 libsodium libnotify miniupnpc base-devel
    # Debian / Ubuntu / Mint / Pop!_OS
    sudo apt install build-essential libsdl2-dev libsodium-dev libnotify-bin libminiupnpc-dev
    # Fedora / Nobara
    sudo dnf install gcc-c++ SDL2-devel libsodium-devel libnotify miniupnpc-devel
    # openSUSE
    sudo zypper install gcc-c++ libSDL2-devel libsodium-devel libnotify-tools miniupnpc-devel

    make            # builds ./kernel-panic
    make test       # runs the network/security test suite under AddressSanitizer + UBSan
    make install    # to ~/.local: binary, app-menu entry with icon, default hooks
Needs a desktop session (X11 or Wayland). Start "Kernel Panic" from your app menu (right-click it for "Host a co-op game").
If `kernel-panic` is not found in a terminal, add `~/.local/bin` to your PATH.

## Co-op: host and join with one code (no server)
1. Host: **HOST CO-OP**. The lobby shows one long invite starting with `KP-`. Press **COPY INVITE** and send it to your friends.
2. Friends: **JOIN CO-OP**, paste (Ctrl+V), press Enter. When everyone is in, the host presses **START GAME**.
Command line: `kernel-panic --host` / `kernel-panic --join KP-XXXXX-...`

The invite contains a fresh random room secret plus the host's reachable addresses (up to 4), so nothing has to be looked up on a server.
The game finds those addresses by itself:
* **IPv6** (direct, no router setup - works if both sides have IPv6),
* **Public IPv4** through **UPnP** (asks your router to forward the port; opt-in toggle on the title screen; removed when you leave) or **STUN** (learns your public address from a free public STUN server; only your IP is visible to it),
* **VPN/Tailscale** and **LAN** addresses.
Friends' game tries all of them at once and uses the first that answers.
If it says "no public IPv4 found": use IPv6, Tailscale/ZeroTier, the same LAN, or forward UDP port 47474 (or the port shown) on your router by hand. A VPN such as Mullvad blocks incoming connections (Mullvad has no port forwarding): turn it off while hosting, or use Tailscale.

## Security model
* Every session has a new 128-bit secret. Connecting needs it: without it, packets fail a MAC check and the host creates no state and does not reply.
* Handshake: ephemeral X25519 key exchange (forward secrecy) bound to the secret with keyed BLAKE2b. Data: XChaCha20-Poly1305 per direction, authenticated headers, replay window.
* Handshake replies are exactly as large as requests (cannot be used for traffic amplification). Peers, pending handshakes, message queues and datagram sizes are all bounded. Every network message goes through a bounds-checked reader.
* The **invite is like a password plus your address**: anyone who has it can join while the lobby is open, and it reveals your IP to whoever receives it. It changes every time you host. Anyone you play with also learns your IP (unavoidable in peer-to-peer).
* The host is trusted by its clients (it runs the game). Clients cannot cheat state: the host only accepts their input.
* No software can be promised bug-free. `make test` runs the transport tests (tampering, replay, 60k garbage packets, typo detection, loss) under sanitizers, and the game's message handlers were fuzzed for 400k+ iterations (which found and fixed two out-of-bounds bugs). Real-world networks, UPnP routers and STUN servers could not be tested in development.

## Controls
WASD move | mouse aim + hold to fire | Space dash | Q firewall (shield) | E sudo | R turbo | P/Esc menu (in co-op the game keeps running) | F11 fullscreen | F12 screenshot
Gamepad: left stick move, right stick aim+fire, A dash, B/X sudo, Y firewall, D-pad up turbo, Start menu. Level-up: click, 1/2/3, or arrows + Enter (co-op: pick within 14 s, the game keeps running).

## Powers, upgrades, ships and coins
Two active powers charge independently of your usual upgrades:
* **Firewall (Q)** — a personal shield on its own cooldown. Grants brief invulnerability and bursts nearby enemies when you trigger it.
* **Turbo (R)** — a team-wide meter, charged by kills like sudo but separately. When full, boosts everyone's fire rate, speed and damage for 6 seconds.

The level-up pool has 20 passive upgrades across CPU/WEAPON/SYSTEM/MOBILITY, including lifesteal, dodge chance, bonus XP, splash-damage bullets, and heal-on-level-up.

Every run earns **coins** (score/40 + kills/4), kept even after you die, shown on the game-over screen. Spend them in the **Shop** (from the title screen) on 5 ships — Interceptor (free/default), Vanguard, Wraith, Juggernaut, Phantom — each with a different hp/speed/damage/dash profile, color and size. Your equipped ship is sent to the host when you join a co-op game, so everyone sees everyone else's real ship, color and stats.

## Outside the game
On events (start, wave, boss, bossdead, sudo, levelup, gameover, highscore) the game sends a desktop notification, flashes the taskbar if unfocused, writes `~/.cache/kernel-panic/live.json`, and runs `~/.config/kernel-panic/hooks/on_<event>` / `on_any` with `KP_*` variables. The default `on_any` recolors kitty (see `hooks/on_any`). fastfetch line:

    { "type": "command", "key": "| Kernel Panic", "text": "cat ~/.local/share/kernel-panic/best.txt" }

## Options
`--windowed --fullscreen --no-bloom --no-notify --no-hooks --no-vsync --host [--port N] --join INVITE`. Settings persist in `~/.config/kernel-panic/config.ini`.
Dev/test variables (KP_HEADLESS, KP_HOST_AUTO, KP_JOIN, KP_FUZZ, KP_NET_LOSS, ...) are for automated testing only.

## Troubleshooting
* **Icon in the app menu doesn't launch anything, or nothing happens on click:** `make install` writes an absolute path into the launcher, so this shouldn't happen after a fresh install — run `make install` again. Some menus (especially GNOME) cache entries and need a log out/in to notice a new one. As a fallback, `~/.local/bin/kernel-panic` always works from a terminal.
* **Crashes immediately on launch:** run it from a terminal to see the error (`~/.local/bin/kernel-panic`). If you see `SDL_CreateWindow`/`SDL_CreateRenderer` failures, your graphics driver or Wayland/X11 setup may be missing something SDL2 needs — try `SDL_VIDEODRIVER=x11 kernel-panic` (or `wayland`) to force a backend. Please report the exact error if you file an issue.
* **No sound:** the game runs fine without audio; check `SDL_AUDIODRIVER=pipewire kernel-panic` or `pulseaudio` if music/SFX are silent.

## Known limits
No client-side movement prediction (movement feels delayed on high-latency links). Up to 4 players; nobody can join mid-run. Tested on loopback with simulated packet loss, not on real internet paths.
