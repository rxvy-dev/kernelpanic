#include "net.h"
#include <cassert>
#include <cstdio>
#include <thread>
using namespace net;
static int fails = 0;
#define CHECK(c, msg) do { if (!(c)) { printf("FAIL: %s (line %d)\n", msg, __LINE__); fails++; } else printf("ok:   %s\n", msg); } while (0)
static void pump(Host* h, Client* c, int ms) { double t = nowSec(); while (nowSec() - t < ms / 1000.0) { if (h) h->poll(); if (c) c->poll(); std::this_thread::sleep_for(std::chrono::milliseconds(2)); } }
int main() {
    sodium_init();
    // --- invite code round trip
    uint8_t code[16]; randombytes_buf(code, 16); std::string cs = encodeCode(code); uint8_t back[16];
    CHECK(cs.size() == 26 + 5 && decodeCode(cs, back) && !memcmp(code, back, 16), "invite code encode/decode round trip");
    CHECK(!decodeCode("ABC", back) && !decodeCode("!!!!!-!!!!!-!!!!!-!!!!!-!!!!!-!", back) && !decodeCode("", back), "malformed invite codes rejected");
    // --- session unit tests
    { Sess a, b; a.sid = b.sid = 7; randombytes_buf(a.txk, 32); memcpy(b.rxk, a.txk, 32);
      uint8_t pt[100], ct[1400], out[1400]; randombytes_buf(pt, 100); size_t pl;
      size_t n1 = a.seal(ct, sizeof ct, pt, 100); CHECK(n1 && b.open(ct, n1, out, pl) && pl == 100 && !memcmp(out, pt, 100), "seal/open works");
      CHECK(!b.open(ct, n1, out, pl), "replayed packet rejected");
      uint8_t ct2[1400]; size_t n2 = a.seal(ct2, sizeof ct2, pt, 100); uint8_t ct3[1400]; size_t n3 = a.seal(ct3, sizeof ct3, pt, 100);
      CHECK(b.open(ct3, n3, out, pl) && b.open(ct2, n2, out, pl), "reordered packets inside the window accepted once");
      uint8_t bad[1400]; memcpy(bad, ct2, n2); size_t n4 = a.seal(bad, sizeof bad, pt, 100); bad[20] ^= 1; CHECK(!b.open(bad, n4, out, pl), "bit-flipped ciphertext rejected");
      size_t n5 = a.seal(bad, sizeof bad, pt, 100); bad[6] ^= 1; CHECK(!b.open(bad, n5, out, pl), "tampered header/counter rejected (AAD)");
      for (int i = 0; i < 200; i++) a.seal(bad, sizeof bad, pt, 100); size_t n6 = a.seal(bad, sizeof bad, pt, 100); CHECK(b.open(bad, n6, out, pl), "far-ahead counter accepted");
      CHECK(!b.open(ct2, n2, out, pl), "packet older than the window rejected");
      CHECK(a.seal(ct, sizeof ct, pt, MAX_PLAIN + 1) == 0, "oversize plaintext refused"); }
    // --- handshake + reliable channel under loss
    Host host; uint8_t hc[16]; randombytes_buf(hc, 16); CHECK(host.start(0, hc), "host starts"); uint16_t port = host.sock.port();
    std::string good = encodeCode(hc);
    Client c; CHECK(c.connect("127.0.0.1:" + std::to_string(port), good), "client dials"); pump(&host, &c, 400);
    CHECK(c.st == Client::CONNECTED && host.confirmedCount() == 1, "handshake completes with correct invite code");
    uint32_t sid = host.peers.begin()->first; host.ev.clear(); c.ev.clear();
    g_lossPct = 30; const int N = 300; int hostRecv = 0, cliRecv = 0; bool ordered = true; int sentH = 0, sentC = 0;
    double t0 = nowSec(); while (nowSec() - t0 < 12 && (hostRecv < N || cliRecv < N)) {
        if (sentH < N) { uint8_t m[3] = { 1, (uint8_t)(sentH & 255), (uint8_t)(sentH >> 8) }; if (host.sendR(sid, m, 3)) sentH++; }
        if (sentC < N) { uint8_t m[3] = { 2, (uint8_t)(sentC & 255), (uint8_t)(sentC >> 8) }; if (c.sendR(m, 3)) sentC++; }
        uint8_t j[4] = { 9, 1, 2, 3 }; host.sendU(sid, j, 4); c.sendU(j, 4);
        host.poll(); c.poll();
        for (auto& e : host.ev) if (e.kind == Event::REL) { int v = e.data[1] | (e.data[2] << 8); if (v != hostRecv) ordered = false; hostRecv++; } host.ev.clear();
        for (auto& e : c.ev) if (e.kind == Event::REL) { int v = e.data[1] | (e.data[2] << 8); if (v != cliRecv) ordered = false; cliRecv++; } c.ev.clear();
        std::this_thread::sleep_for(std::chrono::milliseconds(3));
    }
    g_lossPct = 0; printf("      (30%% loss) host got %d/%d, client got %d/%d reliable msgs\n", hostRecv, N, cliRecv, N);
    CHECK(hostRecv == N && cliRecv == N && ordered, "reliable messages arrive exactly once, in order, despite 30% packet loss");
    // --- wrong code
    { Host h2; uint8_t c2[16]; randombytes_buf(c2, 16); h2.start(0, c2); Client bad; uint8_t other[16]; randombytes_buf(other, 16); bad.connect("127.0.0.1:" + std::to_string(h2.sock.port()), encodeCode(other)); pump(&h2, &bad, 1500);
      CHECK(bad.st == Client::CONNECTING && h2.peers.empty() && h2.rejected >= 1, "wrong invite code: no session, no state created on the host"); }
    // --- amplification: valid-size garbage gets no reply; a valid HELLO gets a reply of exactly the same size
    { Sock raw; raw.open(0); Addr to; resolve("127.0.0.1:" + std::to_string(port), 1, to); uint8_t junk[128]; randombytes_buf(junk, 128); junk[0] = T_HELLO; junk[1] = VER;
      raw.send(to, junk, 128); pump(&host, nullptr, 100); uint8_t rb[2048]; Addr f; CHECK(raw.recv(rb, sizeof rb, f) < 0, "unauthenticated HELLO gets no response at all");
      Sock spy; spy.open(0); Client probe; probe.connect("127.0.0.1:" + std::to_string(spy.port()), good); probe.poll(); pump(nullptr, &probe, 50);
      uint8_t cap[2048]; Addr from; ssize_t r = spy.recv(cap, sizeof cap, from); CHECK(r == (ssize_t)HS_LEN, "HELLO is padded to 128 bytes");
      if (r == (ssize_t)HS_LEN) { size_t peersBefore = host.peers.size(); raw.send(to, cap, HS_LEN); pump(&host, nullptr, 100); ssize_t r2 = raw.recv(rb, sizeof rb, f);
        CHECK(r2 == (ssize_t)HS_LEN, "WELCOME is exactly as large as HELLO (no amplification)"); pump(&host, nullptr, 100);
        size_t unconf = 0; for (auto& kv : host.peers) if (!kv.second.confirmed) unconf++;
        CHECK(unconf == 1 && host.confirmedCount() == 1, "replayed HELLO cannot become a confirmed session"); pump(&host, nullptr, 5300);
        CHECK(host.peers.size() == peersBefore, "the half-open replay entry expires on its own"); } }
    // --- fuzzing: random garbage, and bit-flipped valid packets, into both ends (run this under ASan/UBSan)
    { Sock raw; raw.open(0); Addr to; resolve("127.0.0.1:" + std::to_string(port), 1, to); size_t peersBefore = host.peers.size(); uint64_t rej0 = host.rejected;
      for (int i = 0; i < 60000; i++) { uint8_t b[1500]; size_t n = randombytes_uniform(1401); randombytes_buf(b, n); if (n && (i & 1)) b[0] = 0xA1 + randombytes_uniform(3); if (n >= 5 && (i % 3 == 0)) putU32(b + 1, sid); raw.send(to, b, n); if (i % 200 == 0) host.poll(); }
      pump(&host, nullptr, 200);
      CHECK(host.peers.size() == peersBefore && host.confirmedCount() == 1, "60k garbage datagrams: host state unchanged, still alive"); printf("      rejected packets counted: %llu\n", (unsigned long long)(host.rejected - rej0));
      // mutate real encrypted traffic
      Sess a; a.sid = 5; randombytes_buf(a.txk, 32); uint8_t pt[300], ct[1400]; randombytes_buf(pt, 300); size_t m = a.seal(ct, sizeof ct, pt, 300);
      Sess b; b.sid = 5; memcpy(b.rxk, a.txk, 32); int accepted = 0; for (int i = 0; i < 20000; i++) { uint8_t mut[1400]; memcpy(mut, ct, m); int flips = 1 + randombytes_uniform(4); for (int k = 0; k < flips; k++) mut[randombytes_uniform((uint32_t)m)] ^= (uint8_t)(1u << randombytes_uniform(8)); if (!memcmp(mut, ct, m)) continue; /* flips cancelled out: identical packet, not a mutation */ uint8_t o[1400]; size_t pl; if (b.open(mut, m, o, pl)) accepted++; }
      CHECK(accepted == 0, "20k bit-flipped copies of a real packet: none accepted");
      // authenticated peers sending malformed payloads must not crash the reliable parser
      Chan ch; int got = 0; for (int i = 0; i < 100000; i++) { uint8_t b2[64]; size_t n = randombytes_uniform(65); randombytes_buf(b2, n); ch.parse(b2, n, [&](const uint8_t*, size_t) { got++; }, [&](const uint8_t*, size_t) { got++; }); }
      CHECK(true, "100k malformed channel payloads parsed without fault"); }
    // --- host to client garbage
    { Sock raw; raw.open(0); Addr to; Client c3; uint8_t cc[16]; randombytes_buf(cc, 16); Host h3; h3.start(0, cc); c3.connect("127.0.0.1:" + std::to_string(h3.sock.port()), encodeCode(cc)); pump(&h3, &c3, 300);
      Addr dst; dst.ss.ss_family = AF_INET; ((sockaddr_in*)&dst.ss)->sin_family = AF_INET; ((sockaddr_in*)&dst.ss)->sin_addr.s_addr = htonl(INADDR_LOOPBACK); ((sockaddr_in*)&dst.ss)->sin_port = htons(c3.sock.port()); dst.len = sizeof(sockaddr_in);
      for (int i = 0; i < 20000; i++) { uint8_t b[1500]; size_t n = randombytes_uniform(1401); randombytes_buf(b, n); if (n) b[0] = 0xA1 + randombytes_uniform(3); raw.send(dst, b, n); if (i % 100 == 0) c3.poll(); }
      pump(&h3, &c3, 200); CHECK(c3.st == Client::CONNECTED, "client survives 20k forged datagrams and stays connected"); }
    // --- address parsing
    { Addr a; CHECK(resolve("127.0.0.1", 47474, a) && resolve("127.0.0.1:9", 1, a) && resolve("[::1]:5000", 1, a) && resolve("::1", 47474, a), "address parsing: v4, v4:port, [v6]:port, bare v6");
      CHECK(!resolve("", 1, a) && !resolve("host:99999", 1, a) && !resolve("[::1", 1, a) && !resolve("a:b:c:d:e", 1, a) && !resolve(std::string(400, 'a'), 1, a), "address parsing: hostile input rejected"); }

    // --- invites that carry the host's addresses
    { uint8_t sec[16]; randombytes_buf(sec, 16); std::vector<Addr> eps(3); resolve("[2001:db8::7]:47474", 1, eps[0]); resolve("203.0.113.9:51000", 1, eps[1]); resolve("192.168.1.20:47474", 1, eps[2]);
      std::string inv = makeInvite(sec, eps); printf("      sample invite (%zu chars): %s\n", inv.size(), inv.c_str());
      uint8_t sec2[16]; std::vector<Addr> back; CHECK(parseInvite(inv, sec2, back) && !memcmp(sec, sec2, 16) && back.size() == 3 && back[0].same(eps[0]) && back[1].same(eps[1]) && back[2].same(eps[2]), "invite round-trips: secret + all three endpoints");
      CHECK(parseInvite("  " + inv + "\n", sec2, back), "invite tolerates surrounding whitespace / newline from copy-paste");
      std::string lower = inv; for (auto& c : lower) c = (char)tolower((unsigned char)c); CHECK(parseInvite(lower, sec2, back), "invite is case-insensitive");
      int caught = 0, total = 0; for (size_t i = 3; i < inv.size(); i++) { if (inv[i] == '-') continue; std::string bad = inv; bad[i] = bad[i] == '7' ? '8' : '7'; total++; std::vector<Addr> b2; uint8_t s4[16]; bool acc2 = parseInvite(bad, s4, b2); if (!acc2 || (!memcmp(s4, sec, 16) && b2.size() == 3 && b2[0].same(eps[0]) && b2[1].same(eps[1]) && b2[2].same(eps[2]))) caught++; /* rejected, or only padding bits changed = identical invite */ }
      printf("      single-character typos detected: %d/%d\n", caught, total); CHECK(caught == total, "every single-character typo is detected (checksum)");
      CHECK(!parseInvite(inv.substr(0, inv.size() - 6), sec2, back) && !parseInvite(inv.substr(0, 20), sec2, back) && !parseInvite("KP-", sec2, back) && !parseInvite("", sec2, back), "truncated invites rejected");
      int acc = 0; for (int i = 0; i < 200000; i++) { std::string g = "KP-"; int n = randombytes_uniform(120); static const char* A = "0123456789ABCDEFGHJKMNPQRSTVWXYZ-"; for (int k = 0; k < n; k++) g += A[randombytes_uniform(33)]; if (parseInvite(g, sec2, back)) acc++; }
      CHECK(acc == 0, "200k random invite-shaped strings: none accepted, no crash");
      uint8_t hb[80]; for (int i = 0; i < 100000; i++) { size_t n = randombytes_uniform(80); randombytes_buf(hb, n); std::string g = "KP-" + b32(hb, n); parseInvite(g, sec2, back); }
      CHECK(true, "100k random binary payloads parsed without fault");
      Addr z; resolve("0.0.0.0:47474", 1, z); Addr mc; resolve("224.0.0.1:5", 1, mc); Addr p0; resolve("1.2.3.4:1", 1, p0); ((sockaddr_in*)&p0.ss)->sin_port = 0;
      CHECK(makeInvite(sec, { z, mc, p0 }).empty() == false && ([&] { std::vector<Addr> e2; uint8_t s3[16]; return parseInvite(makeInvite(sec, { z, mc, p0 }), s3, e2); })() == false, "nonsense endpoints (0.0.0.0, multicast, port 0) are never dialled"); }
    // --- join with several candidate endpoints; only one is real
    { Host h; uint8_t sec[16]; randombytes_buf(sec, 16); h.start(0, sec); std::vector<Addr> eps(3); resolve("127.0.0.1:9", 1, eps[0]); resolve("127.0.0.1:" + std::to_string(h.sock.port()), 1, eps[1]); resolve("10.255.255.1:47474", 1, eps[2]);
      Client cl; CHECK(cl.connectInvite(makeInvite(sec, eps)), "client accepts a 3-endpoint invite"); pump(&h, &cl, 500);
      CHECK(cl.st == Client::CONNECTED && h.confirmedCount() == 1, "client finds the working endpoint among dead ones and connects");
      Client bad; uint8_t other[16]; randombytes_buf(other, 16); bad.connectInvite(makeInvite(other, eps)); pump(&h, &bad, 800); CHECK(bad.st == Client::CONNECTING && h.confirmedCount() == 1, "invite with a different secret cannot join"); }
    // --- STUN discovery against a local mock server
    { Host h; uint8_t sec[16]; randombytes_buf(sec, 16); h.start(0, sec); Sock mock; mock.open(0); h.stunServers = { "127.0.0.1:" + std::to_string(mock.port()) }; h.startStun();
      double t0 = nowSec(); bool answered = false; while (nowSec() - t0 < 4 && !h.havePublic) {
          h.poll(); uint8_t rb[512]; Addr from; ssize_t r = mock.recv(rb, sizeof rb, from);
          if (r == 20 && rb[0] == 0 && rb[1] == 1) { uint8_t rs[64] = { 0x01, 0x01, 0, 12, 0x21, 0x12, 0xA4, 0x42 }; memcpy(rs + 8, rb + 8, 12); rs[20] = 0; rs[21] = 0x20; rs[22] = 0; rs[23] = 8; rs[25] = 1;
              auto a = (sockaddr_in*)&from.ss; uint16_t port = ntohs(a->sin_port) ^ 0x2112; rs[26] = (uint8_t)(port >> 8); rs[27] = (uint8_t)port; uint8_t* ip = (uint8_t*)&a->sin_addr; const uint8_t ck[4] = { 0x21, 0x12, 0xA4, 0x42 }; for (int i = 0; i < 4; i++) rs[28 + i] = ip[i] ^ ck[i]; mock.send(from, rs, 32); answered = true; }
          std::this_thread::sleep_for(std::chrono::milliseconds(3)); }
      CHECK(answered && h.havePublic && h.publicEp.ss.ss_family == AF_INET && ntohs(((sockaddr_in*)&h.publicEp.ss)->sin_port) == h.sock.port(), "STUN: host learns its public endpoint from the (mock) server's XOR-MAPPED-ADDRESS");
      uint8_t tx[12] = { 0 }; uint8_t rsp[80]; int okc = 0; Addr o; for (int i = 0; i < 200000; i++) { size_t n = randombytes_uniform(80); randombytes_buf(rsp, n); if (n > 20 && (i & 1)) { rsp[0] = 1; rsp[1] = 1; memcpy(rsp + 4, "\x21\x12\xA4\x42", 4); memset(rsp + 8, 0, 12); rsp[2] = 0; rsp[3] = (uint8_t)((n - 20) & ~3u); } if (parseStunResponse(rsp, n, tx, o)) okc++; }
      CHECK(true, "200k malformed STUN responses parsed without fault"); (void)okc; }
    printf(fails ? "\n%d FAILED\n" : "\nALL NET TESTS PASSED\n", fails); return fails ? 1 : 0;
}
