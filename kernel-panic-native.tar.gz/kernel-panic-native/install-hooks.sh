#!/bin/sh
# Installs the default hook (kitty recolor) without overwriting anything you already have.
D="${XDG_CONFIG_HOME:-$HOME/.config}/kernel-panic/hooks"
mkdir -p "$D/examples"
[ -e "$D/on_any" ] || cp hooks/on_any "$D/on_any"
cp -n hooks/examples/* "$D/examples/" 2>/dev/null
echo "Hooks installed in $D"
echo "To let the game recolor kitty, add to ~/.config/kitty/kitty.conf and restart kitty:"
echo "  allow_remote_control socket-only"
echo "  listen_on unix:/tmp/kitty"
