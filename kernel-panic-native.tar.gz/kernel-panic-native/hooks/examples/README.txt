Hooks are executables named on_<event> in ~/.config/kernel-panic/hooks/ (on_any runs for every event).
Events: start wave boss bossdead sudo levelup gameover highscore
Env vars: KP_EVENT KP_WAVE KP_SCORE KP_KILLS KP_LEVEL KP_HP KP_TIME KP_BOSS KP_COLOR KP_BEST
