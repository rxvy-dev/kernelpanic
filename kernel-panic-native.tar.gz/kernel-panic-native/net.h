// net.h - small secure UDP transport for KERNEL PANIC co-op. Header-only, needs libsodium + POSIX sockets.
//
// Threat model / design:
//  * The host generates a random 128-bit room secret (the invite code). Only people who have it can talk to the host.
//  * Handshake = ephemeral X25519 key exchange (forward secrecy) authenticated with keyed BLAKE2b using the room secret
//    (Noise-NNpsk0 style). Packets from anyone without the secret fail a 16-byte MAC and are dropped with no state created.
//  * Every data packet is XChaCha20-Poly1305 with a per-direction key; header is authenticated; 64-packet replay window.
//  * Handshake replies are the same size as requests (128 bytes) so the host can't be used for traffic amplification.
//  * All parsing goes through a bounds-checked Reader; nothing is trusted, no pointers or lengths from the wire are followed blindly.
//  * Bounded everything: max peers, pending handshakes, reliable queue, datagram size, handshake rate.
// It does NOT hide that you are talking to someone (IP addresses are visible), and the host is trusted by clients.
#pragma once
#include <sodium.h>

#include <arpa/inet.h>
#include <fcntl.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <memory>
#include <mutex>
#include <thread>
#include <string>
#include <unordered_map>
#include <vector>

namespace net {
static constexpr uint8_t VER = 1;
static constexpr size_t HS_LEN = 128, MAX_DGRAM = 1400, MAX_PLAIN = 1150, HDR = 13;
static constexpr uint8_t T_HELLO = 0xA1, T_WELCOME = 0xA2, T_DATA = 0xA3;
inline int g_lossPct = 0;   // test hook: simulated packet loss (applied on send)

inline double nowSec() { return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count(); }

// ---------------------------------------------------------------- bounds-checked serialization
struct Writer {
    uint8_t* b; size_t cap, n = 0; bool ok = true;
    Writer(uint8_t* buf, size_t c) : b(buf), cap(c) {}
    void raw(const void* p, size_t k) { if (!ok || n + k > cap) { ok = false; return; } if (k) memcpy(b + n, p, k); n += k; }
    void u8(uint8_t v) { raw(&v, 1); }
    void i8(int8_t v) { u8((uint8_t)v); }
    void u16(uint16_t v) { uint8_t t[2] = { (uint8_t)v, (uint8_t)(v >> 8) }; raw(t, 2); }
    void i16(int16_t v) { u16((uint16_t)v); }
    void u32(uint32_t v) { uint8_t t[4] = { (uint8_t)v, (uint8_t)(v >> 8), (uint8_t)(v >> 16), (uint8_t)(v >> 24) }; raw(t, 4); }
    void str(const std::string& s, size_t maxLen) { size_t k = s.size() < maxLen ? s.size() : maxLen; u8((uint8_t)k); raw(s.data(), k); }
};
struct Reader {
    const uint8_t* b; size_t len, pos = 0; bool ok = true;
    Reader(const uint8_t* p, size_t n) : b(p), len(n) {}
    const uint8_t* take(size_t k) { if (!ok || k > len - pos) { ok = false; return nullptr; } const uint8_t* p = b + pos; pos += k; return p; }
    uint8_t u8() { const uint8_t* p = take(1); return p ? p[0] : 0; }
    int8_t i8() { return (int8_t)u8(); }
    uint16_t u16() { const uint8_t* p = take(2); return p ? (uint16_t)(p[0] | (p[1] << 8)) : 0; }
    int16_t i16() { return (int16_t)u16(); }
    uint32_t u32() { const uint8_t* p = take(4); return p ? (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24) : 0; }
    std::string str(size_t maxLen) { size_t k = u8(); if (k > maxLen) { ok = false; return ""; } const uint8_t* p = take(k); return p ? std::string((const char*)p, k) : std::string(); }
    size_t left() const { return ok ? len - pos : 0; }
    const uint8_t* cur() const { return b + pos; }
};

// ---------------------------------------------------------------- invite codes (Crockford base32, 128 bits)
inline std::string encodeCode(const uint8_t k[16]) {
    static const char* A = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"; std::string o; uint32_t buf = 0; int bits = 0;
    for (int i = 0; i < 16; i++) { buf = (buf << 8) | k[i]; bits += 8; while (bits >= 5) { o += A[(buf >> (bits - 5)) & 31]; bits -= 5; } }
    if (bits > 0) o += A[(buf << (5 - bits)) & 31];
    std::string g; for (size_t i = 0; i < o.size(); i++) { if (i && i % 5 == 0) g += '-'; g += o[i]; }
    return g;
}
inline bool decodeCode(const std::string& s, uint8_t out[16]) {
    uint32_t buf = 0; int bits = 0, n = 0;
    for (char c : s) {
        if (c == '-' || c == ' ') continue;
        static const char* A = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"; c = (char)toupper((unsigned char)c);
        if (c == 'O') c = '0'; else if (c == 'I' || c == 'L') c = '1';
        const char* p = c ? strchr(A, c) : nullptr; if (!p) return false; int v = (int)(p - A);
        buf = (buf << 5) | (uint32_t)v; bits += 5;
        if (bits >= 8) { if (n >= 16) break; out[n++] = (uint8_t)((buf >> (bits - 8)) & 255); bits -= 8; }
    }
    return n == 16;
}
inline void pskFromCode(const uint8_t code[16], uint8_t psk[32]) {
    static const uint8_t ctx[] = "kernel-panic/room-secret/v1";
    crypto_generichash(psk, 32, code, 16, ctx, 16);   // key = first 16 bytes of the context string, domain separation only
}

// ---------------------------------------------------------------- addresses and sockets
struct Addr {
    sockaddr_storage ss; socklen_t len = 0;
    Addr() { memset(&ss, 0, sizeof ss); }
    bool same(const Addr& o) const {
        if (ss.ss_family != o.ss.ss_family) return false;
        if (ss.ss_family == AF_INET6) { auto a = (const sockaddr_in6*)&ss; auto b = (const sockaddr_in6*)&o.ss; return a->sin6_port == b->sin6_port && !memcmp(&a->sin6_addr, &b->sin6_addr, 16); }
        if (ss.ss_family == AF_INET) { auto a = (const sockaddr_in*)&ss; auto b = (const sockaddr_in*)&o.ss; return a->sin_port == b->sin_port && a->sin_addr.s_addr == b->sin_addr.s_addr; }
        return false;
    }
    std::string str() const {
        char h[INET6_ADDRSTRLEN] = "?"; uint16_t port = 0;
        if (ss.ss_family == AF_INET6) { auto a = (const sockaddr_in6*)&ss; inet_ntop(AF_INET6, &a->sin6_addr, h, sizeof h); port = ntohs(a->sin6_port); return std::string("[") + h + "]:" + std::to_string(port); }
        if (ss.ss_family == AF_INET) { auto a = (const sockaddr_in*)&ss; inet_ntop(AF_INET, &a->sin_addr, h, sizeof h); port = ntohs(a->sin_port); return std::string(h) + ":" + std::to_string(port); }
        return h;
    }
};
// "host", "host:port", "[v6]:port", bare v6 literal. Returns false if it cannot be resolved.
inline bool resolve(const std::string& in, uint16_t defPort, Addr& out, bool preferV4 = false) {
    std::string host = in, port = std::to_string(defPort);
    while (!host.empty() && host.front() == ' ') host.erase(host.begin()); while (!host.empty() && host.back() == ' ') host.pop_back();
    if (host.empty() || host.size() > 200) return false;
    if (host[0] == '[') { size_t e = host.find(']'); if (e == std::string::npos) return false; if (e + 1 < host.size() && host[e + 1] == ':') port = host.substr(e + 2); host = host.substr(1, e - 1); }
    else { size_t c = host.find(':'); if (c != std::string::npos && host.find(':', c + 1) == std::string::npos) { port = host.substr(c + 1); host = host.substr(0, c); } }
    if (port.empty() || port.size() > 5 || port.find_first_not_of("0123456789") != std::string::npos || atoi(port.c_str()) < 1 || atoi(port.c_str()) > 65535) return false;
    addrinfo hints; memset(&hints, 0, sizeof hints); hints.ai_socktype = SOCK_DGRAM; hints.ai_family = AF_UNSPEC; hints.ai_flags = AI_NUMERICSERV;
    addrinfo* res = nullptr;
    if (getaddrinfo(host.c_str(), port.c_str(), &hints, &res) != 0 || !res) return false;
    bool ok = false;
    for (addrinfo* r = res; r; r = r->ai_next) if ((r->ai_family == AF_INET || r->ai_family == AF_INET6) && r->ai_addrlen <= sizeof(sockaddr_storage)) { memcpy(&out.ss, r->ai_addr, r->ai_addrlen); out.len = (socklen_t)r->ai_addrlen; ok = true; if ((r->ai_family == AF_INET6) != preferV4) break; }
    freeaddrinfo(res);
    return ok;
}
struct Sock {
    int fd = -1; bool v6 = false;
    ~Sock() { close(); }
    void close() { if (fd >= 0) ::close(fd); fd = -1; }
    bool open(uint16_t port) {   // dual-stack when possible
        fd = ::socket(AF_INET6, SOCK_DGRAM, 0);
        if (fd >= 0) {
            int off = 0; setsockopt(fd, IPPROTO_IPV6, IPV6_V6ONLY, &off, sizeof off);
            sockaddr_in6 a; memset(&a, 0, sizeof a); a.sin6_family = AF_INET6; a.sin6_port = htons(port); a.sin6_addr = in6addr_any;
            if (bind(fd, (sockaddr*)&a, sizeof a) == 0) v6 = true; else { ::close(fd); fd = -1; }
        }
        if (fd < 0) {
            fd = ::socket(AF_INET, SOCK_DGRAM, 0); if (fd < 0) return false;
            sockaddr_in a; memset(&a, 0, sizeof a); a.sin_family = AF_INET; a.sin_port = htons(port); a.sin_addr.s_addr = INADDR_ANY;
            if (bind(fd, (sockaddr*)&a, sizeof a) != 0) { ::close(fd); fd = -1; return false; }
            v6 = false;
        }
        int fl = fcntl(fd, F_GETFL, 0); fcntl(fd, F_SETFL, fl | O_NONBLOCK);
        return true;
    }
    uint16_t port() const { sockaddr_storage s; socklen_t l = sizeof s; if (getsockname(fd, (sockaddr*)&s, &l) != 0) return 0; return ntohs(s.ss_family == AF_INET6 ? ((sockaddr_in6*)&s)->sin6_port : ((sockaddr_in*)&s)->sin_port); }
    void send(const Addr& to, const uint8_t* d, size_t n) {
        if (fd < 0 || n > MAX_DGRAM) return;
        if (g_lossPct > 0 && (int)(randombytes_uniform(100)) < g_lossPct) return;
        if (v6 && to.ss.ss_family == AF_INET) {   // IPv4 destination through a dual-stack socket = v4-mapped address
            sockaddr_in6 m; memset(&m, 0, sizeof m); m.sin6_family = AF_INET6; auto a = (const sockaddr_in*)&to.ss; m.sin6_port = a->sin_port;
            m.sin6_addr.s6_addr[10] = 0xff; m.sin6_addr.s6_addr[11] = 0xff; memcpy(&m.sin6_addr.s6_addr[12], &a->sin_addr, 4);
            sendto(fd, d, n, 0, (sockaddr*)&m, sizeof m);
        } else if (!v6 && to.ss.ss_family == AF_INET6) return;
        else sendto(fd, d, n, 0, (const sockaddr*)&to.ss, to.len);
    }
    ssize_t recv(uint8_t* buf, size_t cap, Addr& from) {
        from = Addr(); from.len = sizeof from.ss; ssize_t r = recvfrom(fd, buf, cap, 0, (sockaddr*)&from.ss, &from.len);
        if (r >= 0 && from.ss.ss_family == AF_INET6) {   // normalise v4-mapped sources back to AF_INET so equality/logging is stable
            auto a = (sockaddr_in6*)&from.ss; static const uint8_t pre[12] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xff, 0xff };
            if (!memcmp(a->sin6_addr.s6_addr, pre, 12)) { sockaddr_in v; memset(&v, 0, sizeof v); v.sin_family = AF_INET; v.sin_port = a->sin6_port; memcpy(&v.sin_addr, &a->sin6_addr.s6_addr[12], 4); memset(&from.ss, 0, sizeof from.ss); memcpy(&from.ss, &v, sizeof v); from.len = sizeof v; }
        }
        return r;
    }
};
// Non-loopback local addresses worth telling a friend about (global IPv6 first).
inline std::vector<std::string> localAddresses() {
    std::vector<std::string> v6, v4; ifaddrs* ifa = nullptr; if (getifaddrs(&ifa) != 0) return {};
    for (ifaddrs* i = ifa; i; i = i->ifa_next) {
        if (!i->ifa_addr || (i->ifa_flags & IFF_LOOPBACK) || !(i->ifa_flags & IFF_UP)) continue;
        char h[INET6_ADDRSTRLEN];
        if (i->ifa_addr->sa_family == AF_INET6) { auto a = (sockaddr_in6*)i->ifa_addr; if (IN6_IS_ADDR_LINKLOCAL(&a->sin6_addr)) continue; inet_ntop(AF_INET6, &a->sin6_addr, h, sizeof h); v6.push_back(std::string("[") + h + "]"); }
        else if (i->ifa_addr->sa_family == AF_INET) { auto a = (sockaddr_in*)i->ifa_addr; inet_ntop(AF_INET, &a->sin_addr, h, sizeof h); v4.push_back(h); }
    }
    freeifaddrs(ifa); v6.insert(v6.end(), v4.begin(), v4.end()); return v6;
}


// ---------------------------------------------------------------- invites: ONE string = room secret + where to find the host
inline std::string b32(const uint8_t* d, size_t n) {
    static const char* A = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"; std::string o; uint32_t buf = 0; int bits = 0;
    for (size_t i = 0; i < n; i++) { buf = (buf << 8) | d[i]; bits += 8; while (bits >= 5) { o += A[(buf >> (bits - 5)) & 31]; bits -= 5; } }
    if (bits > 0) o += A[(buf << (5 - bits)) & 31];
    return o;
}
inline bool unb32(const std::string& s, std::vector<uint8_t>& out) {
    static const char* A = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"; uint32_t buf = 0; int bits = 0; out.clear();
    for (char c : s) {
        if (c == '-' || c == ' ' || c == '\n' || c == '\r' || c == '\t') continue;
        c = (char)toupper((unsigned char)c); if (c == 'O') c = '0'; else if (c == 'I' || c == 'L') c = '1';
        const char* p = c ? strchr(A, c) : nullptr; if (!p) return false;
        buf = (buf << 5) | (uint32_t)(p - A); bits += 5; if (bits >= 8) { out.push_back((uint8_t)((buf >> (bits - 8)) & 255)); bits -= 8; if (out.size() > 200) return false; }
    }
    return true;
}
inline bool endpointOk(const Addr& a) {   // refuse endpoints that make no sense to dial
    if (a.ss.ss_family == AF_INET) { auto p = (const sockaddr_in*)&a.ss; uint32_t ip = ntohl(p->sin_addr.s_addr); return p->sin_port != 0 && ip != 0 && ip != 0xFFFFFFFFu && (ip >> 28) != 0xE; }
    if (a.ss.ss_family == AF_INET6) { auto p = (const sockaddr_in6*)&a.ss; static const uint8_t z[16] = { 0 }; return p->sin6_port != 0 && memcmp(&p->sin6_addr, z, 16) != 0 && p->sin6_addr.s6_addr[0] != 0xFF; }
    return false;
}
inline std::string makeInvite(const uint8_t secret[16], const std::vector<Addr>& eps) {
    uint8_t b[160]; Writer w(b, sizeof b); w.u8(1); w.raw(secret, 16); size_t n = 0; for (auto& e : eps) if (endpointOk(e) && n < 4) n++;
    w.u8((uint8_t)n); size_t k = 0;
    for (auto& e : eps) {
        if (!endpointOk(e) || k >= 4) continue; k++;
        if (e.ss.ss_family == AF_INET) { auto p = (const sockaddr_in*)&e.ss; w.u8(4); w.u16(ntohs(p->sin_port)); w.raw(&p->sin_addr, 4); }
        else { auto p = (const sockaddr_in6*)&e.ss; w.u8(6); w.u16(ntohs(p->sin6_port)); w.raw(&p->sin6_addr, 16); }
    }
    uint8_t h[32]; crypto_generichash(h, 32, b, w.n, nullptr, 0); w.raw(h, 3);   // 24-bit checksum catches typos and truncation
    if (!w.ok) return "";
    std::string t = b32(b, w.n), g = "KP"; for (size_t i = 0; i < t.size(); i++) { if (i % 5 == 0) g += '-'; g += t[i]; }
    return g;
}
inline bool parseInvite(const std::string& in, uint8_t secret[16], std::vector<Addr>& eps) {
    std::string s = in; while (!s.empty() && isspace((unsigned char)s.front())) s.erase(s.begin()); while (!s.empty() && isspace((unsigned char)s.back())) s.pop_back();
    if (s.size() < 6 || s.size() > 300 || (s[0] != 'K' && s[0] != 'k') || (s[1] != 'P' && s[1] != 'p') || s[2] != '-') return false;
    std::vector<uint8_t> b; if (!unb32(s.substr(3), b) || b.size() < 1 + 16 + 1 + 3) return false;
    // b32 pads with up to 4 zero bits: drop any trailing partial byte the decoder did not emit
    Reader r(b.data(), b.size()); if (r.u8() != 1) return false; const uint8_t* sec = r.take(16); int n = r.u8(); if (!r.ok || n < 1 || n > 4) return false;
    std::vector<Addr> out;
    for (int i = 0; i < n; i++) {
        int fam = r.u8(); uint16_t port = r.u16(); Addr a; if (!r.ok) return false;
        if (fam == 4) { const uint8_t* ip = r.take(4); if (!ip) return false; sockaddr_in* p = (sockaddr_in*)&a.ss; p->sin_family = AF_INET; p->sin_port = htons(port); memcpy(&p->sin_addr, ip, 4); a.len = sizeof(sockaddr_in); }
        else if (fam == 6) { const uint8_t* ip = r.take(16); if (!ip) return false; sockaddr_in6* p = (sockaddr_in6*)&a.ss; p->sin6_family = AF_INET6; p->sin6_port = htons(port); memcpy(&p->sin6_addr, ip, 16); a.len = sizeof(sockaddr_in6); }
        else return false;
        if (!endpointOk(a)) return false; out.push_back(a);
    }
    size_t used = r.pos; const uint8_t* ck = r.take(3); if (!ck) return false;
    uint8_t h[32]; crypto_generichash(h, 32, b.data(), used, nullptr, 0); if (memcmp(h, ck, 3) != 0) return false;
    memcpy(secret, sec, 16); eps = out; return true;
}
// Addresses of this machine worth putting in an invite, best first: global IPv6, then Tailscale/CGNAT IPv4, then LAN IPv4.
inline std::vector<Addr> localEndpoints(uint16_t port) {
    std::vector<Addr> v6, ts, lan; ifaddrs* ifa = nullptr; if (getifaddrs(&ifa) != 0) return {};
    for (ifaddrs* i = ifa; i; i = i->ifa_next) {
        if (!i->ifa_addr || (i->ifa_flags & IFF_LOOPBACK) || !(i->ifa_flags & IFF_UP)) continue; Addr a;
        if (i->ifa_addr->sa_family == AF_INET6) { auto s6 = (sockaddr_in6*)i->ifa_addr; if (IN6_IS_ADDR_LINKLOCAL(&s6->sin6_addr) || (s6->sin6_addr.s6_addr[0] & 0xE0) != 0x20) continue; auto p = (sockaddr_in6*)&a.ss; *p = *s6; p->sin6_port = htons(port); a.len = sizeof *p; v6.push_back(a); }
        else if (i->ifa_addr->sa_family == AF_INET) { auto s4 = (sockaddr_in*)i->ifa_addr; uint32_t ip = ntohl(s4->sin_addr.s_addr); auto p = (sockaddr_in*)&a.ss; *p = *s4; p->sin_port = htons(port); a.len = sizeof *p;
            if ((ip >> 22) == (100u << 2 | 1u)) ts.push_back(a);   // 100.64.0.0/10
            else if ((ip >> 24) == 10 || (ip >> 20) == (172u << 4 | 1u) || (ip >> 16) == (192u << 8 | 168u)) lan.push_back(a); }
    }
    freeifaddrs(ifa); std::vector<Addr> out; if (!v6.empty()) out.push_back(v6[0]); if (!ts.empty()) out.push_back(ts[0]); if (!lan.empty()) out.push_back(lan[0]); return out;
}

// ---------------------------------------------------------------- encrypted session
inline void putU32(uint8_t* p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24); }
inline uint32_t getU32(const uint8_t* p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }
inline void putU64(uint8_t* p, uint64_t v) { for (int i = 0; i < 8; i++) p[i] = (uint8_t)(v >> (8 * i)); }
inline uint64_t getU64(const uint8_t* p) { uint64_t v = 0; for (int i = 0; i < 8; i++) v |= (uint64_t)p[i] << (8 * i); return v; }
struct Sess {
    uint32_t sid = 0; uint8_t txk[32] = { 0 }, rxk[32] = { 0 }; uint64_t txc = 0, rxMax = 0, rxMap = 0; bool anyRx = false;
    static void nonce(uint8_t n[24], uint64_t c) { memset(n, 0, 24); putU64(n, c); }
    size_t seal(uint8_t* out, size_t cap, const uint8_t* pt, size_t n) {
        if (n > MAX_PLAIN || cap < HDR + n + crypto_aead_xchacha20poly1305_ietf_ABYTES || txc >= (1ull << 60)) return 0;
        out[0] = T_DATA; putU32(out + 1, sid); putU64(out + 5, txc);
        uint8_t nn[24]; nonce(nn, txc); unsigned long long cl = 0;
        crypto_aead_xchacha20poly1305_ietf_encrypt(out + HDR, &cl, pt, n, out, HDR, nullptr, nn, txk);
        txc++; return HDR + (size_t)cl;
    }
    bool open(const uint8_t* pkt, size_t n, uint8_t* pt, size_t& pl) {
        if (n < HDR + crypto_aead_xchacha20poly1305_ietf_ABYTES || n > HDR + MAX_PLAIN + crypto_aead_xchacha20poly1305_ietf_ABYTES || pkt[0] != T_DATA) return false;
        uint64_t c = getU64(pkt + 5);
        if (anyRx && c <= rxMax) { uint64_t d = rxMax - c; if (d >= 64 || ((rxMap >> d) & 1)) return false; }   // replay / too old
        uint8_t nn[24]; nonce(nn, c); unsigned long long ml = 0;
        if (crypto_aead_xchacha20poly1305_ietf_decrypt(pt, &ml, nullptr, pkt + HDR, n - HDR, pkt, HDR, nn, rxk) != 0) return false;
        if (!anyRx) { rxMax = c; rxMap = 1; anyRx = true; }
        else if (c > rxMax) { uint64_t s = c - rxMax; rxMap = s >= 64 ? 0 : (rxMap << s); rxMap |= 1; rxMax = c; }
        else rxMap |= (1ull << (rxMax - c));
        pl = (size_t)ml; return true;
    }
};
inline void hashTo(uint8_t* out, size_t outLen, const uint8_t* in, size_t inLen, const uint8_t* key = nullptr, size_t keyLen = 0) { crypto_generichash(out, outLen, in, inLen, key, keyLen); }
inline void deriveSession(const uint8_t psk[32], const uint8_t kxS2C[32], const uint8_t kxC2S[32], const uint8_t transcript[32], uint8_t s2c[32], uint8_t c2s[32]) {
    uint8_t b[65]; b[0] = 'S'; memcpy(b + 1, kxS2C, 32); memcpy(b + 33, transcript, 32); hashTo(s2c, 32, b, 65, psk, 32);
    b[0] = 'C'; memcpy(b + 1, kxC2S, 32); hashTo(c2s, 32, b, 65, psk, 32);
    sodium_memzero(b, sizeof b);
}

// ---------------------------------------------------------------- reliable, ordered messages on top of datagrams
struct Chan {
    struct Out { uint16_t id; std::vector<uint8_t> d; };
    std::deque<Out> q; uint16_t nextId = 1, expect = 1;
    bool queue(const uint8_t* d, size_t n) { if (n == 0 || n > 200 || q.size() >= 64) return false; q.push_back({ nextId++, std::vector<uint8_t>(d, d + n) }); return true; }
    size_t build(uint8_t* out, size_t cap, const uint8_t* un, size_t unl) {
        Writer w(out, cap); w.u16((uint16_t)(expect - 1)); size_t cp = w.n; w.u8(0); int cnt = 0;
        for (auto& m : q) { if (cnt >= 6 || w.n + 3 + m.d.size() + unl > cap) break; w.u16(m.id); w.u8((uint8_t)m.d.size()); w.raw(m.d.data(), m.d.size()); cnt++; }
        out[cp] = (uint8_t)cnt; w.raw(un, unl); return w.ok ? w.n : 0;
    }
    template <class FR, class FU> bool parse(const uint8_t* p, size_t n, FR onRel, FU onUn) {
        Reader r(p, n); uint16_t ack = r.u16(); int cnt = r.u8(); if (!r.ok) return false;
        while (!q.empty() && (int16_t)(uint16_t)(ack - q.front().id) >= 0) q.pop_front();
        for (int i = 0; i < cnt; i++) { uint16_t id = r.u16(); size_t len = r.u8(); const uint8_t* d = r.take(len); if (!r.ok) return false; if (id == expect) { expect++; onRel(d, len); } }
        if (r.left() > 0) onUn(r.cur(), r.left());
        return true;
    }
};


// ---------------------------------------------------------------- STUN: learn our public IPv4:port without running any server
struct StunShared { std::mutex m; std::vector<Addr> addrs; bool done = false; };
inline bool parseStunResponse(const uint8_t* b, size_t n, const uint8_t txid[12], Addr& out) {
    if (n < 20 || n > 600 || b[0] != 0x01 || b[1] != 0x01 || memcmp(b + 4, "\x21\x12\xA4\x42", 4) != 0 || memcmp(b + 8, txid, 12) != 0) return false;
    size_t mlen = ((size_t)b[2] << 8) | b[3]; if (mlen + 20 > n || (mlen & 3)) return false; size_t p = 20; bool got = false;
    while (p + 4 <= 20 + mlen) {
        unsigned type = ((unsigned)b[p] << 8) | b[p + 1]; size_t len = ((size_t)b[p + 2] << 8) | b[p + 3]; p += 4; if (p + len > 20 + mlen) return false;
        if ((type == 0x0020 || (type == 0x0001 && !got)) && len >= 8) {
            bool x = type == 0x0020; unsigned fam = b[p + 1]; uint16_t port = (uint16_t)(((unsigned)b[p + 2] << 8) | b[p + 3]); if (x) port ^= 0x2112;
            if (fam == 1 && len >= 8) { sockaddr_in* a = (sockaddr_in*)&out.ss; memset(&out.ss, 0, sizeof out.ss); a->sin_family = AF_INET; a->sin_port = htons(port); uint8_t ip[4]; for (int i = 0; i < 4; i++) ip[i] = b[p + 4 + i] ^ (x ? "\x21\x12\xA4\x42"[i] : 0); memcpy(&a->sin_addr, ip, 4); out.len = sizeof *a; got = endpointOk(out); }
            else if (fam == 2 && len >= 20) { sockaddr_in6* a = (sockaddr_in6*)&out.ss; memset(&out.ss, 0, sizeof out.ss); a->sin6_family = AF_INET6; a->sin6_port = htons(port); uint8_t mask[16]; memcpy(mask, "\x21\x12\xA4\x42", 4); memcpy(mask + 4, txid, 12); for (int i = 0; i < 16; i++) a->sin6_addr.s6_addr[i] = b[p + 4 + i] ^ (x ? mask[i] : 0); out.len = sizeof *a; got = endpointOk(out); }
            if (got && x) return true;
        }
        p += (len + 3) & ~(size_t)3;
    }
    return got;
}

struct Event { enum Kind { CONNECTED, DISCONNECTED, REL, UNREL } kind; uint32_t sid; std::vector<uint8_t> data; };

// ---------------------------------------------------------------- host
struct Peer { uint32_t sid = 0; Addr addr; Sess s; Chan ch; bool confirmed = false; double created = 0, last = 0; uint8_t cnonce[24] = { 0 }; std::vector<uint8_t> welcome; };
class Host {
public:
    Sock sock; uint8_t psk[32] = { 0 }; std::unordered_map<uint32_t, Peer> peers; size_t maxPeers = 3; std::vector<Event> ev; uint64_t rejected = 0;
    std::vector<std::string> stunServers = { "stun.l.google.com:19302", "stun.cloudflare.com:3478" }; bool havePublic = false; Addr publicEp;
    bool stunPending() const { return stun_ && !havePublic && stunTries_ < 6; }
    void startStun() {
        stun_ = std::make_shared<StunShared>(); randombytes_buf(txid_, 12); stunTries_ = 0; havePublic = false; auto st = stun_; auto servers = stunServers;
        std::thread([st, servers]() { for (auto& sv : servers) { Addr a; if (resolve(sv, 3478, a, true) && a.ss.ss_family == AF_INET) { std::lock_guard<std::mutex> l(st->m); st->addrs.push_back(a); } } std::lock_guard<std::mutex> l(st->m); st->done = true; }).detach();
    }
    bool start(uint16_t port, const uint8_t code[16]) { if (sodium_init() < 0) return false; sock.close(); peers.clear(); ev.clear(); pskFromCode(code, psk); return sock.open(port); }
    void stop() { for (auto& kv : peers) { uint8_t bye[1] = { 0xFF }; sendU(kv.first, bye, 1); } sock.close(); peers.clear(); }
    void sendU(uint32_t sid, const uint8_t* d, size_t n) {
        auto it = peers.find(sid); if (it == peers.end()) return; Peer& p = it->second;
        uint8_t pl[MAX_PLAIN], pk[MAX_DGRAM]; size_t k = p.ch.build(pl, sizeof pl, d, n); if (!k) return;
        size_t m = p.s.seal(pk, sizeof pk, pl, k); if (m) sock.send(p.addr, pk, m);
    }
    bool sendR(uint32_t sid, const uint8_t* d, size_t n) { auto it = peers.find(sid); if (it == peers.end()) return false; if (!it->second.ch.queue(d, n)) { drop(sid); return false; } return true; }
    void drop(uint32_t sid) { auto it = peers.find(sid); if (it == peers.end()) return; if (it->second.confirmed) ev.push_back({ Event::DISCONNECTED, sid, {} }); peers.erase(it); }
    void poll() {
        double now = nowSec(); if (now - lastRefill > 1) { hsBudget = 30; macBudget = 4000; lastRefill = now; }
        if (stun_ && !havePublic && stunTries_ < 6 && now - lastStun_ > 0.8) {
            std::vector<Addr> ad; bool done; { std::lock_guard<std::mutex> l(stun_->m); ad = stun_->addrs; done = stun_->done; }
            if (!ad.empty()) { lastStun_ = now; stunTries_++; uint8_t rq[20] = { 0, 1, 0, 0, 0x21, 0x12, 0xA4, 0x42 }; memcpy(rq + 8, txid_, 12); for (auto& a : ad) sock.send(a, rq, 20); }
            else if (done) stunTries_ = 99;
        }
        uint8_t buf[2048]; Addr from;
        for (int i = 0; i < 256; i++) {
            ssize_t r = sock.recv(buf, sizeof buf, from); if (r < 0) break;
            if (r < 1 || (size_t)r > MAX_DGRAM) continue;
            if (buf[0] == 0x01 && stun_ && !havePublic) { Addr pe; if (parseStunResponse(buf, (size_t)r, txid_, pe)) { publicEp = pe; havePublic = true; } continue; }
            if (buf[0] == T_DATA) onData(buf, (size_t)r, from, now);
            else if (buf[0] == T_HELLO && macBudget > 0) { macBudget--; onHello(buf, (size_t)r, from, now); }   // MAC checks are cheap; state creation has its own, smaller budget
        }
        std::vector<uint32_t> dead;
        for (auto& kv : peers) { Peer& p = kv.second; if ((!p.confirmed && now - p.created > 5.0) || (p.confirmed && now - p.last > 8.0)) dead.push_back(kv.first); }
        for (uint32_t s : dead) drop(s);
    }
    size_t confirmedCount() const { size_t c = 0; for (auto& kv : peers) if (kv.second.confirmed) c++; return c; }
private:
    std::shared_ptr<StunShared> stun_; uint8_t txid_[12] = { 0 }; int stunTries_ = 0; double lastStun_ = 0;
    uint8_t nonceRing[256][24] = { { 0 } }; int nonceN = 0; int nonceCount = 0; double lastRefill = 0; int hsBudget = 30, macBudget = 4000;
    void onHello(const uint8_t* b, size_t n, const Addr& from, double now) {
        if (n < HS_LEN || b[1] != VER) return;
        uint8_t tag[16]; hashTo(tag, 16, b, 62, psk, 32); if (crypto_verify_16(tag, b + 62) != 0) { rejected++; return; }   // wrong room secret -> ignore silently
        uint32_t ts = getU32(b + 2); double skew = (double)time(nullptr) - (double)ts; if (skew > 600 || skew < -600) return;
        for (auto& kv : peers) if (!memcmp(kv.second.cnonce, b + 38, 24)) { if (!kv.second.confirmed && !kv.second.welcome.empty()) sock.send(from, kv.second.welcome.data(), kv.second.welcome.size()); return; }   // retransmit
        for (int i = 0; i < nonceCount; i++) if (!memcmp(nonceRing[i], b + 38, 24)) return;   // replayed HELLO from an earlier (now closed) attempt
        if (hsBudget <= 0) return; hsBudget--;   // only authenticated HELLOs count against the join-rate budget
        size_t pend = 0; for (auto& kv : peers) if (!kv.second.confirmed) pend++;
        if (pend >= 8 || peers.size() >= maxPeers + 8 || confirmedCount() >= maxPeers) return;
        memcpy(nonceRing[nonceN], b + 38, 24); nonceN = (nonceN + 1) & 255; if (nonceCount < 256) nonceCount++;
        uint8_t hpk[32], hsk[32], rx[32], tx[32]; crypto_kx_keypair(hpk, hsk);
        if (crypto_kx_server_session_keys(rx, tx, hpk, hsk, b + 6) != 0) return;
        uint8_t hn[24]; randombytes_buf(hn, 24);
        uint8_t tin[62 + 32 + 24]; memcpy(tin, b, 62); memcpy(tin + 62, hpk, 32); memcpy(tin + 94, hn, 24); uint8_t tr[32]; hashTo(tr, 32, tin, sizeof tin);
        Peer p; do { p.sid = randombytes_uniform(0xFFFFFFFEu) + 1; } while (peers.count(p.sid));
        deriveSession(psk, tx, rx, tr, p.s.txk, p.s.rxk); p.s.sid = p.sid;   // server tx = s2c, server rx = c2s
        p.addr = from; p.created = p.last = now; memcpy(p.cnonce, b + 38, 24);
        uint8_t w[HS_LEN]; randombytes_buf(w, sizeof w); w[0] = T_WELCOME; putU32(w + 1, p.sid); memcpy(w + 5, hpk, 32); memcpy(w + 37, hn, 24);
        uint8_t tm[61 + 32]; memcpy(tm, w, 61); memcpy(tm + 61, tr, 32); hashTo(w + 61, 16, tm, sizeof tm, psk, 32);
        p.welcome.assign(w, w + HS_LEN); sock.send(from, w, HS_LEN);
        sodium_memzero(hsk, 32); sodium_memzero(rx, 32); sodium_memzero(tx, 32);
        peers[p.sid] = std::move(p);
    }
    void onData(const uint8_t* b, size_t n, const Addr& from, double now) {
        if (n < HDR) return; auto it = peers.find(getU32(b + 1)); if (it == peers.end()) return; Peer& p = it->second;
        uint8_t pl[MAX_PLAIN + 64]; size_t plen = 0; if (!p.s.open(b, n, pl, plen)) { rejected++; return; }
        p.last = now; if (!p.addr.same(from)) p.addr = from;   // authenticated roaming (NAT rebinding)
        uint32_t sid = p.sid; bool first = !p.confirmed; if (first) { p.confirmed = true; p.welcome.clear(); ev.push_back({ Event::CONNECTED, sid, {} }); }
        bool bye = false;
        bool ok = p.ch.parse(pl, plen, [&](const uint8_t* d, size_t l) { ev.push_back({ Event::REL, sid, std::vector<uint8_t>(d, d + l) }); },
                             [&](const uint8_t* d, size_t l) { if (l == 1 && d[0] == 0xFF) bye = true; else if (!(l == 1 && d[0] == 0xFE)) ev.push_back({ Event::UNREL, sid, std::vector<uint8_t>(d, d + l) }); });
        if (!ok) rejected++;
        if (bye) drop(sid);
    }
};

// ---------------------------------------------------------------- client
class Client {
public:
    enum State { IDLE, CONNECTING, CONNECTED, FAILED } st = IDLE; std::string err; Sock sock; Addr srv; std::vector<Addr> cands; uint8_t psk[32] = { 0 }; Sess s; Chan ch; std::vector<Event> ev; uint16_t defPort = 47474;
    bool connect(const std::string& hostPort, const std::string& code) {
        stop(); ch = Chan(); ev.clear(); s = Sess();
        if (sodium_init() < 0) return fail("crypto init failed");
        uint8_t raw[16]; if (!decodeCode(code, raw)) return fail("invite code is not valid");
        pskFromCode(raw, psk);
        if (!resolve(hostPort, defPort, srv)) return fail("could not resolve host address");
        if (!sock.open(0)) return fail("could not open a UDP socket");
        if (!sock.v6 && srv.ss.ss_family == AF_INET6) return fail("this machine has no IPv6 but the host address is IPv6");
        cands = { srv }; return begin();
    }
    bool begin() {
        crypto_kx_keypair(epk, esk);
        memset(hello, 0, sizeof hello); randombytes_buf(hello, sizeof hello);   // random padding, overwritten below
        hello[0] = T_HELLO; hello[1] = VER; putU32(hello + 2, (uint32_t)time(nullptr)); memcpy(hello + 6, epk, 32); randombytes_buf(hello + 38, 24);
        hashTo(hello + 62, 16, hello, 62, psk, 32);
        st = CONNECTING; t0 = nowSec(); lastHello = 0; err.clear(); return true;
    }
    bool connectInvite(const std::string& invite) {
        stop(); ch = Chan(); ev.clear(); s = Sess(); if (sodium_init() < 0) return fail("crypto init failed");
        uint8_t raw[16]; std::vector<Addr> eps; if (!parseInvite(invite, raw, eps)) return fail("invite code is not valid (check it was copied completely)");
        pskFromCode(raw, psk); cands = eps; srv = eps[0];
        if (!sock.open(0)) return fail("could not open a UDP socket");
        return begin();
    }
    void stop() { if (st == CONNECTED) { uint8_t bye[1] = { 0xFF }; sendU(bye, 1); } sock.close(); st = IDLE; }
    void sendU(const uint8_t* d, size_t n) {
        if (st != CONNECTED) return; uint8_t pl[MAX_PLAIN], pk[MAX_DGRAM]; size_t k = ch.build(pl, sizeof pl, d, n); if (!k) return;
        size_t m = s.seal(pk, sizeof pk, pl, k); if (m) sock.send(srv, pk, m);
    }
    bool sendR(const uint8_t* d, size_t n) { return ch.queue(d, n); }
    void poll() {
        if (st == IDLE || st == FAILED) return; double now = nowSec();
        if (st == CONNECTING) { if (now - t0 > 10) { st = FAILED; err = "no reply (wrong address, blocked port, or wrong code)"; return; } if (now - lastHello > 0.4) { lastHello = now; for (auto& c : cands) sock.send(c, hello, HS_LEN); } }
        uint8_t buf[2048]; Addr from;
        for (int i = 0; i < 256; i++) {
            ssize_t r = sock.recv(buf, sizeof buf, from); if (r < 0) break; if (r < 1 || (size_t)r > MAX_DGRAM) continue;
            bool known = srv.same(from); if (!known && st == CONNECTING) for (auto& c : cands) if (c.same(from)) known = true;
            if (!known) continue;   // only addresses we dialed
            if (buf[0] == T_WELCOME && st == CONNECTING && (size_t)r >= HS_LEN) { Addr keep = srv; srv = from; size_t before = ev.size(); onWelcome(buf, now); if (ev.size() == before) srv = keep; }
            else if (buf[0] == T_DATA && st == CONNECTED) onData(buf, (size_t)r, now);
        }
        if (st == CONNECTED && now - lastRx > 8.0) { st = FAILED; err = "connection timed out"; ev.push_back({ Event::DISCONNECTED, 0, {} }); }
    }
private:
    uint8_t epk[32] = { 0 }, esk[32] = { 0 }, hello[HS_LEN] = { 0 }; double t0 = 0, lastHello = 0, lastRx = 0;
    bool fail(const char* m) { err = m; st = FAILED; return false; }
    void onWelcome(const uint8_t* b, double now) {
        uint8_t hpk[32]; memcpy(hpk, b + 5, 32);
        uint8_t tin[62 + 32 + 24]; memcpy(tin, hello, 62); memcpy(tin + 62, hpk, 32); memcpy(tin + 94, b + 37, 24); uint8_t tr[32]; hashTo(tr, 32, tin, sizeof tin);
        uint8_t tm[61 + 32], tag[16]; memcpy(tm, b, 61); memcpy(tm + 61, tr, 32); hashTo(tag, 16, tm, sizeof tm, psk, 32);
        if (crypto_verify_16(tag, b + 61) != 0) return;   // not from someone who knows the room secret
        uint8_t rx[32], tx[32]; if (crypto_kx_client_session_keys(rx, tx, epk, esk, hpk) != 0) return;
        s = Sess(); s.sid = getU32(b + 1); deriveSession(psk, rx, tx, tr, s.rxk, s.txk);   // client rx = s2c, tx = c2s
        sodium_memzero(esk, 32); sodium_memzero(rx, 32); sodium_memzero(tx, 32);
        st = CONNECTED; lastRx = now; ev.push_back({ Event::CONNECTED, 0, {} });
        uint8_t ping[1] = { 0xFE }; sendU(ping, 1);   // first authenticated packet confirms the session to the host
    }
    void onData(const uint8_t* b, size_t n, double now) {
        uint8_t pl[MAX_PLAIN + 64]; size_t plen = 0; if (getU32(b + 1) != s.sid || !s.open(b, n, pl, plen)) return;
        lastRx = now; bool bye = false;
        ch.parse(pl, plen, [&](const uint8_t* d, size_t l) { ev.push_back({ Event::REL, 0, std::vector<uint8_t>(d, d + l) }); },
                 [&](const uint8_t* d, size_t l) { if (l == 1 && d[0] == 0xFF) bye = true; else if (!(l == 1 && d[0] == 0xFE)) ev.push_back({ Event::UNREL, 0, std::vector<uint8_t>(d, d + l) }); });
        if (bye) { st = FAILED; err = "host closed the game"; ev.push_back({ Event::DISCONNECTED, 0, {} }); }
    }
};
}   // namespace net
